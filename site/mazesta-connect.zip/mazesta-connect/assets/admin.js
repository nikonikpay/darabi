/* Mazesta Connect admin: part rows (add / remove), filtering a list of checkboxes, rows that open on click. No libraries. */
(function () {
  'use strict';
  document.addEventListener('click', function (e) {
    var add = e.target.closest('[data-mzc-add]');
    if (add) {
      e.preventDefault();
      var box = document.getElementById(add.getAttribute('data-mzc-add')), tpl = document.getElementById(add.getAttribute('data-mzc-add') + '-tpl');
      if (!box || !tpl) return;
      var n = parseInt(box.getAttribute('data-next') || '0', 10);
      var row = document.createElement('div'); row.className = 'mzc-row';
      row.innerHTML = tpl.innerHTML.replace(/__N__/g, String(n));
      box.appendChild(row); box.setAttribute('data-next', String(n + 1));
      var first = row.querySelector('input,select'); if (first) first.focus();
      return;
    }
    var rm = e.target.closest('[data-mzc-remove]');
    if (rm) { e.preventDefault(); var r = rm.closest('.mzc-row'); if (r) r.remove(); return; }
    var go = e.target.closest('tr[data-href]');
    if (go && !e.target.closest('a,button,input,select')) { window.location = go.getAttribute('data-href'); }
  });
  document.addEventListener('input', function (e) {
    var f = e.target.closest('[data-mzc-filter]');
    if (!f) return;
    var q = f.value.trim().toLowerCase(), list = document.getElementById(f.getAttribute('data-mzc-filter'));
    if (!list) return;
    list.querySelectorAll('label').forEach(function (l) { l.style.display = l.textContent.toLowerCase().indexOf(q) >= 0 ? '' : 'none'; });
  });
  /* a part row picked from the stock (<input list="mzc-products">): the product id, and the category and prices the row has not been given yet */
  document.addEventListener('input', function (e) {
    var inp = e.target, row = inp.closest && inp.closest('[data-mzc-part]');
    if (!row || inp.getAttribute('data-f') !== 'name') return;
    var opt = null, list = document.getElementById('mzc-products');
    if (list) { for (var i = 0; i < list.options.length; i++) { if (list.options[i].value === inp.value) { opt = list.options[i]; break; } } }
    var f = function (k) { return row.querySelector('[data-f="' + k + '"]'); }, set = function (k, v, always) { var el = f(k); if (el && v != null && v !== '' && (always || !el.value)) el.value = v; };
    if (f('pid')) f('pid').value = opt ? opt.getAttribute('data-id') : '';
    if (!opt) return;
    set('cat', opt.getAttribute('data-cat'), true); set('sell', opt.getAttribute('data-sell')); set('buy', opt.getAttribute('data-buy')); set('w', opt.getAttribute('data-w'));
  });
  document.addEventListener('change', function (e) {
    var t = e.target.closest('[data-mzc-target]');
    if (!t) return;
    var some = document.getElementById('mzc-some'); if (some) some.style.display = t.value === 'some' ? '' : 'none';
  });
  document.addEventListener('submit', function (e) {
    var c = e.target.getAttribute && e.target.getAttribute('data-mzc-confirm');
    if (c && !window.confirm(c)) e.preventDefault();
  });

  /* the old-data import: asks the server for one small step at a time until it says it is done */
  var imp = document.getElementById('mzc-imp');
  if (imp) {
    var bar = imp.querySelector('.mzc-bar i'), txt = document.getElementById('mzc-imp-text'), go = document.getElementById('mzc-imp-go');
    var show = function (r) {
      bar.style.width = r.pct + '%';
      var c = r.counts || {}, parts = Object.keys(c).map(function (k) { return k + ': ' + c[k]; });
      txt.textContent = r.lines + ' رکورد — ' + (parts.join(' · ') || '…') + (r.skipped ? ' — ردشده (قبلاً بوده): ' + r.skipped : '') + (r.errors && r.errors.length ? ' — خطا: ' + r.errors.join(' | ') : '');
    };
    var step = function () {
      var fd = new FormData(); fd.append('action', 'mzc_import_step'); fd.append('n', imp.getAttribute('data-nonce'));
      fetch(imp.getAttribute('data-url'), { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (r) {
        if (r.error) { txt.textContent = r.error; if (go) go.disabled = false; return; }
        show(r);
        if (r.done) { txt.textContent += ' — تمام شد.'; if (go) go.remove(); } else { step(); }
      }).catch(function () { txt.textContent = 'ارتباط قطع شد؛ دوباره «شروع واردسازی» را بزنید (از همان‌جا ادامه می‌دهد).'; if (go) go.disabled = false; });
    };
    if (go) go.addEventListener('click', function () { go.disabled = true; step(); });
  }
})();
