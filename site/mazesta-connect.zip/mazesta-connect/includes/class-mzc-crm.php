<?php
if (!defined('ABSPATH')) { exit; }

/**
 * The CRM on the second database (see MZC_Crm_Db): customers, the new computers the shop built and sold (their parts with serial numbers and warranty, the invoice number of the
 * accounting program, the test report the app made), the service jobs (what the customer asked for, what was done, the parts added and their prices) and the photos of each.
 * The admin pages in admin/ read and write through this class; the customer's portal reads the same history (only its own).
 */
final class MZC_Crm
{
    const PHOTO_MAX = 8;
    const PHOTO_BYTES = 8388608;

    public static $categories = array('cpu' => 'پردازنده', 'motherboard' => 'مادربرد', 'ram' => 'رم', 'gpu' => 'کارت گرافیک', 'ssd' => 'SSD / NVMe', 'hdd' => 'هارد', 'psu' => 'پاور',
        'case' => 'کیس', 'cooler' => 'خنک‌کننده', 'fan' => 'فن', 'monitor' => 'مانیتور', 'other' => 'سایر');
    /** What a new computer or a service job is about (the forms' "device" choice). */
    public static $device_types = array('system' => 'سیستم', 'laptop' => 'لپ‌تاپ', 'part' => 'قطعه', 'other' => 'سایر');
    /** The old CRM's customer groups (shop customers, agents, staff, ...). */
    public static $groups = array('customer' => 'مشتری', 'lead' => 'مشتری بالقوه', 'agent' => 'نماینده', 'general' => 'عمومی', 'warranty' => 'گارانتی', 'staff' => 'پرسنل', 'store' => 'انبار', 'courier' => 'پیک و باربری');

    /** Where a new computer is on its way: the shop's own steps from the queue to the customer's hands. */
    public static $build_statuses = array('queue' => 'در صف اسمبل', 'assembling' => 'در حال اسمبل', 'assembled' => 'اسمبل شده', 'testing' => 'در حال تست', 'tested' => 'اتمام تست و اعلام به مشتری', 'delivered' => 'ارسال و تحویل');

    public static $statuses = array('received' => 'پذیرش شد', 'diagnosing' => 'در حال بررسی', 'waiting_part' => 'منتظر قطعه', 'ready' => 'آماده تحویل', 'delivered' => 'تحویل شد', 'cancelled' => 'لغو شد');

    public static function boot()
    {
        foreach (array('customer_save', 'customer_delete', 'build_save', 'build_delete', 'job_save', 'job_delete', 'job_call', 'job_call_delete', 'photo_delete', 'db_wipe', 'db_save', 'db_install', 'sms_save', 'sms_test', 'soft_save') as $a) {
            add_action('admin_post_mzc_' . $a, array(__CLASS__, 'act_' . $a));
        }
        add_action('admin_post_mzc_photo', array(__CLASS__, 'act_photo'));
        add_action('wp_ajax_mzc_customer_find', array(__CLASS__, 'ajax_customer_find'));
        add_action('wp_ajax_mzc_product_find', array(__CLASS__, 'ajax_product_find'));
    }

    /** The stock products a form's live search offers as one types (a part row, an invoice line): with their stock and prices. */
    public static function ajax_product_find()
    {
        if (!Mazesta_Connect::can() || !check_ajax_referer('mzc_product_find', 'n', false)) { wp_send_json(array('items' => array()), 403); }
        $q = isset($_GET['q']) ? trim(sanitize_text_field(wp_unslash($_GET['q']))) : '';
        list($rows) = mb_strlen($q) >= 2 ? MZC_Stock::products($q, 1, 12) : array(array());
        $n = function ($v) { return $v === null ? null : (int) $v; };
        wp_send_json(array('items' => array_map(function ($p) use ($n) { return array('id' => (int) $p['id'], 'name' => $p['name'], 'category' => $p['category'], 'stock' => (int) $p['stock'],
            'sell_price' => $n($p['sell_price']), 'buy_price' => $n($p['buy_price']), 'warranty_months' => $n($p['warranty_months'])); }, $rows)));
    }

    /** The forms' customer boxes ask this as one types a name or a mobile number: the closest customers (any of their numbers matches). */
    public static function ajax_customer_find()
    {
        if (!Mazesta_Connect::can() || !check_ajax_referer('mzc_customer_find', 'n', false)) { wp_send_json(array('items' => array()), 403); }
        $q = isset($_GET['q']) ? trim(sanitize_text_field(wp_unslash($_GET['q']))) : '';
        list($rows) = mb_strlen($q) >= 2 ? self::customers($q, 1, 8) : array(array());
        wp_send_json(array('items' => array_map(function ($c) { return array('id' => (int) $c['id'], 'name' => $c['name'], 'mobiles' => self::mobiles_of($c), 'phone' => (string) $c['phone']); }, $rows)));
    }

    /* ---------- the programs a customer asks for (both forms, and the customer's own page) ---------- */

    /** What the forms suggest as one types a program's name; any other name is taken as well. The shop edits the list on the settings page. */
    const SOFTWARE = "Windows 11 Pro\nWindows 10 Pro\nMicrosoft Office 2021\nMicrosoft Office 365\nAdobe Photoshop\nAdobe Illustrator\nAdobe Premiere Pro\nAdobe After Effects\nAdobe Acrobat\nAutodesk 3ds Max\nAutodesk AutoCAD\nAutodesk Revit\nAutodesk Maya\nSketchUp\nLumion\nV-Ray\nCorona Renderer\nD5 Render\nEnscape\nTwinmotion\nCinema 4D\nBlender\nRhino\nUnreal Engine\nSolidWorks\nCATIA\nMATLAB\nVisual Studio\nPython\nWinRAR\n7-Zip\nGoogle Chrome\nMozilla Firefox\nVLC\nK-Lite Codec Pack\nInternet Download Manager\nTelegram Desktop\nAnyDesk\nSteam\nEpic Games Launcher\nNVIDIA App\nMSI Afterburner\nESET NOD32\nKaspersky";

    /** A list the forms suggest from: 'software' (the programs) or 'accounts' (where customers pay: POS, cards, accounts). */
    public static function software_catalog($k = 'software')
    {
        $db = self::db(); $v = $db ? $db->get_var($db->prepare('SELECT v FROM `' . self::t('meta') . '` WHERE k = %s', $k)) : null;
        return array_values(array_unique(array_filter(array_map('trim', explode("\n", $v === null ? ($k === 'software' ? self::SOFTWARE : '') : (string) $v)))));
    }

    public static function save_software_catalog($text, $k = 'software')
    {
        $db = self::db(); if (!$db) { return; }
        $list = array_slice(array_values(array_unique(array_filter(array_map(function ($x) { return mb_substr(trim($x), 0, 80); }, preg_split('/[\r\n]+/', (string) $text))))), 0, 500);
        $db->query($db->prepare('REPLACE INTO `' . self::t('meta') . '` (k, v) VALUES (%s, %s)', $k, implode("\n", $list)));
    }

    /** A record's requested programs as stored (JSON): rows of (name, installed?), the customer's own words, and when the customer last saved it on their page. */
    public static function soft_out($json)
    {
        $d = is_string($json) && $json !== '' ? json_decode($json, true) : null; $d = is_array($d) ? $d : array();
        $items = array();
        foreach (isset($d['items']) && is_array($d['items']) ? $d['items'] : array() as $x) { if (is_array($x) && isset($x['name']) && is_string($x['name'])) { $items[] = array('name' => $x['name'], 'done' => !empty($x['done'])); } }
        return array('items' => $items, 'note' => isset($d['note']) && is_string($d['note']) ? $d['note'] : '', 'by_customer' => isset($d['by_customer']) && is_string($d['by_customer']) ? $d['by_customer'] : '');
    }

    /** The JSON to store from rows (array(name, done) or plain names) and a note; null when both are empty. $byCustomer: when the customer saved it (else kept from $old). */
    public static function soft_in($rows, $note, $old = null, $byCustomer = '')
    {
        $items = array(); $seen = array();
        foreach (is_array($rows) ? $rows : array() as $x) {
            $n = is_array($x) ? (isset($x['name']) && is_string($x['name']) ? $x['name'] : '') : (is_string($x) ? $x : '');
            $n = mb_substr(trim(wp_strip_all_tags($n)), 0, 80); $k = mb_strtolower($n);
            if ($n === '' || isset($seen[$k])) { continue; }
            $seen[$k] = 1; $items[] = array('name' => $n, 'done' => is_array($x) && !empty($x['done']));
            if (count($items) >= 60) { break; }
        }
        $note = mb_substr(trim(sanitize_textarea_field((string) $note)), 0, 2000);
        $was = self::soft_out($old); $by = $byCustomer !== '' ? $byCustomer : $was['by_customer'];
        return $items || $note !== '' ? wp_json_encode(array('items' => $items, 'note' => $note, 'by_customer' => $by), JSON_UNESCAPED_UNICODE) : null;
    }

    /**
     * The tick lists of a service or a new computer, per device type: 'recv' = what came in with the device (or goes out with a new one), 'check' = the shop's checks
     * before it leaves. Stored as JSON (checks_in); a person or the AI app ticks them.
     */
    public static $checklists = array(
        'recv' => array(
            'system' => array('case_box' => 'جعبهٔ کیس', 'power_cable' => 'کابل پاور', 'monitor_cable' => 'کابل مانیتور', 'wifi_dongle' => 'دانگل وای‌فای', 'door_left' => 'درِ سمت چپ', 'door_right' => 'درِ سمت راست',
                'mesh_door' => 'توری روی در', 'mesh_top' => 'توری بالای کیس', 'mesh_bottom' => 'توری پایین کیس'),
            'laptop' => array('charger' => 'شارژر', 'bag' => 'کیف', 'box' => 'جعبه', 'battery' => 'باتری', 'mouse' => 'ماوس'),
            'part' => array('box' => 'جعبه', 'cables' => 'کابل و لوازم جانبی', 'card' => 'کارت گارانتی / فاکتور'),
        ),
        'check' => array(
            'system' => array('parts_invoice' => 'چک قطعات با فاکتور', 'gpu_plate' => 'پلیت گرافیک', 'gpu_screw' => 'پیچ شدن گرافیک', 'case_fans' => 'کار کردن فن‌های کیس', 'usb' => 'چک USBها (جلو و پشت)',
                'audio' => 'چک پورت صدا (جلو و پشت)', 'backup' => 'کپی آرشیو اطلاعات', 'board_screws' => 'بسته بودن پیچ‌های برد', 'logo' => 'لوگوی مازستا', 'restore_point' => 'Restore point', 'power_option' => 'Power Option',
                'virtual_memory' => 'Virtual Memory', 'hdmi' => 'HDMI', 'displayport' => 'DisplayPort', 'cpu_fan' => 'CPU Fan Config', 'rgb' => 'RGB sync', 'antivirus' => 'Antivirus', 'drivers' => 'Drivers'),
            'laptop' => array('parts_invoice' => 'چک مشخصات با فاکتور', 'screen' => 'صفحه‌نمایش (پیکسل، نور)', 'keyboard' => 'کیبورد و تاچ‌پد', 'usb' => 'پورت‌های USB', 'audio' => 'بلندگو و پورت صدا',
                'webcam' => 'وب‌کم و میکروفون', 'wifi' => 'وای‌فای و بلوتوث', 'battery' => 'باتری و شارژ شدن', 'body' => 'لولا، بدنه و پیچ‌ها', 'backup' => 'کپی آرشیو اطلاعات', 'restore_point' => 'Restore point',
                'power_option' => 'Power Option', 'antivirus' => 'Antivirus', 'drivers' => 'Drivers'),
            'part' => array('model_invoice' => 'مدل و سریال با فاکتور', 'look' => 'سالم بودن ظاهری', 'test' => 'تست کارکرد', 'box' => 'جعبه و لوازم'),
        ),
    );

    /** A record's ticks as stored: the ticked keys of each list and the note on what came in. */
    public static function checks_out($json)
    {
        $d = is_string($json) && $json !== '' ? json_decode($json, true) : null; $d = is_array($d) ? $d : array();
        $keys = function ($k) use ($d) { return isset($d[$k]) && is_array($d[$k]) ? array_values(array_filter($d[$k], 'is_string')) : array(); };
        return array('recv' => $keys('recv'), 'check' => $keys('check'), 'note' => isset($d['note']) && is_string($d['note']) ? $d['note'] : '');
    }

    /** The JSON to store from array(recv => keys, check => keys, note): only the keys of this device type's lists; null when nothing is ticked or written. */
    public static function checks_in($in, $type)
    {
        $in = is_array($in) ? $in : array(); $out = array();
        foreach (array('recv', 'check') as $l) {
            $known = isset(self::$checklists[$l][$type]) ? self::$checklists[$l][$type] : array();
            $out[$l] = array_values(array_intersect(array_keys($known), isset($in[$l]) && is_array($in[$l]) ? array_map('strval', $in[$l]) : array()));
        }
        $out['note'] = mb_substr(trim(sanitize_textarea_field(isset($in['note']) && is_scalar($in['note']) ? (string) $in['note'] : '')), 0, 2000);
        return $out['recv'] || $out['check'] || $out['note'] !== '' ? wp_json_encode($out, JSON_UNESCAPED_UNICODE) : null;
    }

    /** A new computer's name in the lists: its graphics card, else its processor (the form no longer asks for a title). */
    public static function build_title($parts)
    {
        $pick = function ($cat) use ($parts) { foreach ($parts as $p) { if (isset($p['category'], $p['model']) && $p['category'] === $cat && $p['model'] !== null && $p['model'] !== '') { return $p['model']; } } return ''; };
        $m = $pick('gpu') ?: $pick('cpu');
        return $m !== '' ? mb_substr('سیستم ' . $m, 0, 190) : 'سیستم نو';
    }

    /* ---------- small helpers ---------- */

    public static function mobile($s)
    {
        $s = strtr((string) $s, array('۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9'));
        $s = preg_replace('/\D+/', '', $s);
        if (strpos($s, '0098') === 0) { $s = substr($s, 4); } elseif (strpos($s, '98') === 0 && strlen($s) === 12) { $s = substr($s, 2); }
        if (strlen($s) === 10 && $s[0] === '9') { $s = '0' . $s; }
        return preg_match('/^09\d{9}$/', $s) ? $s : '';
    }

    public static function digits($s) { return strtr((string) $s, array('۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9')); }

    public static function post($k, $max = 255) { return Mazesta_Connect::clip(isset($_POST[$k]) ? wp_unslash($_POST[$k]) : '', $max); }
    public static function post_long($k, $max = 4000) { return isset($_POST[$k]) ? mb_substr(trim(sanitize_textarea_field(wp_unslash($_POST[$k]))), 0, $max) : ''; }
    public static function date($k) { $v = self::digits(self::post($k, 10)); return preg_match('/^\d{4}-\d{2}-\d{2}$/', $v) ? $v : null; }
    private static function now() { return gmdate('Y-m-d H:i:s'); }

    /** A Gregorian date (Y-m-d) as the Persian calendar's Y/m/d. */
    public static function jdate($ymd)
    {
        if (!is_string($ymd) || !preg_match('/^(\d{4})-(\d{2})-(\d{2})/', $ymd, $m)) { return ''; }
        $gy = (int) $m[1]; $gm = (int) $m[2]; $gd = (int) $m[3];
        $g = array(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334);
        $gy2 = $gm > 2 ? $gy + 1 : $gy;
        $days = 355666 + 365 * $gy + (int) (($gy2 + 3) / 4) - (int) (($gy2 + 99) / 100) + (int) (($gy2 + 399) / 400) + $gd + $g[$gm - 1];
        $jy = -1595 + 33 * (int) ($days / 12053); $days %= 12053;
        $jy += 4 * (int) ($days / 1461); $days %= 1461;
        if ($days > 365) { $jy += (int) (($days - 1) / 365); $days = ($days - 1) % 365; }
        $jm = $days < 186 ? 1 + (int) ($days / 31) : 7 + (int) (($days - 186) / 30);
        $jd = 1 + ($days < 186 ? $days % 31 : ($days - 186) % 30);
        return sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
    }

    /** A unix time (now by default) in the site's time zone. Not wp_date(): Persian-calendar plugins filter it into a Shamsi date, which jdate() then converted again (year 0784, a 227,000-day Installs table). */
    public static function ymd($ts = null, $fmt = 'Y-m-d') { $d = new DateTime('@' . ($ts === null ? time() : (int) $ts)); $d->setTimezone(wp_timezone()); return $d->format($fmt); }

    /** A unix time as "1405/07/30 14:32" (Persian calendar, site time). */
    public static function jtime($ts) { return self::jdate(self::ymd($ts)) . ' ' . self::ymd($ts, 'H:i'); }

    /** A typed date - Y-m-d or Y/m/d, Gregorian or Persian (a year below 1700 is read as Persian), Persian digits allowed - as Gregorian Y-m-d, or null. */
    public static function gdate($s)
    {
        if (!preg_match('/^(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})$/', trim(self::digits((string) $s)), $m)) { return null; }
        list(, $y, $mo, $d) = array_map('intval', $m);
        if ($y < 1700) {
            if ($mo < 1 || $mo > 12 || $d < 1 || $d > 31) { return null; }
            $jy = $y + 1595; $days = -355668 + 365 * $jy + (int) ($jy / 33) * 8 + (int) ((($jy % 33) + 3) / 4) + $d + ($mo < 7 ? ($mo - 1) * 31 : ($mo - 7) * 30 + 186);
            $y = 400 * (int) ($days / 146097); $days %= 146097;
            if ($days > 36524) { $days--; $y += 100 * (int) ($days / 36524); $days %= 36524; if ($days >= 365) { $days++; } }
            $y += 4 * (int) ($days / 1461); $days %= 1461;
            if ($days > 365) { $y += (int) (($days - 1) / 365); $days = ($days - 1) % 365; }
            $d = $days + 1; $len = array(31, ($y % 4 === 0 && $y % 100 !== 0) || $y % 400 === 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
            for ($mo = 1; $mo <= 12 && $d > $len[$mo - 1]; $mo++) { $d -= $len[$mo - 1]; }
        }
        return checkdate($mo, $d, $y) ? sprintf('%04d-%02d-%02d', $y, $mo, $d) : null;
    }

    /** The links to a record's photos and videos (the shop keeps them in a Telegram channel): https addresses only, at most 30. */
    public static function media_list($v)
    {
        $out = array();
        foreach (is_array($v) ? $v : preg_split('/[\s,]+/', (string) $v) as $u) {
            $u = is_string($u) ? trim($u) : '';
            if ($u !== '' && strlen($u) <= 300 && preg_match('#^https://[^\s<>"\']+$#i', $u) && !in_array($u, $out, true)) { $out[] = $u; }
        }
        return array_slice($out, 0, 30);
    }

    /** The id of the new computer ($kind 'build') or service ('job') a number names: its invoice number or service number ("1289", "R-1289"). 0 when none or when it is ambiguous. */
    public static function find_number($kind, $no)
    {
        $db = self::db(); $no = trim(self::digits((string) $no)); if (!$db || $no === '') { return 0; }
        $t = self::t($kind === 'build' ? 'builds' : 'jobs'); $r = ctype_digit($no) ? 'R-' . $no : $no;
        $ids = $db->get_col($db->prepare("SELECT id FROM `$t` WHERE invoice_no = %s OR service_no = %s OR service_no = %s LIMIT 2", $no, $no, $r));
        return count($ids) === 1 ? (int) $ids[0] : 0;
    }

    public static function money($n) { return number_format((int) $n) . ' تومان'; }

    /** The warranty's end for a part sold on $sold with $months months: array(date or null, days left or null). */
    public static function warranty($sold, $months)
    {
        if (!$sold || !$months) { return array(null, null); }
        $end = strtotime($sold . ' +' . (int) $months . ' months');
        return array(gmdate('Y-m-d', $end), (int) floor(($end - time()) / 86400));
    }

    public static function db() { return MZC_Crm_Db::db(); }
    private static function t($n) { return MZC_Crm_Db::t($n); }

    /* ---------- customers ---------- */

    public static function customer($id)
    {
        $db = self::db(); if (!$db) { return null; }
        return $db->get_row($db->prepare('SELECT * FROM `' . self::t('customers') . '` WHERE id = %d', (int) $id), ARRAY_A);
    }

    /** Every mobile number of a customer, the main one first: mobile, mobile2, then the third onward (the `mobiles` column, one per line). */
    public static function mobiles_of($c)
    {
        return array_values(array_unique(array_filter(array_merge(array((string) $c['mobile'], (string) $c['mobile2']), explode("\n", isset($c['mobiles']) ? (string) $c['mobiles'] : '')))));
    }

    /** The SQL that finds a customer having $n among any of their numbers (with its argument appended to $args). */
    private static function has_mobile_sql($n, &$args) { array_push($args, $n, $n, '%' . "\n" . $n . "\n" . '%'); return "(mobile = %s OR mobile2 = %s OR CONCAT('\n', COALESCE(mobiles, ''), '\n') LIKE %s)"; }

    public static function customer_by_mobile($mobile)
    {
        $db = self::db(); if (!$db) { return null; }
        $args = array(); $w = self::has_mobile_sql($mobile, $args); $args[] = $mobile;
        return $db->get_row($db->prepare('SELECT * FROM `' . self::t('customers') . "` WHERE $w ORDER BY (mobile = %s) DESC LIMIT 1", $args), ARRAY_A);
    }

    /** A page of customers (search in name, mobile, national id), newest first, with how many systems and jobs each has. */
    public static function customers($q, $page, $per = 30, $grp = '')
    {
        $db = self::db(); if (!$db) { return array(array(), 0); }
        $c = self::t('customers'); $where = '1=1'; $args = array();
        if ($q !== '') { $like = '%' . $db->esc_like(self::digits($q)) . '%'; $likeq = '%' . $db->esc_like($q) . '%'; $where = '(c.name LIKE %s OR c.mobile LIKE %s OR c.mobile2 LIKE %s OR c.mobiles LIKE %s OR c.national_id LIKE %s OR c.phone LIKE %s)'; $args = array($likeq, $like, $like, $like, $like, $like); }
        if ($grp !== '' && isset(self::$groups[$grp])) { $where = '(' . $where . ') AND c.grp = %s'; $args[] = $grp; }
        $total = (int) $db->get_var($args ? $db->prepare("SELECT COUNT(*) FROM `$c` c WHERE $where", $args) : "SELECT COUNT(*) FROM `$c`");
        $sql = "SELECT c.*, (SELECT COUNT(*) FROM `" . self::t('builds') . "` b WHERE b.customer_id = c.id) AS builds, (SELECT COUNT(*) FROM `" . self::t('jobs') . "` j WHERE j.customer_id = c.id) AS jobs
            FROM `$c` c WHERE $where ORDER BY c.id DESC LIMIT %d OFFSET %d";
        $rows = $db->get_results($db->prepare($sql, array_merge($args, array((int) $per, (int) (($page - 1) * $per)))), ARRAY_A);
        return array($rows ? $rows : array(), $total);
    }

    /** Creates or updates a customer from the posted fields. Returns the id, or a string with the error.
     *  $extra['mobiles'] (a list, the main number first) sets every mobile number at once; without it $mobile and $extra['mobile2'] set the first two and the rest stay. */
    public static function save_customer($id, $name, $mobile, $extra = array())
    {
        $db = self::db(); if (!$db) { return MZC_Crm_Db::error(); }
        $more = null;
        if (isset($extra['mobiles']) && is_array($extra['mobiles'])) {
            $list = array();
            foreach ($extra['mobiles'] as $x) {
                $x = trim((string) $x); if ($x === '') { continue; }
                $n = self::mobile($x); if ($n === '') { return 'شمارهٔ موبایل «' . $x . '» درست نیست (مثل 09121234567).'; }
                if (!in_array($n, $list, true)) { $list[] = $n; }
            }
            $mobile = isset($list[0]) ? $list[0] : ''; $extra['mobile2'] = isset($list[1]) ? $list[1] : ''; $more = array_slice($list, 2, 20);
        }
        $m = self::mobile($mobile);
        if ($name === '') { return 'نام مشتری را بنویسید.'; }
        if ($m === '' && trim((string) $mobile) !== '') { return 'شمارهٔ موبایل درست نیست (مثل 09121234567).'; }
        $t = self::t('customers');
        $m2 = self::mobile(isset($extra['mobile2']) ? $extra['mobile2'] : '');
        // a number this customer did not have yet may not belong to somebody else (numbers already on the record never block a save: the old data has some shared ones)
        $had = $id && ($old = self::customer($id)) ? self::mobiles_of($old) : array();
        foreach (array_merge(array($m, $m2), (array) $more) as $n) {
            if ($n === '' || in_array($n, $had, true)) { continue; }
            $args = array(); $w = self::has_mobile_sql($n, $args); $args[] = (int) $id;
            if ($db->get_var($db->prepare("SELECT id FROM `$t` WHERE $w AND id <> %d LIMIT 1", $args))) { return 'مشتری دیگری با شمارهٔ ' . $n . ' ثبت شده است.'; }
        }
        $row = array('name' => $name, 'mobile' => $m === '' ? null : $m, 'mobile2' => $m2 === '' || $m2 === $m ? null : $m2, 'phone' => isset($extra['phone']) ? $extra['phone'] : null, 'phone2' => isset($extra['phone2']) ? $extra['phone2'] : null, 'national_id' => isset($extra['national_id']) ? $extra['national_id'] : null,
            'email' => isset($extra['email']) ? $extra['email'] : null, 'address' => isset($extra['address']) ? $extra['address'] : null, 'notes' => isset($extra['notes']) ? $extra['notes'] : null, 'updated' => self::now());
        if (isset($extra['grp']) && isset(self::$groups[$extra['grp']])) { $row['grp'] = $extra['grp']; }
        if ($more !== null) { $row['mobiles'] = $more ? implode("\n", $more) : null; }
        if ($id) { $ok = $db->update($t, $row, array('id' => (int) $id)); return $ok === false ? 'ذخیره نشد: ' . $db->last_error : (int) $id; }
        $row['created'] = self::now(); if (!isset($row['grp'])) { $row['grp'] = 'customer'; }
        return $db->insert($t, $row) ? (int) $db->insert_id : 'ذخیره نشد: ' . $db->last_error;
    }

    /** The customer a form names: an existing one by mobile, or a new one made from the form's name. */
    public static function customer_of_form()
    {
        $id = isset($_POST['customer_id']) ? (int) $_POST['customer_id'] : 0;
        if ($id && self::customer($id)) { return $id; }
        $mobile = self::mobile(self::post('c_mobile', 30));
        if ($mobile === '') { return 'یک مشتری انتخاب کنید یا شمارهٔ موبایل او را بنویسید.'; }
        if ($c = self::customer_by_mobile($mobile)) { return (int) $c['id']; }
        return self::save_customer(0, self::post('c_name', 190), $mobile, array('mobile2' => self::post('c_mobile2', 30)));
    }

    /* ---------- builds (new computers) ---------- */

    public static function build($id)
    {
        $db = self::db(); if (!$db) { return null; }
        $b = $db->get_row($db->prepare('SELECT * FROM `' . self::t('builds') . '` WHERE id = %d', (int) $id), ARRAY_A);
        if (!$b) { return null; }
        $b['parts'] = $db->get_results($db->prepare('SELECT * FROM `' . self::t('build_parts') . '` WHERE build_id = %d ORDER BY id', (int) $id), ARRAY_A) ?: array();
        $b['photos'] = self::photos('build', $id);
        $b['more'] = !empty($b['data']) ? json_decode($b['data'], true) : array();
        return $b;
    }

    public static function builds($q, $page, $per = 30, $customer = 0, $status = '')
    {
        $db = self::db(); if (!$db) { return array(array(), 0); }
        $b = self::t('builds'); $c = self::t('customers'); $where = array('1=1'); $args = array();
        if ($customer) { $where[] = 'b.customer_id = %d'; $args[] = (int) $customer; }
        if ($status !== '' && isset(self::$build_statuses[$status])) { $where[] = 'b.status = %s'; $args[] = $status; }
        if ($q !== '') {
            $l = '%' . $db->esc_like($q) . '%';
            $where[] = "(b.service_no LIKE %s OR b.invoice_no LIKE %s OR b.title LIKE %s OR c.name LIKE %s OR c.mobile LIKE %s OR c.mobile2 LIKE %s OR c.mobiles LIKE %s OR EXISTS (SELECT 1 FROM `" . self::t('build_parts') . "` p WHERE p.build_id = b.id AND (p.serial LIKE %s OR p.model LIKE %s)))";
            $d = '%' . $db->esc_like(self::digits($q)) . '%'; array_push($args, $l, $l, $l, $l, $d, $d, $d, $l, $l);
        }
        $w = implode(' AND ', $where);
        $from = "FROM `$b` b JOIN `$c` c ON c.id = b.customer_id WHERE $w";
        $total = (int) $db->get_var($args ? $db->prepare("SELECT COUNT(*) $from", $args) : "SELECT COUNT(*) $from");
        $rows = $db->get_results($db->prepare("SELECT b.*, c.name AS customer_name, c.mobile AS customer_mobile, (SELECT COUNT(*) FROM `" . self::t('build_parts') . "` p WHERE p.build_id = b.id) AS parts $from ORDER BY b.id DESC LIMIT %d OFFSET %d",
            array_merge($args, array((int) $per, (int) (($page - 1) * $per)))), ARRAY_A);
        return array($rows ? $rows : array(), $total);
    }

    private static function posted_parts($prefix, $fields)
    {
        $out = array(); $rows = isset($_POST[$prefix]) && is_array($_POST[$prefix]) ? wp_unslash($_POST[$prefix]) : array();
        foreach ($rows as $r) {
            if (!is_array($r)) { continue; }
            $row = array();
            foreach ($fields as $f => $kind) {
                $v = isset($r[$f]) ? (is_string($r[$f]) ? trim($r[$f]) : '') : '';
                if ($kind === 'flag') { $row[$f] = !empty($r[$f]) ? 1 : 0; continue; }
                if ($kind === 'id') { $row[$f] = (int) $v > 0 ? (int) $v : null; continue; }
                if ($kind === 'int') { $v = self::digits($v); $row[$f] = $v === '' ? null : (int) preg_replace('/[^\d]/', '', $v); }
                elseif ($kind === 'cat') { $row[$f] = isset(self::$categories[$v]) ? $v : 'other'; }
                else { $row[$f] = $v === '' ? null : mb_substr(sanitize_text_field($v), 0, $kind); }
            }
            $out[] = $row;
        }
        return $out;
    }

    /** The software rows of a posted form (soft[n][name], soft[n][done]). */
    private static function posted_soft() { return isset($_POST['soft']) && is_array($_POST['soft']) ? wp_unslash($_POST['soft']) : array(); }

    public static function act_build_save()
    {
        MZC_Admin::guard('build_save');
        $db = self::db(); if (!$db) { MZC_Admin::back('mzc-builds', 'err:' . MZC_Crm_Db::error()); }
        $id = isset($_POST['id']) ? (int) $_POST['id'] : 0;
        if ($id && ($h = MZC_Rev::blocker('build', $id, get_current_user_id()))) { MZC_Admin::back('mzc-builds', 'err:' . MZC_Rev::busy_text($h), array('view' => $id)); }
        $cid = self::customer_of_form();
        if (!is_int($cid)) { MZC_Admin::back('mzc-builds', 'err:' . $cid, $id ? array('edit' => $id) : array('add' => 1)); }
        $bst = isset($_POST['status']) && isset(self::$build_statuses[$_POST['status']]) ? (string) $_POST['status'] : 'queue';
        $inv = self::digits(self::post('invoice_no', 60));
        // a new computer is known by its invoice number (no service number of its own any more); the old ones keep theirs
        if ($inv === '' && !$id) { MZC_Admin::back('mzc-builds', 'err:شمارهٔ فاکتور را بنویسید؛ سیستم نو با شمارهٔ فاکتور شناخته می‌شود.', array('add' => 1)); }
        $dup = $inv === '' || !empty($_POST['force']) ? 0 : (int) $db->get_var($db->prepare('SELECT id FROM `' . self::t('builds') . '` WHERE invoice_no = %s AND id <> %d LIMIT 1', $inv, $id));
        if ($dup) { MZC_Admin::back('mzc-builds', 'err:شمارهٔ فاکتور ' . $inv . ' قبلاً برای سیستم دیگری ثبت شده است (شمارهٔ ' . $dup . ').', $id ? array('edit' => $id) : array('add' => 1)); }
        $parts = MZC_Stock::link_parts(self::posted_parts('parts', array('product_id' => 'id', 'category' => 'cat', 'model' => 190, 'serial' => 120, 'warranty_months' => 'int', 'sell_price' => 'int', 'buy_price' => 'int', 'vendor' => 120, 'note' => 255, 'has_warranty' => 'flag', 'has_box' => 'flag', 'qc' => 'flag')),
            'model', array('sell_price' => 'sell_price', 'buy_price' => 'buy_price'));
        $was = $id ? $db->get_var($db->prepare('SELECT soft FROM `' . self::t('builds') . '` WHERE id = %d', $id)) : null;
        $row = array('customer_id' => $cid, 'invoice_no' => $inv ?: null, 'title' => self::build_title($parts), 'sold_at' => self::date('sold_at'), 'soft' => self::soft_in(self::posted_soft(), self::post_long('soft_note', 2000), $was),
            'report_id' => preg_match('/^[A-Za-z0-9-]{8,64}$/', self::post('report_id', 64)) ? self::post('report_id', 64) : null, 'notes' => self::post_long('notes'), 'status' => $bst, 'delivered' => $bst === 'delivered' ? 1 : 0, 'updated' => self::now());
        $row['device_type'] = isset($_POST['device_type'], self::$device_types[$_POST['device_type']]) ? (string) $_POST['device_type'] : 'system';
        $row['checks'] = self::checks_in(isset($_POST['checks']) ? wp_unslash($_POST['checks']) : array(), $row['device_type']);
        $t = self::t('builds'); $was = $id;
        // all or nothing: a part that fails to save must not leave the computer with half its parts
        $db->query('START TRANSACTION');
        if ($id) { $ok = $db->update($t, $row, array('id' => $id)) !== false; }
        else { $row['created'] = self::now(); $ok = (bool) $db->insert($t, $row); $id = (int) $db->insert_id; }
        if ($ok) { $ok = $db->delete(self::t('build_parts'), array('build_id' => $id)) !== false; }
        foreach ($parts as $p) { if (!$ok) { break; } if ($p['model'] === null) { continue; } $p['build_id'] = $id; $ok = (bool) $db->insert(self::t('build_parts'), $p); }
        $err = $db->last_error; $db->query($ok ? 'COMMIT' : 'ROLLBACK');
        if (!$ok) { MZC_Log::error('crm', 'build not saved', array('id' => $was, 'error' => $err)); MZC_Admin::back('mzc-builds', 'err:ذخیره نشد: ' . $err, $was ? array('edit' => $was) : array('add' => 1)); }
        MZC_Rev::record('build', $id, get_current_user_id(), $was ? 'update' : 'create'); MZC_Rev::unlock('build', $id, get_current_user_id());
        MZC_Admin::back('mzc-builds', 'ok:ثبت شد.', array('view' => $id));
    }

    public static function act_build_delete()
    {
        MZC_Admin::guard('build_delete');
        $db = self::db(); $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
        if ($db && $id) { self::delete_photos('build', $id); $db->delete(self::t('build_parts'), array('build_id' => $id)); $db->delete(self::t('builds'), array('id' => $id)); }
        MZC_Admin::back('mzc-builds', 'ok:سیستم پاک شد.');
    }

    /* ---------- service jobs ---------- */

    public static function job($id)
    {
        $db = self::db(); if (!$db) { return null; }
        $j = $db->get_row($db->prepare('SELECT * FROM `' . self::t('jobs') . '` WHERE id = %d', (int) $id), ARRAY_A);
        if (!$j) { return null; }
        $all = $db->get_results($db->prepare('SELECT * FROM `' . self::t('job_parts') . '` WHERE job_id = %d ORDER BY id', (int) $id), ARRAY_A) ?: array();
        $j['parts'] = array_values(array_filter($all, function ($p) { return $p['kind'] !== 'in'; }));      // added parts (they are charged)
        $j['recv'] = array_values(array_filter($all, function ($p) { return $p['kind'] === 'in'; }));       // parts the customer brought
        $j['pays'] = $db->get_results($db->prepare('SELECT * FROM `' . self::t('job_pays') . '` WHERE job_id = %d ORDER BY id', (int) $id), ARRAY_A) ?: array();
        $j['shipping'] = !empty($j['ship']) ? json_decode($j['ship'], true) : array();
        $j['more'] = !empty($j['data']) ? json_decode($j['data'], true) : array();
        $j['photos'] = self::photos('job', $id);
        $j['total'] = self::job_total($j);
        $j['calls'] = $db->get_results($db->prepare('SELECT * FROM `' . self::t('job_calls') . '` WHERE job_id = %d ORDER BY at, id', (int) $id), ARRAY_A) ?: array();
        $j['hands_out'] = self::hands_out(isset($j['hands']) ? $j['hands'] : null);
        return $j;
    }

    /** What the customer pays: parts + services - discount. The costs the shop paid out for the job (`paid`) are the shop's own: they lower the service's profit, never the customer's bill. */
    public static function job_total($j)
    {
        $sum = (int) $j['labor_price'] - (int) $j['discount'];
        foreach ($j['parts'] as $p) { $sum += (int) $p['qty'] * (int) $p['unit_price']; }
        return $sum;
    }

    /** Records per status ('job' or 'build') in one query, counted like the lists (with their customer): the staff app's home cards. */
    public static function status_counts($kind)
    {
        $db = self::db(); $out = array(); if (!$db) { return $out; }
        $t = self::t($kind === 'job' ? 'jobs' : 'builds'); $c = self::t('customers');
        foreach ((array) $db->get_results("SELECT x.status, COUNT(*) AS n FROM `$t` x JOIN `$c` c ON c.id = x.customer_id GROUP BY x.status", ARRAY_A) as $r) { $out[$r['status']] = (int) $r['n']; }
        return $out;
    }

    public static function jobs($q, $status, $page, $per = 30, $customer = 0)
    {
        $db = self::db(); if (!$db) { return array(array(), 0); }
        $j = self::t('jobs'); $c = self::t('customers'); $where = array('1=1'); $args = array();
        if ($customer) { $where[] = 'j.customer_id = %d'; $args[] = (int) $customer; }
        if ($status !== '' && isset(self::$statuses[$status])) { $where[] = 'j.status = %s'; $args[] = $status; }
        if ($q !== '') {
            $l = '%' . $db->esc_like($q) . '%';
            $d = '%' . $db->esc_like(self::digits($q)) . '%';
            $where[] = '(j.service_no LIKE %s OR j.device LIKE %s OR j.device_serial LIKE %s OR j.complaint LIKE %s OR c.name LIKE %s OR c.mobile LIKE %s OR c.mobile2 LIKE %s OR c.mobiles LIKE %s)';
            array_push($args, $l, $l, $l, $l, $l, $d, $d, $d);
        }
        $from = "FROM `$j` j JOIN `$c` c ON c.id = j.customer_id WHERE " . implode(' AND ', $where);
        $total = (int) $db->get_var($args ? $db->prepare("SELECT COUNT(*) $from", $args) : "SELECT COUNT(*) $from");
        $rows = $db->get_results($db->prepare("SELECT j.*, c.name AS customer_name, c.mobile AS customer_mobile, j.labor_price - j.discount + COALESCE((SELECT SUM(p.qty * p.unit_price) FROM `" . self::t('job_parts') . "` p WHERE p.job_id = j.id AND p.kind <> 'in'), 0) AS total,
            (SELECT k.result FROM `" . self::t('job_calls') . "` k WHERE k.job_id = j.id ORDER BY k.at DESC, k.id DESC LIMIT 1) AS last_call, (SELECT COUNT(*) FROM `" . self::t('job_calls') . "` k WHERE k.job_id = j.id) AS calls $from ORDER BY j.id DESC LIMIT %d OFFSET %d",
            array_merge($args, array((int) $per, (int) (($page - 1) * $per)))), ARRAY_A);
        return array($rows ? $rows : array(), $total);
    }

    /** The next service number: the old CRM's numbers (R-3579) go on from the highest one used by a service or a new computer. Call inside the lock. */
    public static function next_service_no($db)
    {
        $max = 0;
        foreach (array('jobs', 'builds') as $tb) { $max = max($max, (int) $db->get_var("SELECT MAX(CAST(SUBSTRING(service_no, 3) AS UNSIGNED)) FROM `" . self::t($tb) . "` WHERE service_no REGEXP '^R-[0-9]+$'")); }
        return 'R-' . ($max + 1);
    }

    public static function act_job_save()
    {
        MZC_Admin::guard('job_save');
        $db = self::db(); if (!$db) { MZC_Admin::back('mzc-jobs', 'err:' . MZC_Crm_Db::error()); }
        $id = isset($_POST['id']) ? (int) $_POST['id'] : 0;
        if ($id && ($h = MZC_Rev::blocker('job', $id, get_current_user_id()))) { MZC_Admin::back('mzc-jobs', 'err:' . MZC_Rev::busy_text($h), array('view' => $id)); }
        $cid = self::customer_of_form();
        if (!is_int($cid)) { MZC_Admin::back('mzc-jobs', 'err:' . $cid, $id ? array('edit' => $id) : array('add' => 1)); }
        $status = isset($_POST['status'], self::$statuses[$_POST['status']]) ? (string) $_POST['status'] : 'received';
        $closed = self::date('closed_at'); if ($status === 'delivered' && $closed === null) { $closed = self::ymd(); }
        $labor = (int) preg_replace('/[^\d]/', '', self::digits(self::post('labor_price', 15)));
        $was = $id ? $db->get_var($db->prepare('SELECT soft FROM `' . self::t('jobs') . '` WHERE id = %d', $id)) : null;
        $row = array('customer_id' => $cid, 'device' => self::post('device', 190) ?: null, 'device_serial' => self::post('device_serial', 120) ?: null, 'paid_note' => self::post('paid_note', 255) ?: null,
            'soft' => self::soft_in(self::posted_soft(), self::post_long('soft_note', 2000), $was),
            'device_type' => isset($_POST['device_type'], self::$device_types[$_POST['device_type']]) ? (string) $_POST['device_type'] : null, 'media' => implode("\n", self::media_list(isset($_POST['media']) ? wp_unslash($_POST['media']) : '')) ?: null, 'received_at' => self::date('received_at') ?: self::ymd(),
            'closed_at' => $closed, 'due_at' => self::date('due_at'), 'invoice_no' => self::post('invoice_no', 60) ?: null, 'is_mazesta' => empty($_POST['is_mazesta']) ? 0 : 1, 'has_warranty' => empty($_POST['has_warranty']) ? 0 : 1,
            'discount' => (int) preg_replace('/[^\d]/', '', self::digits(self::post('discount', 15))), 'paid' => (int) preg_replace('/[^\d]/', '', self::digits(self::post('paid', 15))), 'service_done' => in_array($status, array('ready', 'delivered'), true) ? 1 : 0, 'status' => $status, 'complaint' => self::post_long('complaint'), 'diagnosis' => self::post_long('diagnosis'), 'work_done' => self::post_long('work_done'), 'labor_price' => $labor,
            'report_id' => preg_match('/^[A-Za-z0-9-]{8,64}$/', self::post('report_id', 64)) ? self::post('report_id', 64) : null, 'notes' => self::post_long('notes'), 'updated' => self::now());
        $row['report_pre'] = preg_match('/^[A-Za-z0-9-]{8,64}$/', self::post('report_pre', 64)) ? self::post('report_pre', 64) : null;
        $row['checks'] = self::checks_in(isset($_POST['checks']) ? wp_unslash($_POST['checks']) : array(), (string) $row['device_type']);
        $t = self::t('jobs'); $was = $id;
        // all or nothing, as on the build form; the lock keeps two desks from taking the same service number
        $lock = $id ? null : $db->get_var("SELECT GET_LOCK('" . self::t('svc') . "', 5)");
        $db->query('START TRANSACTION');
        if ($id) { $ok = $db->update($t, $row, array('id' => $id)) !== false; }
        else { $row['created'] = self::now(); $row['service_no'] = self::next_service_no($db); $ok = (bool) $db->insert($t, $row); $id = (int) $db->insert_id; }
        if ($ok) { $ok = $db->delete(self::t('job_parts'), array('job_id' => $id)) !== false; }
        foreach (array('add' => 'parts', 'in' => 'recv') as $kind => $field) {
            $rows = self::posted_parts($field, array('product_id' => 'id', 'name' => 190, 'qty' => 'int', 'unit_price' => 'int', 'buy_price' => 'int', 'serial' => 120, 'warranty_months' => 'int', 'note' => 255, 'has_box' => 'flag', 'has_warranty' => 'flag'));
            // a part the customer brought is not the shop's stock
            $rows = $kind === 'in' ? array_map(function ($p) { $p['product_id'] = null; $p['buy_price'] = null; return $p; }, $rows) : MZC_Stock::link_parts($rows, 'name', array('unit_price' => 'sell_price', 'buy_price' => 'buy_price'));
            foreach ($rows as $p) {
                if (!$ok) { break; } if ($p['name'] === null) { continue; }
                $p['qty'] = max(1, (int) $p['qty']); $p['unit_price'] = $kind === 'in' ? 0 : (int) $p['unit_price']; $p['job_id'] = $id; $p['kind'] = $kind; $ok = (bool) $db->insert(self::t('job_parts'), $p);
            }
        }
        if ($ok) { $ok = $db->delete(self::t('job_pays'), array('job_id' => $id)) !== false; }
        foreach (self::posted_parts('pays', array('amount' => 'int', 'account' => 120, 'tx' => 80, 'holder' => 120)) as $p) { if (!$ok) { break; } if (!$p['amount']) { continue; } $p['job_id'] = $id; $ok = (bool) $db->insert(self::t('job_pays'), $p); }
        $err = $db->last_error; $db->query($ok ? 'COMMIT' : 'ROLLBACK');
        if ($lock) { $db->query("DO RELEASE_LOCK('" . self::t('svc') . "')"); }
        if (!$ok) { MZC_Log::error('crm', 'job not saved', array('id' => $was, 'error' => $err)); MZC_Admin::back('mzc-jobs', 'err:ذخیره نشد: ' . $err, $was ? array('edit' => $was) : array('add' => 1)); }
        MZC_Rev::record('job', $id, get_current_user_id(), $was ? 'update' : 'create'); MZC_Rev::unlock('job', $id, get_current_user_id());
        $bad = self::add_photos('job', $id);
        MZC_Admin::back('mzc-jobs', 'ok:ثبت شد.' . ($bad ? ' (' . $bad . ')' : ''), array('view' => $id));
    }

    public static function act_job_delete()
    {
        MZC_Admin::guard('job_delete');
        $db = self::db(); $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
        if ($db && $id) { self::delete_photos('job', $id); $db->delete(self::t('job_parts'), array('job_id' => $id)); $db->delete(self::t('job_pays'), array('job_id' => $id)); $db->delete(self::t('job_calls'), array('job_id' => $id)); $db->delete(self::t('jobs'), array('id' => $id)); }
        MZC_Admin::back('mzc-jobs', 'ok:سرویس پاک شد.');
    }

    /* ---------- calls to the customer about a service ---------- */

    public static $call_reasons = array('ready' => 'آماده شدن و تحویل', 'quote' => 'اعلام هزینه و گرفتن تأیید', 'question' => 'سؤال دربارهٔ دستگاه', 'parts' => 'قطعه و موجودی', 'followup' => 'پیگیری', 'other' => 'سایر');
    public static $call_results = array('informed' => 'اطلاع داده شد', 'approved' => 'هزینه را تأیید کرد', 'declined' => 'هزینه را تأیید نکرد', 'pickup' => 'وقت تحویل هماهنگ شد', 'callback' => 'خواست بعداً تماس بگیریم',
        'no_answer' => 'جواب نداد', 'off' => 'خاموش یا در دسترس نبود', 'busy' => 'اشغال بود', 'other' => 'سایر');
    /** The results after which the customer knows: the rest are tries that did not reach them. */
    public static $call_reached = array('informed', 'approved', 'declined', 'pickup', 'callback', 'other');

    public static function act_job_call()
    {
        MZC_Admin::guard('job_call');
        $db = self::db(); $id = isset($_POST['id']) ? (int) $_POST['id'] : 0;
        $reason = isset($_POST['reason'], self::$call_reasons[$_POST['reason']]) ? (string) $_POST['reason'] : 'other';
        $result = isset($_POST['result'], self::$call_results[$_POST['result']]) ? (string) $_POST['result'] : '';
        if (!$db || !$id || $result === '' || !$db->get_var($db->prepare('SELECT id FROM `' . self::t('jobs') . '` WHERE id = %d', $id))) { MZC_Admin::back('mzc-jobs', 'err:نتیجهٔ تماس را انتخاب کنید.', array('view' => $id)); }
        $u = wp_get_current_user();
        $db->insert(self::t('job_calls'), array('job_id' => $id, 'at' => self::now(), 'reason' => $reason, 'result' => $result, 'note' => self::post('note', 500) ?: null, 'user_id' => $u->ID ?: null, 'who' => $u->display_name ?: null));
        $db->update(self::t('jobs'), array('updated' => self::now()), array('id' => $id));
        MZC_Admin::back('mzc-jobs', 'ok:تماس ثبت شد.', array('view' => $id));
    }

    public static function act_job_call_delete()
    {
        MZC_Admin::guard('job_call_delete');
        $db = self::db(); $id = isset($_GET['id']) ? (int) $_GET['id'] : 0; $job = isset($_GET['job']) ? (int) $_GET['job'] : 0;
        if ($db && $id) { $db->delete(self::t('job_calls'), array('id' => $id, 'job_id' => $job)); }
        MZC_Admin::back('mzc-jobs', 'ok:تماس پاک شد.', array('view' => $job));
    }

    /* ---------- the app's hands-on checks (screen, keyboard, ports...), before and after the service ---------- */

    /** The stored checks: array('Before' => array('at' => ..., 'items' => array(key => array(name, verdict, note))), 'After' => ...). */
    public static function hands_out($json)
    {
        $d = is_string($json) && $json !== '' ? json_decode($json, true) : null;
        return is_array($d) ? array_intersect_key($d, self::$stages) : array();
    }

    /** Which tick of the "before it leaves" list an app check stands for, by device type: ticked when every check behind it was fine after the service. */
    private static $hands_ticks = array(
        'laptop' => array('screen' => array('Display'), 'keyboard' => array('Keys', 'Mouse'), 'usb' => array('Usb'), 'audio' => array('Speakers'), 'webcam' => array('Webcam', 'Mic'), 'wifi' => array('Wifi', 'Bluetooth'), 'battery' => array('Battery'), 'body' => array('Body')),
        'system' => array('usb' => array('Usb'), 'audio' => array('Speakers'), 'hdmi' => array('VideoOut')),
    );

    /**
     * The app's hands-on checks of the service with this number, as the test before the work or the one after it (the newest of each replaces the last).
     * After the service, every list tick whose checks all came back fine is ticked; nothing is unticked. Returns the number of items kept, or an error text.
     */
    public static function hands_in($service, $stage, $items)
    {
        $db = self::db(); if (!$db) { return 'CRM آماده نیست.'; }
        if (!isset(self::$stages[$stage])) { return 'قبل یا بعد از سرویس معلوم نیست.'; }
        $j = $db->get_row($db->prepare('SELECT id, hands, checks, device_type FROM `' . self::t('jobs') . '` WHERE service_no = %s ORDER BY id DESC LIMIT 1', $service), ARRAY_A);
        if (!$j) { return 'سرویسی با شمارهٔ ' . $service . ' در CRM نیست.'; }
        $kept = array();
        foreach (is_array($items) ? array_slice($items, 0, 60) : array() as $i) {
            if (!is_array($i) || !isset($i['key'], $i['verdict']) || !is_string($i['key']) || !preg_match('/^[A-Za-z]{1,40}$/', $i['key']) || !in_array($i['verdict'], array('ok', 'bad'), true)) { continue; }
            $kept[$i['key']] = array('name' => Mazesta_Connect::clip(isset($i['name']) ? $i['name'] : $i['key'], 120), 'verdict' => $i['verdict'], 'note' => Mazesta_Connect::clip(isset($i['note']) ? $i['note'] : '', 300));
        }
        if (!$kept) { return 'هیچ بررسی‌ای نرسید.'; }
        $all = self::hands_out($j['hands']); $all[$stage] = array('at' => self::now(), 'items' => $kept);
        $row = array('hands' => wp_json_encode($all, JSON_UNESCAPED_UNICODE), 'updated' => self::now());
        $type = (string) $j['device_type'];
        if ($stage === 'After' && isset(self::$hands_ticks[$type])) {
            $c = self::checks_out($j['checks']);
            foreach (self::$hands_ticks[$type] as $tick => $from) {
                $seen = array_intersect_key($kept, array_flip($from));
                if (count($seen) === count($from) && !array_filter($seen, function ($x) { return $x['verdict'] !== 'ok'; }) && !in_array($tick, $c['check'], true)) { $c['check'][] = $tick; }
            }
            $row['checks'] = self::checks_in($c, $type);
        }
        $db->update(self::t('jobs'), $row, array('id' => (int) $j['id']));
        return count($kept);
    }

    /* ---------- customers: admin actions ---------- */

    public static function act_customer_save()
    {
        MZC_Admin::guard('customer_save');
        $id = isset($_POST['id']) ? (int) $_POST['id'] : 0;
        $mob = isset($_POST['mobiles']) && is_array($_POST['mobiles']) ? array_map(function ($x) { return Mazesta_Connect::clip((string) $x, 30); }, wp_unslash($_POST['mobiles'])) : array();
        $r = self::save_customer($id, self::post('name', 190), '', array('mobiles' => $mob, 'phone' => self::post('phone', 80) ?: null, 'phone2' => null, 'national_id' => self::post('national_id', 20) ?: null,
            'email' => sanitize_email(self::post('email', 190)) ?: null, 'address' => self::post_long('address', 1000) ?: null, 'notes' => self::post_long('notes') ?: null, 'grp' => self::post('grp', 12)));
        if (!is_int($r)) { MZC_Admin::back('mzc-customers', 'err:' . $r, $id ? array('view' => $id) : array('add' => 1)); }
        MZC_Admin::back('mzc-customers', 'ok:مشتری ثبت شد.', array('view' => $r));
    }

    public static function act_customer_delete()
    {
        MZC_Admin::guard('customer_delete');
        $db = self::db(); $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
        if ($db && $id) {
            $n = (int) $db->get_var($db->prepare('SELECT (SELECT COUNT(*) FROM `' . self::t('builds') . '` WHERE customer_id = %d) + (SELECT COUNT(*) FROM `' . self::t('jobs') . '` WHERE customer_id = %d)', $id, $id));
            if ($n > 0) { MZC_Admin::back('mzc-customers', 'err:این مشتری سیستم یا سرویس ثبت‌شده دارد؛ اول آن‌ها را پاک کنید.', array('view' => $id)); }
            $db->delete(self::t('sessions'), array('customer_id' => $id)); $db->delete(self::t('customers'), array('id' => $id));
        }
        MZC_Admin::back('mzc-customers', 'ok:مشتری پاک شد.');
    }

    /** Everything a customer has: their systems and service jobs, each with parts and photos, newest first (the admin page and the portal both show this). */
    public static function history($customerId)
    {
        $db = self::db(); if (!$db) { return array(array(), array()); }
        $builds = array(); $jobs = array();
        foreach ((array) $db->get_col($db->prepare('SELECT id FROM `' . self::t('builds') . '` WHERE customer_id = %d ORDER BY COALESCE(sold_at, DATE(created)) DESC, id DESC', (int) $customerId)) as $id) { $builds[] = self::build($id); }
        foreach ((array) $db->get_col($db->prepare('SELECT id FROM `' . self::t('jobs') . '` WHERE customer_id = %d ORDER BY COALESCE(received_at, DATE(created)) DESC, id DESC', (int) $customerId)) as $id) { $jobs[] = self::job($id); }
        return array($builds, $jobs);
    }

    /** The customer's other forms (tests, warranty parts, hand-overs ...), newest first. */
    public static function forms_of($customerId)
    {
        $db = self::db(); if (!$db) { return array(); }
        $rows = $db->get_results($db->prepare('SELECT * FROM `' . self::t('forms') . '` WHERE customer_id = %d ORDER BY COALESCE(at, DATE(created)) DESC, id DESC', (int) $customerId), ARRAY_A) ?: array();
        foreach ($rows as &$r) { $r['more'] = !empty($r['data']) ? json_decode($r['data'], true) : array(); }
        return $rows;
    }

    public static $form_kinds = array('test' => 'تست سیستم', 'warranty' => 'قطعهٔ گارانتی / تعمیرگاه', 'handover' => 'تحویل و دریافت کالا', 'online' => 'خدمات آنلاین', 'solution' => 'راه‌حل');

    /* ---------- photos: files in the plugin's data folder (not in the media library), the names in the CRM database ---------- */

    private static function photo_dir() { return Mazesta_Connect::dir() . '/photos'; }

    public static function photos($entity, $id)
    {
        $db = self::db(); if (!$db) { return array(); }
        return $db->get_results($db->prepare('SELECT * FROM `' . self::t('photos') . '` WHERE entity = %s AND entity_id = %d ORDER BY id', $entity, (int) $id), ARRAY_A) ?: array();
    }

    /** Stores the posted images (resized to 1600 px, recompressed); returns a note about any that were refused, or ''. */
    private static function add_photos($entity, $id)
    {
        $db = self::db();
        if (!$db || empty($_FILES['photos']['name']) || !is_array($_FILES['photos']['name'])) { return ''; }
        if (!wp_mkdir_p(self::photo_dir())) { return 'پوشهٔ عکس‌ها ساخته نشد'; }
        $have = count(self::photos($entity, $id)); $refused = 0; $caption = self::post('photo_caption', 190);
        foreach ($_FILES['photos']['name'] as $i => $name) {
            if ($_FILES['photos']['error'][$i] === UPLOAD_ERR_NO_FILE) { continue; }
            $tmp = $_FILES['photos']['tmp_name'][$i];
            if ($have >= self::PHOTO_MAX || $_FILES['photos']['error'][$i] !== UPLOAD_ERR_OK || $_FILES['photos']['size'][$i] > self::PHOTO_BYTES || !is_uploaded_file($tmp)) { $refused++; continue; }
            $info = @getimagesize($tmp);
            $ext = $info && isset($info[2]) ? array(IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp') : array();
            $ext = $info && isset($ext[$info[2]]) ? $ext[$info[2]] : '';
            if ($ext === '') { $refused++; continue; }
            $file = bin2hex(random_bytes(16)) . '.' . $ext; $dest = self::photo_dir() . '/' . $file . '.dat';
            $ed = wp_get_image_editor($tmp);
            $ok = false;
            if (!is_wp_error($ed)) { $ed->resize(1600, 1600, false); $ed->set_quality(82); $saved = $ed->save($dest, $info['mime']); $ok = !is_wp_error($saved) && is_file($dest); }
            if (!$ok) { $refused++; continue; }
            $db->insert(self::t('photos'), array('entity' => $entity, 'entity_id' => (int) $id, 'file' => $file, 'caption' => $caption ?: null, 'created' => self::now()));
            $have++;
        }
        return $refused ? $refused . ' عکس پذیرفته نشد (فقط jpg/png/webp تا ۸ مگابایت و حداکثر ' . self::PHOTO_MAX . ' عکس)' : '';
    }

    private static function delete_photos($entity, $id)
    {
        $db = self::db(); if (!$db) { return; }
        foreach (self::photos($entity, $id) as $p) { @unlink(self::photo_dir() . '/' . $p['file'] . '.dat'); }
        $db->delete(self::t('photos'), array('entity' => $entity, 'entity_id' => (int) $id));
    }

    public static function act_photo_delete()
    {
        MZC_Admin::guard('photo_delete');
        $db = self::db(); $id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
        if ($db && ($p = $db->get_row($db->prepare('SELECT * FROM `' . self::t('photos') . '` WHERE id = %d', $id), ARRAY_A))) {
            @unlink(self::photo_dir() . '/' . $p['file'] . '.dat'); $db->delete(self::t('photos'), array('id' => $id));
            MZC_Admin::back($p['entity'] === 'job' ? 'mzc-jobs' : 'mzc-builds', 'ok:عکس پاک شد.', array('edit' => (int) $p['entity_id']));
        }
        MZC_Admin::back('mzc-builds', 'err:عکس پیدا نشد.');
    }

    /** Sends a stored photo's bytes (the caller has checked who may see it). */
    public static function send_photo($p)
    {
        $f = self::photo_dir() . '/' . basename((string) $p['file']) . '.dat';
        if (!is_readable($f)) { status_header(404); exit; }
        $ext = pathinfo((string) $p['file'], PATHINFO_EXTENSION);
        nocache_headers();
        header('Content-Type: ' . ($ext === 'png' ? 'image/png' : ($ext === 'webp' ? 'image/webp' : 'image/jpeg')));
        header('Content-Length: ' . filesize($f)); header('X-Content-Type-Options: nosniff'); header("Content-Security-Policy: default-src 'none'; sandbox"); header('Cache-Control: private, max-age=3600');
        readfile($f); exit;
    }

    public static function photo_row($id)
    {
        $db = self::db(); if (!$db) { return null; }
        return $db->get_row($db->prepare('SELECT * FROM `' . self::t('photos') . '` WHERE id = %d', (int) $id), ARRAY_A);
    }

    public static function act_photo()
    {
        if (!Mazesta_Connect::can()) { wp_die('اجازه ندارید.', '', array('response' => 403)); }
        $p = self::photo_row(isset($_GET['id']) ? (int) $_GET['id'] : 0);
        if (!$p) { status_header(404); exit; }
        self::send_photo($p);
    }

    /* ---------- reports from the app, for the forms' "attach the test report" ---------- */

    /** The reports the app sent, newest first, for a dropdown; those whose service number is $service come first. */
    public static function report_options($service = '')
    {
        $out = array();
        foreach (Mazesta_Connect::reports('', 300)[0] as $id => $r) {
            $label = trim(($r['service'] !== '' ? $r['service'] . ' — ' : '') . ($r['device'] !== '' ? $r['device'] : $r['machine']) . ' — ' . gmdate('Y/m/d', (int) strtotime($r['created'])));
            $out[(string) $id] = array('label' => $label . (isset(self::$stages[$r['stage']]) ? ' — ' . self::$stages[$r['stage']] : ''), 'match' => $service !== '' && $r['service'] === $service, 'stage' => $r['stage']);
        }
        uasort($out, function ($a, $b) { return (int) $b['match'] <=> (int) $a['match']; });
        return $out;
    }

    public static $stages = array('Before' => 'قبل از سرویس', 'After' => 'بعد از سرویس');

    /** A report the app marked before or after the service goes into that place of the service with its number: report_pre or report_id. */
    public static function attach_stage($service, $stage, $report_id)
    {
        $db = self::db(); if (!$db || !isset(self::$stages[$stage])) { return; }
        $col = $stage === 'Before' ? 'report_pre' : 'report_id';
        $db->query($db->prepare('UPDATE `' . self::t('jobs') . "` SET `$col` = %s, updated = %s WHERE service_no = %s", $report_id, self::now(), $service));
    }

    private static $outcomes = array('Passed' => 'موفق', 'Failed' => 'ناموفق', 'Cancelled' => 'لغو شد', 'Unsupported' => 'پشتیبانی نمی‌شود', 'Error' => 'خطای تست', 'Inconclusive' => 'نامعین');

    /**
     * The service's before and after reports side by side: each figure both reports have (a test's outcome, a part's peak temperature during a test,
     * a benchmark figure), with the change and whether it went the good way (1), the bad way (-1), stayed (0) or has no better side (null).
     * Nothing is made up: a figure only one report has is left out. Empty when either report has no figures (sent by an app before 0.15.15).
     */
    public static function compare($pre, $post)
    {
        $a = $pre ? Mazesta_Connect::report_figures($pre) : array(); $b = $post ? Mazesta_Connect::report_figures($post) : array(); $rows = array();
        $num = function ($v) { return $v === null ? '' : (floor($v) == $v ? number_format($v) : number_format($v, 1)); };
        foreach ($a as $k => $x) {
            if (!isset($b[$k])) { continue; } $y = $b[$k];
            if ($k[0] === 't') {
                if ($x['outcome'] === null || $y['outcome'] === null) { continue; }
                $good = $x['outcome'] === $y['outcome'] ? 0 : ($y['outcome'] === 'Passed' ? 1 : ($x['outcome'] === 'Passed' ? -1 : null));
                $rows[] = array('name' => $y['name'], 'before' => isset(self::$outcomes[$x['outcome']]) ? self::$outcomes[$x['outcome']] : $x['outcome'], 'after' => isset(self::$outcomes[$y['outcome']]) ? self::$outcomes[$y['outcome']] : $y['outcome'], 'change' => '', 'good' => $good, 'kind' => 'test');
                continue;
            }
            if ($x['value'] === null || $y['value'] === null) { continue; }
            $d = $y['value'] - $x['value']; $h = $y['higher']; $sign = $d > 0 ? '+' : ($d < 0 ? '−' : '');
            // within the sensors' and the runs' own spread (under 1 °C, a benchmark figure under 2%) no side is called better or worse: the numbers still show
            $still = $k[0] === 'p' ? abs($d) < 1 : ($x['value'] != 0 ? abs($d) / abs($x['value']) < 0.02 : abs($d) < 0.05);
            $good = $still ? 0 : ($h === null ? null : (($d > 0) === $h ? 1 : -1));
            $u = $y['unit'] !== '' ? ' ' . $y['unit'] : '';
            $rows[] = array('name' => $y['name'], 'before' => $num($x['value']) . $u, 'after' => $num($y['value']) . $u, 'change' => $sign . $num(abs($d)) . $u
                . ($x['value'] != 0 && $k[0] === 'b' ? ' (' . $sign . number_format(abs($d) / abs($x['value']) * 100, 1) . '%)' : ''), 'good' => $good, 'kind' => $k[0] === 'p' ? 'temp' : 'bench');
        }
        return $rows;
    }

    /* ---------- settings: the database and the SMS ---------- */

    public static function act_db_save()
    {
        MZC_Admin::guard('db_save', 'manage_options');
        $e = MZC_Crm_Db::save(self::post('host', 190) ?: 'localhost', self::post('name', 64), self::post('user', 64), isset($_POST['pass']) ? (string) wp_unslash($_POST['pass']) : '',
            preg_match('/^[A-Za-z0-9_]{1,20}$/', self::post('prefix', 20)) ? self::post('prefix', 20) : 'mz_');
        if ($e !== '') { MZC_Admin::back('mzc-settings', 'err:' . $e); }
        $e = MZC_Crm_Db::install();
        MZC_Admin::back('mzc-settings', $e === '' ? 'ok:اتصال برقرار شد و جدول‌ها آماده‌اند.' : 'err:' . $e);
    }

    /** Empties every CRM table (not the settings or the schema mark) so the old data can be imported again from nothing. Needs the site administrator and the typed word. */
    public static function act_db_wipe()
    {
        MZC_Admin::guard('db_wipe', 'manage_options');
        $db = self::db(); if (!$db) { MZC_Admin::back('mzc-settings', 'err:' . MZC_Crm_Db::error()); }
        if (self::post('confirm', 20) !== 'پاک‌کن') { MZC_Admin::back('mzc-settings', 'err:برای پاک کردن، کلمهٔ «پاک‌کن» را دقیق بنویسید.'); }
        foreach ((array) $db->get_col('SELECT file FROM `' . self::t('photos') . '`') as $f) { if (preg_match('/^[a-f0-9]{32}\.(jpg|png|webp)$/', (string) $f)) { @unlink(self::photo_dir() . '/' . $f . '.dat'); } }
        foreach (array('customers', 'builds', 'build_parts', 'jobs', 'job_parts', 'job_pays', 'job_calls', 'forms', 'shipments', 'vendors', 'oldmap', 'photos', 'otps', 'sessions', 'products', 'purchases', 'purchase_items', 'invoices', 'invoice_items', 'payments', 'cheques') as $tb) { $db->query('TRUNCATE TABLE `' . self::t($tb) . '`'); }
        $db->query('DELETE FROM `' . self::t('meta') . "` WHERE k = 'import'");
        MZC_Admin::back('mzc-settings', 'ok:همهٔ اطلاعات CRM پاک شد؛ فایل واردسازی را دوباره بارگذاری کنید.');
    }

    public static function act_db_install()
    {
        MZC_Admin::guard('db_install', 'manage_options');
        $e = MZC_Crm_Db::install();
        MZC_Admin::back('mzc-settings', $e === '' ? 'ok:جدول‌ها بررسی و آماده شد.' : 'err:' . $e);
    }

    public static function act_soft_save()
    {
        MZC_Admin::guard('soft_save');
        $k = isset($_POST['accounts']) ? 'accounts' : 'software';
        self::save_software_catalog(isset($_POST[$k]) ? sanitize_textarea_field(wp_unslash($_POST[$k])) : '', $k);
        MZC_Admin::back('mzc-settings', $k === 'accounts' ? 'ok:فهرست حساب‌ها ذخیره شد.' : 'ok:فهرست نرم‌افزارها ذخیره شد.');
    }

    public static function act_sms_save() { MZC_Sms::act_save(); }
    public static function act_sms_test() { MZC_Sms::act_test(); }
}
