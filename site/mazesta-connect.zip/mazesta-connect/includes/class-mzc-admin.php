<?php
if (!defined('ABSPATH')) { exit; }

/** The plugin's menus and the shell every admin page sits in (header, section links, notices), plus the small helpers the pages share. The pages themselves are admin/*.php. */
final class MZC_Admin
{
    private static $pages = array(
        'mzc-overview' => array('نمای کلی', 'overview'), 'mzc-installs' => array('نصب‌ها', 'installs'), 'mzc-systems' => array('سیستم‌ها', 'systems'), 'mzc-problems' => array('سیستم‌های مشکل‌دار', 'problems'), 'mzc-logkinds' => array('خلاصهٔ خطاهای لاگ', 'logkinds'), 'mzc-events' => array('رویدادها', 'events'), 'mzc-tuning' => array('آندرولت و اورکلاک', 'tuning'), 'mzc-messages' => array('پیام‌ها', 'messages'), 'mzc-access' => array('اشتراک و حساب‌ها', 'access'),
        'mzc-customers' => array('مشتریان', 'customers'), 'mzc-builds' => array('سیستم‌های نو', 'builds'), 'mzc-jobs' => array('سرویس‌ها', 'jobs'), 'mzc-acc' => array('حسابداری', 'acc'), 'mzc-report' => array('گزارش مالی و آمار', 'report'), 'mzc-stock' => array('انبار و کالاها', 'stock'), 'mzc-purchases' => array('فاکتورهای خرید', 'purchases'), 'mzc-ships' => array('ارسال به گارانتی', 'ships'), 'mzc-staff' => array('کاربران و دسترسی', 'staff'),
        'mazesta-connect' => array('گزارش‌ها و بنچمارک', null), 'mzc-settings' => array('تنظیمات', 'settings'),
    );

    /** The top bar: a few groups, each opening its first page; the pages of the open group show in a second row. Every page of $pages is in exactly one group. */
    private static $groups = array(
        'نمای کلی' => array('mzc-overview'),
        'سیستم‌ها' => array('mzc-systems', 'mzc-installs', 'mzc-problems', 'mzc-logkinds', 'mzc-events', 'mzc-tuning', 'mazesta-connect'),
        'مشتریان' => array('mzc-customers', 'mzc-messages', 'mzc-access', 'mzc-builds', 'mzc-jobs', 'mzc-ships'),
        'مالی و انبار' => array('mzc-acc', 'mzc-report', 'mzc-stock', 'mzc-purchases'),
        'مدیریت' => array('mzc-staff', 'mzc-settings'),
    );

    public static function boot()
    {
        add_action('admin_menu', array(__CLASS__, 'menu'));
        add_action('admin_enqueue_scripts', array(__CLASS__, 'assets'));
        add_action('admin_post_mzc_system_note', array(__CLASS__, 'act_system_note'));
        add_action('admin_post_mzc_cols_save', array(__CLASS__, 'act_cols_save'));
        add_action('admin_post_mzc_logs_export', array('MZC_Stats', 'act_logs_export'));
        MZC_Crm::boot();
    }

    public static function cap() { return class_exists('WooCommerce') ? 'manage_woocommerce' : 'manage_options'; }

    public static function menu()
    {
        add_menu_page('Mazesta', 'Mazesta', self::cap(), 'mzc-overview', array(__CLASS__, 'render'), 'dashicons-desktop', 58);
        foreach (self::$pages as $slug => $p) {
            add_submenu_page('mzc-overview', $p[0], $p[0], self::cap(), $slug, $p[1] === null ? array('Mazesta_Connect', 'page') : array(__CLASS__, 'render'));
        }
    }

    public static function assets($hook)
    {
        if (strpos((string) $hook, 'mzc-') === false && strpos((string) $hook, 'mazesta-connect') === false) { return; }
        wp_enqueue_style('mzc-admin', MZC_URL . 'assets/admin.css', array(), MZC_VERSION);
        wp_enqueue_script('mzc-admin', MZC_URL . 'assets/admin.js', array(), MZC_VERSION, true);
    }

    public static function render()
    {
        $slug = isset($_GET['page']) ? sanitize_key($_GET['page']) : 'mzc-overview';
        if (!Mazesta_Connect::can()) { wp_die('اجازه دیدن این صفحه را ندارید.', '', array('response' => 403)); }
        if (!isset(self::$pages[$slug]) || self::$pages[$slug][1] === null) { $slug = 'mzc-overview'; }
        self::open($slug, self::$pages[$slug][0]);
        require MZC_DIR . 'admin/' . self::$pages[$slug][1] . '.php';
        self::close();
    }

    /** The page's opening: the header, the section links, and a notice carried in the address (?mzc_msg=ok:… / err:…). */
    public static function open($slug, $title)
    {
        echo '<div class="mzc"><div class="mzc-head"><span class="mark">M</span><div><h1>Mazesta Connect</h1><div class="sub">سیستم‌ها، آمار، مشتریان و سرویس‌ها</div></div><span class="ver lat">v' . esc_html(MZC_VERSION) . '</span></div><nav class="mzc-nav">';
        $cur = '';
        foreach (self::$groups as $g => $slugs) {
            $on = in_array($slug, $slugs, true); if ($on) { $cur = $g; }
            echo '<a class="' . ($on ? 'on' : '') . '" href="' . esc_url(admin_url('admin.php?page=' . $slugs[0])) . '">' . esc_html($g) . '</a>';
        }
        echo '</nav>';
        if (count(self::$groups[$cur] ?? array()) > 1) {
            echo '<nav class="mzc-sub">';
            foreach (self::$groups[$cur] as $s) { echo '<a class="' . ($s === $slug ? 'on' : '') . '" href="' . esc_url(admin_url('admin.php?page=' . $s)) . '">' . esc_html(self::$pages[$s][0]) . '</a>'; }
            echo '</nav>';
        }
        if (!empty($_GET['mzc_msg'])) {
            $m = sanitize_text_field(wp_unslash($_GET['mzc_msg']));
            $kind = strpos($m, 'err:') === 0 ? 'err' : 'ok';
            echo '<div class="mzc-notice ' . $kind . '">' . esc_html(preg_replace('/^(ok|err):/', '', $m)) . '</div>';
        }
        if (!Mazesta_Connect::ensure()) { echo '<div class="mzc-notice err">پوشهٔ داده‌ها ساخته نشد: <code>' . esc_html(Mazesta_Connect::dir()) . '</code>. دسترسی نوشتن wp-content را بررسی کنید.</div>'; }
    }

    public static function close() { echo '</div>'; }

    public static function guard($action, $cap = '')
    {
        if (!Mazesta_Connect::can() || ($cap !== '' && !current_user_can($cap))) { wp_die('اجازه این کار را ندارید.', '', array('response' => 403)); }
        check_admin_referer('mzc_' . $action);
    }

    /** Back to a page with a notice ('ok:…' or 'err:…') and extra address arguments. */
    public static function back($slug, $msg = '', $args = array())
    {
        wp_safe_redirect(add_query_arg(array('page' => $slug, 'mzc_msg' => $msg) + $args, admin_url('admin.php')));
        exit;
    }

    public static function url($slug, $args = array()) { return add_query_arg(array('page' => $slug) + $args, admin_url('admin.php')); }
    public static function post_url($action, $args = array()) { return wp_nonce_url(add_query_arg(array('action' => 'mzc_' . $action) + $args, admin_url('admin-post.php')), 'mzc_' . $action); }

    public static function form_open($action, $extra = '')
    {
        return '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" ' . $extra . '><input type="hidden" name="action" value="mzc_' . esc_attr($action) . '">' . wp_nonce_field('mzc_' . $action, '_wpnonce', true, false);
    }

    /** The sections of an imported form that have no column of their own (checklists, benchmarks, software ...) as a folded list. */
    public static function more($more, $title = 'جزئیات فرم قدیمی')
    {
        if (!$more || !is_array($more)) { return ''; }
        $o = '<details class="mzc-more"><summary>' . esc_html($title) . '</summary><dl class="mzc-kv">';
        foreach ($more as $sec) {
            if (empty($sec['r'])) { continue; }
            foreach ($sec['r'] as $k => $v) { $o .= '<dt>' . esc_html($k) . '</dt><dd dir="auto">' . nl2br(esc_html(is_array($v) ? implode('، ', $v) : (string) $v)) . '</dd>'; }
        }
        return $o . '</dl></details>';
    }

    public static function pill($text, $kind = '') { return '<span class="mzc-pill ' . esc_attr($kind) . '">' . esc_html($text) . '</span>'; }

    /** "1405/07/18 14:32" in the site's time zone. */
    public static function when($ts)
    {
        if (!$ts) { return '—'; }
        return '<span class="num">' . esc_html(MZC_Crm::jtime($ts)) . '</span>';
    }

    public static function ago($ts)
    {
        if (!$ts) { return '—'; }
        $d = time() - $ts;
        if ($d < 90) { return 'همین حالا'; } if ($d < 3600) { return floor($d / 60) . ' دقیقه پیش'; } if ($d < 172800) { return floor($d / 3600) . ' ساعت پیش'; }
        return floor($d / 86400) . ' روز پیش';
    }

    public static function num($n, $d = 0) { return $n === null ? '—' : '<span class="num">' . esc_html(number_format_i18n((float) $n, $d)) . '</span>'; }

    public static function pager($total, $per, $paged, $args = array())
    {
        $pages = (int) ceil($total / $per);
        if ($pages < 2) { return ''; }
        $out = '<div class="mzc-pager">';
        $show = array_unique(array_merge(array(1, $pages), range(max(1, $paged - 2), min($pages, $paged + 2))));
        sort($show); $last = 0;
        foreach ($show as $p) {
            if ($last && $p > $last + 1) { $out .= '<span>…</span>'; }
            $out .= $p === $paged ? '<span class="cur">' . $p . '</span>' : '<a href="' . esc_url(add_query_arg($args + array('paged' => $p))) . '">' . $p . '</a>';
            $last = $p;
        }
        return $out . '</div>';
    }

    /** A bar list of (label => count). */
    public static function bars($rows, $empty = 'هنوز داده‌ای نیست.')
    {
        if (!$rows) { return '<p class="muted">' . esc_html($empty) . '</p>'; }
        $max = max($rows); $out = '<div class="mzc-bars">';
        foreach ($rows as $l => $c) { $out .= '<div class="r"><span class="l" title="' . esc_attr((string) $l) . '" dir="auto">' . esc_html((string) $l) . '</span><span class="t"><i style="width:' . (int) round($c / $max * 100) . '%"></i></span><span class="c num">' . esc_html(number_format_i18n($c)) . '</span></div>'; }
        return $out . '</div>';
    }

    public static function act_system_note()
    {
        self::guard('system_note');
        $id = isset($_POST['id']) ? (string) wp_unslash($_POST['id']) : '';
        $note = Mazesta_Connect::clip(isset($_POST['note']) ? wp_unslash($_POST['note']) : '', 300);
        MZC_Stats::set_note($id, $note);
        self::back('mzc-systems', 'ok:یادداشت ذخیره شد.', array('sys' => $id));
    }

    /** The CRM pages need the second database; says what is missing and returns false when it is not ready. */
    /* ---------- list tables with columns the user chooses (which ones, in what order; kept per user) ---------- */

    /** The keys of the columns to show: the user's saved choice (only keys the page still has), else the page's defaults. $defs = key => array(label, default?, cell callback, class). */
    public static function cols($page, $defs)
    {
        $saved = get_user_meta(get_current_user_id(), 'mzc_cols_' . $page, true); $keys = array();
        if (is_array($saved)) { foreach ($saved as $k) { if (is_string($k) && isset($defs[$k]) && !in_array($k, $keys, true)) { $keys[] = $k; } } }
        if (!$keys) { foreach ($defs as $k => $d) { if (!empty($d[1])) { $keys[] = $k; } } }
        return $keys;
    }

    /** The "columns" menu above a list: a tick and a position number for each column. */
    public static function cols_ui($page, $defs)
    {
        $cur = self::cols($page, $defs); $order = array_merge($cur, array_diff(array_keys($defs), $cur));
        $o = '<details class="mzc-cols"><summary class="mzc-btn sm">ستون‌ها</summary>' . self::form_open('cols_save') . '<input type="hidden" name="page_slug" value="' . esc_attr($page) . '"><div class="list">';
        foreach ($order as $i => $k) {
            $o .= '<div class="row"><label><input type="checkbox" name="show[' . esc_attr($k) . ']" value="1"' . checked(in_array($k, $cur, true), true, false) . '> ' . esc_html($defs[$k][0]) . '</label>'
                . '<input type="number" name="ord[' . esc_attr($k) . ']" value="' . (int) ($i + 1) . '" min="1" max="99" aria-label="ترتیب"></div>';
        }
        return $o . '</div><p><button class="mzc-btn primary sm">ذخیره</button> <button class="mzc-btn sm" name="reset" value="1">پیش‌فرض</button></p></form></details>';
    }

    public static function act_cols_save()
    {
        self::guard('cols_save');
        $page = isset($_POST['page_slug']) ? sanitize_key(wp_unslash($_POST['page_slug'])) : '';
        if (!isset(self::$pages[$page])) { wp_die('صفحه نامعتبر است.', '', array('response' => 400)); }
        $meta = 'mzc_cols_' . $page; $uid = get_current_user_id();
        if (!empty($_POST['reset'])) { delete_user_meta($uid, $meta); self::back($page, 'ok:ستون‌ها به حالت پیش‌فرض برگشت.'); }
        $show = isset($_POST['show']) && is_array($_POST['show']) ? array_keys($_POST['show']) : array();
        $ord = isset($_POST['ord']) && is_array($_POST['ord']) ? $_POST['ord'] : array(); $keys = array();
        foreach ($show as $k) { $k = sanitize_key((string) $k); if ($k !== '' && strlen($k) <= 24) { $keys[$k] = isset($ord[$k]) ? (int) $ord[$k] : 50; } }
        asort($keys);
        if ($keys) { update_user_meta($uid, $meta, array_slice(array_keys($keys), 0, 20)); self::back($page, 'ok:ستون‌ها ذخیره شد.'); }
        self::back($page, 'err:دست‌کم یک ستون را نگه دارید.');
    }

    /** The table of a list page. A cell callback returns escaped HTML; $link($row) is where a click on the row goes; $act($row), when given, a last cell of buttons that no column choice hides. */
    public static function table($page, $defs, $rows, $link, $empty, $act = null)
    {
        $keys = self::cols($page, $defs);
        $o = '<div class="mzc-panel"><div class="body flush mzc-scroll"><table class="mzc-table"><thead><tr>';
        foreach ($keys as $k) { $o .= '<th' . (!empty($defs[$k][3]) ? ' class="' . esc_attr($defs[$k][3]) . '"' : '') . '>' . esc_html($defs[$k][0]) . '</th>'; }
        $o .= ($act ? '<th></th>' : '') . '</tr></thead><tbody>';
        if (!$rows) { $o .= '<tr><td class="empty" colspan="' . (count($keys) + ($act ? 1 : 0)) . '">' . esc_html($empty) . '</td></tr>'; }
        foreach ($rows as $r) {
            $o .= '<tr class="click" data-href="' . esc_url($link($r)) . '">';
            foreach ($keys as $k) { $o .= '<td' . (!empty($defs[$k][3]) ? ' class="' . esc_attr($defs[$k][3]) . '"' : '') . '>' . call_user_func($defs[$k][2], $r) . '</td>'; }
            $o .= ($act ? '<td class="act">' . $act($r) . '</td>' : '') . '</tr>';
        }
        return $o . '</tbody></table></div></div>';
    }

    /** A link to the app's report for a list cell (opens in a tab; the row itself does not follow the click). */
    public static function report_link($id)
    {
        return $id ? '<a href="' . esc_url(admin_url('admin-post.php?action=mzc_report&id=' . rawurlencode((string) $id))) . '" target="_blank" rel="noopener" onclick="event.stopPropagation()">گزارش</a>' : '<span class="muted">—</span>';
    }

    public static function need_crm()
    {
        if (MZC_Crm_Db::ready()) { return true; }
        $e = MZC_Crm_Db::error();
        echo '<div class="mzc-notice warn">' . esc_html($e !== '' ? $e : 'جدول‌های CRM هنوز ساخته نشده‌اند.') . ' <a href="' . esc_url(self::url('mzc-settings')) . '">رفتن به تنظیمات</a></div>';
        return false;
    }

    /** A table of event rows (see MZC_Stats::row). */
    public static function events_table($rows, $withSystem = true, $installs = array())
    {
        $out = '<div class="mzc-scroll"><table class="mzc-table"><thead><tr><th>زمان</th>' . ($withSystem ? '<th>سیستم</th>' : '') . '<th>نوع</th><th>مورد</th><th>نتیجه</th><th>کارت گرافیک</th><th class="n">دما CPU / GPU</th><th class="n">فرکانس CPU / GPU</th><th class="n">FPS</th><th class="n">امتیاز / توان</th><th>توضیح</th></tr></thead><tbody>';
        if (!$rows) { $out .= '<tr><td class="empty" colspan="' . ($withSystem ? 11 : 10) . '">رویدادی پیدا نشد.</td></tr>'; }
        if ($withSystem && !$installs) { $installs = MZC_Stats::names(array_column($rows, 'id')); }
        $t = function ($v, $u) { return $v === null ? '—' : '<span class="num">' . esc_html(round($v) . $u) . '</span>'; };
        foreach ($rows as $r) {
            $pill = $r['result'] === '' ? '' : self::pill($r['result'], $r['ok'] === true ? 'ok' : ($r['ok'] === false ? 'bad' : ''));
            $sys = '';
            if ($withSystem) { $i = isset($installs[$r['id']]) ? $installs[$r['id']] : null; $sys = '<td><a href="' . esc_url(self::url('mzc-systems', array('sys' => $r['id']))) . '" dir="auto">' . esc_html($i ? MZC_Stats::label($i) : substr($r['id'], 0, 8)) . '</a></td>'; }
            $score = $r['score'] !== null ? '<span class="num">' . esc_html(number_format_i18n($r['score'], $r['score'] < 100 ? 1 : 0)) . '</span> <small class="muted">' . esc_html($r['scoreUnit']) . '</small>' : ($r['power'] !== null ? '<span class="num">' . esc_html(round($r['power'])) . ' W</span>' : '—');
            $json = wp_json_encode($r['d'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
            $out .= '<tr><td>' . self::when($r['ts']) . '</td>' . $sys . '<td>' . esc_html(MZC_Stats::kind_label($r['kind'])) . '</td><td dir="auto">' . esc_html($r['item']) . '</td><td>' . $pill . '</td><td dir="auto">' . esc_html($r['gpu'] !== '' ? $r['gpu'] : '—') . '</td>'
                . '<td class="n">' . $t($r['cpuTemp'], '°') . ' / ' . $t($r['gpuTemp'], '°') . '</td><td class="n">' . $t($r['cpuClock'], '') . ' / ' . $t($r['gpuClock'], '') . '</td>'
                . '<td class="n">' . ($r['fps'] !== null ? '<span class="num">' . esc_html(number_format_i18n($r['fps'], 1)) . '</span>' : '—') . '</td><td class="n">' . $score . '</td>'
                . '<td>' . ($r['note'] !== '' ? '<span dir="auto">' . esc_html(mb_substr($r['note'], 0, 160)) . '</span> ' : '') . '<details class="mzc-details"><summary>جزئیات</summary><pre>' . esc_html((string) $json) . '</pre></details></td></tr>';
        }
        return $out . '</tbody></table></div>';
    }

    /** The customer fields of a build or job form: the chosen customer, or a mobile (and name) that finds or makes one. $change: the chosen customer can be swapped (an invoice draft). */
    public static function customer_picker($customer = null, $prefill = '', $required = true, $change = false)
    {
        if ($customer && !$change) {
            return '<input type="hidden" name="customer_id" value="' . (int) $customer['id'] . '"><div class="mzc-field wide"><span>مشتری</span><div><strong>' . esc_html($customer['name']) . '</strong> <span class="num muted">' . esc_html($customer['mobile']) . '</span> '
                . '<a href="' . esc_url(self::url('mzc-customers', array('view' => (int) $customer['id']))) . '">پروندهٔ مشتری</a></div></div>';
        }
        // admin.js searches as one types the name or a number (any of the customer's numbers) and shows the closest customers under the box; picking one fills customer_id
        $picked = $customer ? ' data-mzc-picked="' . esc_attr(wp_json_encode(array('id' => (int) $customer['id'], 'name' => $customer['name'], 'mobiles' => MZC_Crm::mobiles_of($customer)))) . '"' : '';
        return '<div class="mzc-field wide mzc-cfind" data-mzc-cfind="' . esc_url(admin_url('admin-ajax.php?action=mzc_customer_find&n=' . wp_create_nonce('mzc_customer_find'))) . '"' . ($required ? ' data-mzc-req' : '') . $picked . '><input type="hidden" name="customer_id" value="">'
            . '<div class="mzc-fields"><label>نام مشتری<input type="text" name="c_name" maxlength="190" autocomplete="off" data-mzc-cq><small>با نوشتن نام یا موبایل، مشتری‌های ثبت‌شده زیر همین کادر می‌آیند.</small></label>'
            . '<label>موبایل مشتری<input type="text" name="c_mobile" dir="ltr" placeholder="09121234567" value="' . esc_attr($prefill) . '" autocomplete="off" data-mzc-cq' . ($required ? ' required' : '') . '></label>'
            . '<label>موبایل دوم (اختیاری)<input type="text" name="c_mobile2" dir="ltr" autocomplete="off"></label></div>'
            . '<div class="mzc-cpicked" hidden></div></div>';
    }

    /** The programs the customer wants installed (rows picked from the shop's list or typed freely) and their own request in words. */
    public static function soft_block($json)
    {
        $s = MZC_Crm::soft_out($json);
        $row = function ($n, $x) {
            return '<div class="mzc-row"><input type="text" name="soft[' . $n . '][name]" value="' . esc_attr($x['name']) . '" placeholder="نام نرم‌افزار (از فهرست یا نام تازه)" maxlength="80" list="mzc-soft" dir="auto">'
                . '<label class="chk"><input type="checkbox" name="soft[' . $n . '][done]" value="1"' . checked(!empty($x['done']), true, false) . '> نصب و اجرا شد</label><button type="button" class="mzc-btn sm danger x" data-mzc-remove>حذف</button></div>';
        };
        $o = '<div class="mzc-field wide"><span>نرم‌افزارهای درخواستی مشتری' . ($s['by_customer'] !== '' ? ' ' . self::pill('مشتری خودش پر کرده: ' . MZC_Crm::jdate($s['by_customer']), 'info') : '') . '</span><div class="mzc-rows" id="mzc-soft-rows" data-next="' . count($s['items']) . '">';
        foreach ($s['items'] as $n => $x) { $o .= $row($n, $x); }
        $o .= '</div><template id="mzc-soft-rows-tpl">' . str_replace('[0]', '[__N__]', $row(0, array('name' => '', 'done' => false))) . '</template><p><button type="button" class="mzc-btn" data-mzc-add="mzc-soft-rows">+ نرم‌افزار</button> <small class="muted">اگر در فهرست نیست، نامش را کامل بنویسید.</small></p>'
            . '<label>درخواست‌های نرم‌افزاری (توضیح)<textarea name="soft_note" rows="2" dir="auto">' . esc_textarea($s['note']) . '</textarea></label><datalist id="mzc-soft">';
        foreach (MZC_Crm::software_catalog() as $n) { $o .= '<option value="' . esc_attr($n) . '">'; }
        return $o . '</datalist></div>';
    }

    public static function soft_view($json)
    {
        $s = MZC_Crm::soft_out($json);
        if (!$s['items'] && $s['note'] === '') { return ''; }
        $o = '<div class="mzc-panel"><header><h3>نرم‌افزارهای درخواستی</h3>' . ($s['by_customer'] !== '' ? self::pill('مشتری خودش پر کرده: ' . MZC_Crm::jdate($s['by_customer']), 'info') : '') . '</header><div class="body"><p>';
        foreach ($s['items'] as $x) { $o .= self::pill($x['name'] . ($x['done'] ? ' ✓' : ''), $x['done'] ? 'ok' : '') . ' '; }
        return $o . '</p>' . ($s['note'] !== '' ? '<p dir="auto">' . nl2br(esc_html($s['note'])) . '</p>' : '') . '</div></div>';
    }

    /** $stage: which reports go first for a service's before or after field (the ones the app marked so); the field is report_pre for 'Before'. */
    public static function report_select($selected, $service = '', $stage = '')
    {
        $opts = MZC_Crm::report_options($service);
        if ($stage !== '') { uasort($opts, function ($a, $b) use ($stage) { return ((int) ($b['match'] && $b['stage'] === $stage)) <=> ((int) ($a['match'] && $a['stage'] === $stage)); }); }
        $title = $stage === 'Before' ? 'گزارش قبل از سرویس' : ($stage === 'After' ? 'گزارش بعد از سرویس' : 'گزارش تست برنامه');
        $out = '<label class="wide">' . $title . '<select name="' . ($stage === 'Before' ? 'report_pre' : 'report_id') . '"><option value="">— بدون گزارش —</option>';
        foreach ($opts as $id => $o) { $out .= '<option value="' . esc_attr($id) . '"' . selected($selected, $id, false) . '>' . esc_html(($o['match'] ? '★ ' : '') . $o['label']) . '</option>'; }
        return $out . '</select><small>گزارش‌هایی که با «ارسال به سایت» از برنامه رسیده‌اند. ★ یعنی شمارهٔ سرویسش با شمارهٔ این فرم یکی است.' . ($stage !== '' ? ' گزارشی که در برنامه «' . MZC_Crm::$stages[$stage] . '» علامت خورده باشد خودش اینجا می‌نشیند.' : '') . '</small></label>';
    }

    /** The app's hands-on checks of a service, before and after the work side by side; '' when none came. */
    public static function hands_panel($hands)
    {
        if (!$hands) { return ''; }
        $keys = array(); foreach ($hands as $s) { $keys += $s['items']; }
        $cell = function ($stage, $k) use ($hands) {
            if (!isset($hands[$stage]['items'][$k])) { return '<span class="muted">—</span>'; }
            $x = $hands[$stage]['items'][$k];
            return self::pill($x['verdict'] === 'ok' ? 'سالم' : 'مشکل دارد', $x['verdict'] === 'ok' ? 'ok' : 'bad') . ($x['note'] !== '' ? ' <span dir="auto">' . esc_html($x['note']) . '</span>' : '');
        };
        $when = function ($stage) use ($hands) { return isset($hands[$stage]['at']) ? ' <small class="muted">' . esc_html(MZC_Crm::jtime((int) strtotime($hands[$stage]['at'] . ' UTC'))) . '</small>' : ''; };
        $out = '<div class="mzc-panel"><header><h3>بررسی‌های دستی (از برنامه)</h3></header><div class="body flush mzc-scroll"><table class="mzc-table"><thead><tr><th>قسمت</th><th>قبل از سرویس' . $when('Before') . '</th><th>بعد از سرویس' . $when('After') . '</th></tr></thead><tbody>';
        foreach ($keys as $k => $x) { $out .= '<tr><td dir="auto">' . esc_html($x['name']) . '</td><td>' . $cell('Before', $k) . '</td><td>' . $cell('After', $k) . '</td></tr>'; }
        return $out . '</tbody></table></div></div>';
    }

    /** The calls to the customer about a service, oldest first, and the short form that adds one. */
    public static function calls_panel($j)
    {
        $out = '<div class="mzc-panel" id="mzc-calls"><header><h3>تماس با مشتری</h3>' . ($j['calls'] ? self::pill(count($j['calls']) . ' تماس') : '') . '</header><div class="body">';
        if ($j['calls']) {
            $out .= '<table class="mzc-table"><thead><tr><th>زمان</th><th>برای</th><th>نتیجه</th><th>توضیح</th><th>تماس‌گیرنده</th><th></th></tr></thead><tbody>';
            foreach ($j['calls'] as $c) {
                $reached = in_array($c['result'], MZC_Crm::$call_reached, true);
                $out .= '<tr><td class="num">' . esc_html(MZC_Crm::jtime((int) strtotime($c['at'] . ' UTC'))) . '</td><td>' . esc_html(isset(MZC_Crm::$call_reasons[$c['reason']]) ? MZC_Crm::$call_reasons[$c['reason']] : $c['reason']) . '</td>'
                    . '<td>' . self::pill(isset(MZC_Crm::$call_results[$c['result']]) ? MZC_Crm::$call_results[$c['result']] : $c['result'], $reached ? 'ok' : 'warn') . '</td><td dir="auto">' . esc_html((string) $c['note']) . '</td><td>' . esc_html((string) $c['who']) . '</td>'
                    . '<td><a class="mzc-btn sm danger" href="' . esc_url(self::post_url('job_call_delete', array('id' => (int) $c['id'], 'job' => (int) $j['id']))) . '" onclick="return confirm(\'این تماس پاک شود؟\')">حذف</a></td></tr>';
            }
            $out .= '</tbody></table>';
        } else { $out .= '<p class="muted">هنوز تماسی ثبت نشده است.</p>'; }
        $opt = function ($list, $pick) { $o = ''; foreach ($list as $k => $l) { $o .= '<option value="' . esc_attr($k) . '"' . selected($pick, $k, false) . '>' . esc_html($l) . '</option>'; } return $o; };
        $reason = in_array($j['status'], array('ready', 'delivered'), true) ? 'ready' : 'quote';
        $out .= self::form_open('job_call', 'class="mzc-form mzc-call"') . '<input type="hidden" name="id" value="' . (int) $j['id'] . '"><div class="mzc-fields">'
            . '<label>برای<select name="reason">' . $opt(MZC_Crm::$call_reasons, $reason) . '</select></label>'
            . '<label>نتیجهٔ تماس<select name="result" required><option value="">— انتخاب کنید —</option>' . $opt(MZC_Crm::$call_results, '') . '</select></label>'
            . '<label class="wide">توضیح (چه گفته شد، چه قراری گذاشته شد)<input type="text" name="note" maxlength="500"></label></div><p><button class="mzc-btn primary">ثبت تماس</button></p></form>';
        return $out . '</div></div>';
    }

    /** The before/after table of a service (MZC_Crm::compare), or '' when the two reports have no figures in common. */
    public static function compare_panel($pre, $post)
    {
        $rows = $pre && $post ? MZC_Crm::compare($pre, $post) : array();
        if (!$rows) { return ''; }
        $out = '<div class="mzc-panel"><header><h3>مقایسهٔ قبل و بعد از سرویس</h3></header><div class="body flush mzc-scroll"><table class="mzc-table"><thead><tr><th>مورد</th><th class="n">قبل</th><th class="n">بعد</th><th class="n">تغییر</th></tr></thead><tbody>';
        foreach ($rows as $r) {
            $mark = $r['good'] === 1 ? ' ' . self::pill('بهتر', 'ok') : ($r['good'] === -1 ? ' ' . self::pill('بدتر', 'bad') : '');
            $out .= '<tr><td dir="auto">' . esc_html($r['name']) . '</td><td class="n" dir="auto">' . esc_html($r['before']) . '</td><td class="n" dir="auto">' . esc_html($r['after']) . '</td><td class="n"><span dir="ltr">' . esc_html($r['change']) . '</span>' . $mark . '</td></tr>';
        }
        return $out . '</tbody></table></div></div>';
    }

    /** Where a part row's name box ([data-mzc-pq]) searches the stock as one types; admin.js shows the products (stock, price) under the box and fills the row's id, category and prices from the chosen one. */
    public static function product_list()
    {
        return '<span id="mzc-products" hidden data-url="' . esc_url(admin_url('admin-ajax.php?action=mzc_product_find&n=' . wp_create_nonce('mzc_product_find'))) . '"></span>';
    }

    /** The device-type choice and the Telegram links of a build or job form. */
    public static function device_select($cur, $none = false)
    {
        $o = '<label>نوع دستگاه<select name="device_type">' . ($none ? '<option value="">—</option>' : '');
        foreach (MZC_Crm::$device_types as $k => $l) { $o .= '<option value="' . esc_attr($k) . '"' . selected((string) $cur, $k, false) . '>' . esc_html($l) . '</option>'; }
        return $o . '</select></label>';
    }

    /** The tick lists of the form, one set per device type (admin.js shows the chosen type's); the save keeps only that type's ticks. No $recvTitle: only the checks (a new computer receives nothing). */
    public static function checks_field($json, $recvTitle = null)
    {
        $c = MZC_Crm::checks_out($json); $o = '';
        foreach (array_filter(array('recv' => $recvTitle, 'check' => 'چک کلی')) as $l => $title) {
            $o .= '<div class="mzc-field wide"><span>' . esc_html($title) . '</span>';
            foreach (MZC_Crm::$checklists[$l] as $type => $items) {
                $o .= '<div class="mzc-checks" data-mzc-dtype="' . esc_attr($type) . '">';
                foreach ($items as $k => $label) { $o .= '<label class="chk"><input type="checkbox" name="checks[' . $l . '][]" value="' . esc_attr($k) . '"' . checked(in_array($k, $c[$l], true), true, false) . '> <span dir="auto">' . esc_html($label) . '</span></label>'; }
                $o .= '</div>';
            }
            $o .= '</div>';
        }
        return $o . ($recvTitle ? '<label class="wide">توضیحات لوازم دریافتی<textarea name="checks[note]" rows="2">' . esc_textarea($c['note']) . '</textarea></label>' : '');
    }

    /** The ticks of a record for its page: each list of its device type with ✓ or ✗. */
    public static function checks_view($json, $type, $recvTitle = null)
    {
        $c = MZC_Crm::checks_out($json); $o = '';
        foreach (array_filter(array('recv' => $recvTitle, 'check' => 'چک کلی')) as $l => $title) {
            if (!isset(MZC_Crm::$checklists[$l][$type])) { continue; }
            $o .= '<h4>' . esc_html($title) . '</h4><p class="mzc-checks">';
            foreach (MZC_Crm::$checklists[$l][$type] as $k => $label) { $on = in_array($k, $c[$l], true); $o .= self::pill(($on ? '✓ ' : '✗ ') . $label, $on ? 'ok' : '') . ' '; }
            $o .= '</p>';
        }
        if ($c['note'] !== '') { $o .= '<p dir="auto">' . nl2br(esc_html($c['note'])) . '</p>'; }
        return $o === '' ? '' : '<div class="mzc-panel"><header><h3>چک‌لیست</h3></header><div class="body">' . $o . '</div></div>';
    }

    public static function media_field($media)
    {
        return '<label class="wide">لینک عکس‌ها و فیلم‌ها در تلگرام<textarea name="media" rows="2" dir="ltr" placeholder="https://t.me/…  (هر لینک در یک خط)">' . esc_textarea((string) $media) . '</textarea><small>پست‌های کانال تلگرام همین سیستم یا سرویس.</small></label>';
    }

    public static function media_links($media)
    {
        $l = MZC_Crm::media_list((string) $media);
        return $l ? implode(' · ', array_map(function ($u, $i) { return '<a href="' . esc_url($u) . '" target="_blank" rel="noopener noreferrer">لینک ' . ($i + 1) . '</a>'; }, $l, array_keys($l))) : '—';
    }

    public static function photos_block($photos)
    {
        $out = '<div class="mzc-field wide"><span>عکس‌ها (تا ' . MZC_Crm::PHOTO_MAX . ' عکس؛ jpg / png / webp)</span>';
        if ($photos) {
            $out .= '<div class="mzc-photos">';
            foreach ($photos as $p) {
                $src = admin_url('admin-post.php?action=mzc_photo&id=' . (int) $p['id']);
                $out .= '<figure><a href="' . esc_url($src) . '" target="_blank"><img loading="lazy" src="' . esc_url($src) . '" alt=""></a>'
                    . '<a class="mzc-btn sm danger" href="' . esc_url(self::post_url('photo_delete', array('id' => (int) $p['id']))) . '" onclick="return confirm(\'این عکس پاک شود؟\')">پاک</a></figure>';
            }
            $out .= '</div>';
        }
        return $out . '<input type="file" name="photos[]" accept="image/jpeg,image/png,image/webp" multiple><input type="text" name="photo_caption" placeholder="توضیح کوتاه برای عکس‌های تازه (اختیاری)" maxlength="190"></div>';
    }
}
