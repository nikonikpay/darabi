<?php
if (!defined('ABSPATH')) { exit; }

/**
 * Everything the desktop app says to the site goes through this plugin's REST routes (namespace mazesta/v1):
 *   GET  status                 is the plugin there, and is this key the shop's
 *   POST pair/start, pair/claim connects a copy of the app without typing the key: a manager signed in to the site approves the request
 *   POST reports                a report's one-page summary (key)          -> kept, listed and printed in the dashboard
 *   POST bench/runs             benchmark runs (key; or without one into the review queue when the shop allows it)
 *   POST share                  a user's latest benchmark results (no key) -> a page of their own, with a link to pass on
 *   POST usage                  anonymous usage statistics (no key; the app's settings switch, on by default): a random install id, part names and events - counted in the dashboard's "آمار استفاده" tab
 *   GET  bench/index, benchdb/* the comparison lists built from the approved runs, one file per benchmark, version and settings; each says whether it is of an old workload
 *        (a newer version of the benchmark has approved runs: its numbers are not comparable with today's). A shared result of an old benchmark or app version carries a notice on its page.
 *   POST release/chunk, commit  the signed update folder (release key)     -> written to /mazesta/ in the site's root, where the app reads it
 * The lists are built the way the app builds them (BenchmarkPeers.Aggregate): one row per part model, the median of each system's best run.
 *
 * Nothing is kept in WordPress' database: no table, no option, no role change. The data is in the CRM's own database (MZC_Crm_Db; a table per
 * kind: bench_runs, bench_names, shares, share_rows, pairs, limits, and MZC_Stats' and MZC_Messages' tables). Files in wp-content/mazesta-connect-data:
 * config.php (the keys and that database's connection, which cannot be kept in the database it opens), the test reports (reports.php, report-*.php:
 * the shop wants them as uploaded files) and the built comparison lists (benchdb/). Each .php there begins with a line of PHP that ends the request,
 * so asking the web server for it returns nothing.
 * Until the CRM's database is set up on the settings page, whatever needs it answers 503.
 */
final class Mazesta_Connect
{
    const VERSION = MZC_VERSION;
    const NS = 'mazesta/v1';
    const MAX_HTML = 800000;
    const MAX_FULL = 3000000;
    const MAX_RUNS = 500;
    const MAX_SHARES = 5000;
    const GUARD = "<?php exit; ?>\n";

    public static function boot()
    {
        add_action('rest_api_init', array(__CLASS__, 'routes'));
        add_action('init', array(__CLASS__, 'public_pages'));
        foreach (array('pair_approve', 'report', 'report_delete', 'run_approve', 'run_delete', 'run_feature', 'list_delete', 'share_delete', 'share_add', 'settings', 'rebuild') as $a) {
            add_action('admin_post_mzc_' . $a, array(__CLASS__, 'act_' . $a));
        }
    }

    /* ---------- storage: the CRM's database; config.php is the one data file ---------- */

    /** The CRM database's wpdb once its tables are there, else null. */
    public static function db() { return MZC_Crm_Db::ready() ? MZC_Crm_Db::db() : null; }
    public static function t($n) { return MZC_Crm_Db::t($n); }
    public static function no_db() { return new WP_Error('mazesta_db', 'The site database is not reachable; try again later.', array('status' => 503)); }
    /** A DATETIME (UTC) as ISO 8601, the form the pages and the app read. */
    public static function iso($dt) { return $dt ? str_replace(' ', 'T', (string) $dt) . 'Z' : ''; }

    public static function dir() { return WP_CONTENT_DIR . '/mazesta-connect-data'; }

    public static function ensure()
    {
        $d = self::dir();
        if (is_dir($d . '/benchdb')) { return true; }
        if (!wp_mkdir_p($d . '/benchdb')) { return false; }
        @file_put_contents($d . '/.htaccess', "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
        @file_put_contents($d . '/index.php', "<?php // nothing here\n");
        return true;
    }

    public static function file($name) { return self::dir() . '/' . $name . '.php'; }

    /** A data file's content after its guard line, or null when there is none. */
    public static function raw($name)
    {
        $f = self::file($name);
        if (!is_readable($f)) { return null; }
        $s = (string) file_get_contents($f);
        return strncmp($s, self::GUARD, strlen(self::GUARD)) === 0 ? substr($s, strlen(self::GUARD)) : null;
    }

    public static function read($name, $default = array())
    {
        $s = self::raw($name);
        $v = $s === null ? null : json_decode($s, true);
        return is_array($v) ? $v : $default;
    }

    public static function put($name, $text)
    {
        if (!self::ensure()) { return false; }
        $f = self::file($name); $tmp = $f . '.' . bin2hex(random_bytes(4)) . '.tmp';
        if (file_put_contents($tmp, self::GUARD . $text) === false) { return false; }
        if (!@rename($tmp, $f)) { @unlink($tmp); return false; }
        return true;
    }

    public static function remove($name) { $f = self::file($name); if (is_file($f)) { @unlink($f); } }

    public static function write($name, $data)
    {
        $json = wp_json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        return $json !== false && self::put($name, $json);
    }

    /** Runs $work while holding the data folder's lock, so two uploads at once do not write over each other. */
    public static function locked($work)
    {
        if (!self::ensure()) { return $work(); }
        $h = @fopen(self::dir() . '/.lock', 'c');
        if ($h) { flock($h, LOCK_EX); }
        try { return $work(); }
        finally { if ($h) { flock($h, LOCK_UN); fclose($h); } }
    }

    private static function new_key() { return 'mz_' . bin2hex(random_bytes(24)); }

    /** The settings and the two keys; made on first use. */
    public static function config()
    {
        static $c = null;
        if ($c !== null) { return $c; }
        $c = self::read('config', array());
        if (empty($c['key']) || empty($c['releaseKey']) || empty($c['readKey'])) {
            $c = self::locked(function () {
                $c = self::read('config', array());
                if (empty($c['key'])) { $c['key'] = self::new_key(); }
                if (empty($c['releaseKey'])) { $c['releaseKey'] = self::new_key(); }
                if (empty($c['readKey'])) { $c['readKey'] = self::new_key(); }
                $c += array('openUploads' => false, 'publicLinks' => false, 'sharing' => true);
                self::write('config', $c);
                return $c;
            });
        }
        $c += array('openUploads' => false, 'publicLinks' => false, 'sharing' => true);
        return $c;
    }

    public static function can() { return current_user_can('manage_woocommerce') || current_user_can('manage_options'); }

    /** At most $max calls an hour from one address. */
    public static function allowed($bucket, $max)
    {
        return self::hit($bucket . ':' . md5(self::client_ip())) <= $max;
    }

    /** The headers a CDN in front of the site may carry the visitor's address in. */
    public static $ip_headers = array('HTTP_AR_REAL_IP' => 'AR-Real-IP (ابرآروان)', 'HTTP_X_REAL_IP' => 'X-Real-IP', 'HTTP_CF_CONNECTING_IP' => 'CF-Connecting-IP (Cloudflare)');

    /**
     * The visitor's address. Behind a CDN whose server does not put it in REMOTE_ADDR, every visitor looks like the CDN and one hourly limit is shared by everybody; the site
     * administrator then names the CDN's header on the settings page. Never guessed: a header anyone can send would let one visitor pass for any number of others.
     */
    public static function client_ip()
    {
        $c = self::read('config'); $h = isset($c['ipHeader']) ? (string) $c['ipHeader'] : '';
        if (isset(self::$ip_headers[$h], $_SERVER[$h]) && filter_var($_SERVER[$h], FILTER_VALIDATE_IP)) { return (string) $_SERVER[$h]; }
        return isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '';
    }

    /**
     * A counter of the current window of $per seconds (the limits table): $add is added, the count returned. Without the database nothing is counted (0): what the
     * counter guards needs the database too and answers 503 then.
     */
    public static function hit($slot, $per = 3600, $add = 1)
    {
        $db = self::db(); if (!$db) { return 0; }
        $tb = self::t('limits'); $win = ((int) floor(time() / $per) + 1) * $per;   // the window's end, so windows of any length are cleared alike
        if ($add) { $db->query($db->prepare("INSERT INTO `$tb` (slot, win, n) VALUES (%s, %d, %d) ON DUPLICATE KEY UPDATE n = n + %d", $slot, $win, $add, $add)); }
        if (mt_rand(1, 200) === 1) { $db->query($db->prepare("DELETE FROM `$tb` WHERE win < %d LIMIT 5000", time())); }
        return (int) $db->get_var($db->prepare("SELECT n FROM `$tb` WHERE slot = %s AND win = %d", $slot, $win));
    }

    public static function unhit($slot) { $db = self::db(); if ($db) { $db->delete(self::t('limits'), array('slot' => $slot)); } }

    /* ---------- REST ---------- */

    public static function routes()
    {
        $open = '__return_true';
        register_rest_route(self::NS, '/status', array('methods' => 'GET', 'callback' => array(__CLASS__, 'rest_status'), 'permission_callback' => $open));
        register_rest_route(self::NS, '/reports', array(
            array('methods' => 'POST', 'callback' => array(__CLASS__, 'rest_report'), 'permission_callback' => array(__CLASS__, 'need_key')),
            array('methods' => 'GET', 'callback' => array(__CLASS__, 'rest_report_list'), 'permission_callback' => array(__CLASS__, 'need_read_key')),
        ));
        register_rest_route(self::NS, '/reports/(?P<id>[A-Za-z0-9-]{8,64})', array('methods' => 'GET', 'callback' => array(__CLASS__, 'rest_report_get'), 'permission_callback' => array(__CLASS__, 'need_read_key')));
        register_rest_route(self::NS, '/checks', array('methods' => 'POST', 'callback' => array(__CLASS__, 'rest_checks'), 'permission_callback' => array(__CLASS__, 'need_key')));
        register_rest_route(self::NS, '/featured', array('methods' => 'GET', 'callback' => array(__CLASS__, 'rest_featured'), 'permission_callback' => $open));
        register_rest_route(self::NS, '/bench/runs', array('methods' => 'POST', 'callback' => array(__CLASS__, 'rest_runs'), 'permission_callback' => $open));
        register_rest_route(self::NS, '/usage', array('methods' => 'POST', 'callback' => array(__CLASS__, 'rest_usage'), 'permission_callback' => $open));
        register_rest_route(self::NS, '/logs', array('methods' => 'POST', 'callback' => array(__CLASS__, 'rest_logs'), 'permission_callback' => $open));
        register_rest_route(self::NS, '/share', array('methods' => 'POST', 'callback' => array(__CLASS__, 'rest_share'), 'permission_callback' => $open));
        register_rest_route(self::NS, '/pair/start', array('methods' => 'POST', 'callback' => array(__CLASS__, 'rest_pair_start'), 'permission_callback' => $open));
        register_rest_route(self::NS, '/pair/claim', array('methods' => 'POST', 'callback' => array(__CLASS__, 'rest_pair_claim'), 'permission_callback' => $open));
        register_rest_route(self::NS, '/bench/index', array('methods' => 'GET', 'callback' => array(__CLASS__, 'rest_index'), 'permission_callback' => $open));
        // No @ in this pattern: WordPress wraps a route in @…@ to match it, and one inside ends the pattern early.
        register_rest_route(self::NS, '/benchdb/(?P<file>[A-Za-z0-9][A-Za-z0-9._=-]*\.json)', array('methods' => 'GET', 'callback' => array(__CLASS__, 'rest_list'), 'permission_callback' => $open));
        register_rest_route(self::NS, '/release/chunk', array('methods' => 'POST', 'callback' => array(__CLASS__, 'rest_chunk'), 'permission_callback' => array(__CLASS__, 'need_release_key')));
        register_rest_route(self::NS, '/release/commit', array('methods' => 'POST', 'callback' => array(__CLASS__, 'rest_commit'), 'permission_callback' => array(__CLASS__, 'need_release_key')));
    }

    private static function key_state($req, $which = 'key')
    {
        $given = (string) $req->get_header('x_mazesta_key');
        if ($given === '') { return 'missing'; }
        $c = self::config();
        $want = isset($c[$which]) ? (string) $c[$which] : '';
        return $want !== '' && hash_equals($want, $given) ? 'ok' : 'wrong';
    }

    public static function need_key($req)
    {
        return self::key_state($req) === 'ok' ? true : new WP_Error('mazesta_key', 'The site key is missing or wrong.', array('status' => 401));
    }

    /** The reading key (the print program on the secretary's computer) or the site key: both may read the reports, only the site key may send them. */
    public static function need_read_key($req)
    {
        return self::key_state($req, 'readKey') === 'ok' || self::key_state($req) === 'ok' ? true : new WP_Error('mazesta_key', 'The key is missing or wrong.', array('status' => 401));
    }

    public static function need_release_key($req)
    {
        return self::key_state($req, 'releaseKey') === 'ok' ? true : new WP_Error('mazesta_key', 'The release key is missing or wrong.', array('status' => 401));
    }

    /** Answers that must never come from a cache (the page cache also caches REST answers). */
    public static function fresh($data, $status = 200)
    {
        $res = new WP_REST_Response($data, $status);
        $res->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
        $res->header('X-Content-Type-Options', 'nosniff');
        $res->header('X-LiteSpeed-Cache-Control', 'no-cache');
        return $res;
    }

    /** The shop's products on special sale now (WooCommerce's own "on sale" flag), for the app's dashboard. Public data only; the Store API of this site answers 500, hence this. */
    public static function rest_featured($req)
    {
        $out = array();
        if (function_exists('wc_get_product_ids_on_sale')) {
            foreach (array_slice((array) wc_get_product_ids_on_sale(), 0, 30) as $id) {
                $p = wc_get_product($id);
                if (!$p || $p->get_status() !== 'publish' || !$p->is_in_stock()) { continue; }
                $img = $p->get_image_id() ? wp_get_attachment_image_url($p->get_image_id(), 'medium_large') : '';
                $out[] = array('id' => (int) $id, 'title' => wp_strip_all_tags($p->get_name()), 'summary' => wp_strip_all_tags($p->get_short_description()), 'link' => get_permalink($id), 'image' => $img ? $img : null);
            }
        }
        return rest_ensure_response($out);
    }

    public static function rest_status($req)
    {
        $key = self::key_state($req); $c = self::config();
        $out = array('name' => 'Mazesta Connect', 'version' => self::VERSION, 'key' => $key, 'openUploads' => !empty($c['openUploads']), 'sharing' => !empty($c['sharing']),
            'benchmarkVersions' => (object) self::latest_versions(), 'appVersion' => self::latest_app());
        if ($key === 'ok' && ($db = self::db())) {
            $n = $db->get_row('SELECT SUM(approved = 1) AS a, SUM(approved = 0) AS p FROM `' . self::t('bench_runs') . '`', ARRAY_A);
            $out['reports'] = count(self::read('reports')); $out['runs'] = (int) $n['a']; $out['pending'] = (int) $n['p'];
        }
        return self::fresh($out);
    }

    /* ---------- connecting a copy of the app without typing the key ---------- */

    const PAIR_SECONDS = 600;

    /** An open request (younger than ten minutes) by its id, or null. */
    private static function pair($id)
    {
        $db = self::db(); if (!$db) { return null; }
        return $db->get_row($db->prepare('SELECT * FROM `' . self::t('pairs') . '` WHERE id = %s AND created > %d', $id, time() - self::PAIR_SECONDS), ARRAY_A);
    }

    /**
     * A copy of the app asks to be connected. It keeps a random secret to itself and sends only the secret's SHA-256 ($id); the answer is the
     * dashboard page where someone signed in to the site with the right to manage the shop sees the request (the computer's name and a short
     * code the app shows too) and approves it. Nothing is given out here.
     */
    public static function rest_pair_start($req)
    {
        if (!self::allowed('pair', 10)) { return new WP_Error('mazesta_busy', 'Too many requests from this address; try again in an hour.', array('status' => 429)); }
        $p = $req->get_json_params();
        $id = isset($p['id']) && is_string($p['id']) ? strtolower($p['id']) : '';
        if (!preg_match('/^[0-9a-f]{64}$/', $id)) { return new WP_Error('mazesta_pair', 'Not a valid request.', array('status' => 400)); }
        $name = self::text(isset($p['name']) ? $p['name'] : '', 60);
        $db = self::db(); if (!$db) { return self::no_db(); }
        $tb = self::t('pairs'); $db->query($db->prepare("DELETE FROM `$tb` WHERE created <= %d", time() - self::PAIR_SECONDS));
        $ok = (int) $db->get_var("SELECT COUNT(*) FROM `$tb`") < 50 || self::pair($id);
        if ($ok) { $db->replace($tb, array('id' => $id, 'name' => $name, 'approved' => 0, 'created' => time())); }
        if (!$ok) { return new WP_Error('mazesta_busy', 'Too many open requests; try again in a few minutes.', array('status' => 429)); }
        return self::fresh(array('url' => admin_url('admin.php?page=mazesta-connect&pair=' . $id), 'code' => strtoupper(substr($id, 0, 6)), 'seconds' => self::PAIR_SECONDS));
    }

    /** The app asks whether its request was approved, proving it is the one that asked by giving the secret. The key is handed over once; the request is then gone. */
    public static function rest_pair_claim($req)
    {
        if (!self::allowed('claim', 600)) { return new WP_Error('mazesta_busy', 'Too many requests from this address.', array('status' => 429)); }
        $p = $req->get_json_params();
        $secret = isset($p['secret']) && is_string($p['secret']) ? $p['secret'] : '';
        if (!preg_match('/^[0-9a-f]{64}$/', $secret)) { return new WP_Error('mazesta_pair', 'Not a valid request.', array('status' => 400)); }
        $id = hash('sha256', $secret);
        $p = self::pair($id);
        // the delete is what hands the key over: of two claims at once only the one that deleted the row gets it
        $state = !$p ? 'gone' : (empty($p['approved']) ? 'waiting' : (self::db()->delete(self::t('pairs'), array('id' => $id)) ? 'ok' : 'gone'));
        if ($state !== 'ok') { return self::fresh(array('state' => $state)); }
        $c = self::config();
        return self::fresh(array('state' => 'ok', 'key' => (string) $c['key']));
    }

    public static function act_pair_approve()
    {
        self::guard('pair_approve');
        $id = self::arg('id'); $yes = empty($_GET['no']);
        if (self::pair($id)) { if ($yes) { self::db()->update(self::t('pairs'), array('approved' => 1), array('id' => $id)); } else { self::db()->delete(self::t('pairs'), array('id' => $id)); } }
        self::back('settings', $yes ? 'paired' : 'refused');
    }

    /** The request named in the address, for the signed-in manager to approve or refuse. */
    public static function pair_panel($id)
    {
        $p = preg_match('/^[0-9a-f]{64}$/', $id) ? self::pair($id) : null;
        if (!$p) {
            echo '<div class="notice notice-warning"><p>این درخواست اتصال پیدا نشد یا مهلت ده‌دقیقه‌ای آن گذشته است. در برنامه دوباره «اتصال با ورود به سایت» را بزنید.</p></div>';
            return;
        }
        echo '<div class="notice notice-info mzc-pair"><h2 class="mzc-mt0">یک نسخه از برنامه Mazesta Test می‌خواهد به سایت وصل شود</h2>'
            . '<p>نام سیستم: <strong dir="ltr">' . esc_html($p['name'] !== '' ? $p['name'] : '—') . '</strong> · کد: <strong dir="ltr" class="mzc-code-big">' . esc_html(strtoupper(substr($id, 0, 6))) . '</strong></p>'
            . '<p>فقط وقتی تأیید کنید که همین کد را الان در برنامه خودتان می‌بینید. با تأیید، کلید سایت به آن برنامه داده می‌شود و می‌تواند گزارش و نتیجه بنچمارک بفرستد.</p>';
        if (!empty($p['approved'])) { echo '<p><strong>تأیید شده است؛ برنامه تا چند ثانیه دیگر وصل می‌شود.</strong></p>'; }
        else {
            echo '<p>' . self::post_link('pair_approve', array('id' => $id), 'تأیید و اتصال', 'button button-primary') . ' ' . self::post_link('pair_approve', array('id' => $id, 'no' => 1), 'رد کردن', 'button') . '</p>';
        }
        echo '</div>';
    }

    /** A time as ISO 8601 in UTC; now when it does not read as one. */
    public static function when($iso)
    {
        $ts = is_string($iso) ? strtotime($iso) : false;
        return gmdate('Y-m-d\TH:i:s\Z', $ts ? $ts : time());
    }

    public static function clip($s, $n) { return is_string($s) ? mb_substr(trim(wp_strip_all_tags($s)), 0, $n) : ''; }

    public static function rest_report($req)
    {
        $p = $req->get_json_params();
        $id = isset($p['id']) ? (string) $p['id'] : '';
        $html = isset($p['html']) ? (string) $p['html'] : '';
        $full = isset($p['full']) ? (string) $p['full'] : '';   // the whole report, beside its one-page summary (optional: older apps send the summary only)
        if (!preg_match('/^[A-Za-z0-9-]{8,64}$/', $id)) { return new WP_Error('mazesta_report', 'The report id is not valid.', array('status' => 400)); }
        if ($html === '' || strlen($html) > self::MAX_HTML) { return new WP_Error('mazesta_report', 'The summary is missing or too large.', array('status' => 400)); }
        // The page is kept as it came; it is only ever sent out under a policy that lets nothing in it run (see show_report). A "<?php" in it
        // would be read by PHP only if the file were run, which its first line prevents.
        $row = array(
            'title' => self::clip(isset($p['title']) ? $p['title'] : '', 255),
            'machine' => self::clip(isset($p['machine']) ? $p['machine'] : '', 190),
            'service' => self::clip(isset($p['service']) ? $p['service'] : '', 190),
            'device' => self::clip(isset($p['device']) ? $p['device'] : '', 190),   // the maker and model Windows names (System Information), as the app read it
            'laptop' => !empty($p['laptop']) ? '1' : '',
            'notes' => self::clip(isset($p['notes']) ? $p['notes'] : '', 4000),   // the work done on the computer, as the technician wrote it
            'stage' => isset($p['stage']) && in_array($p['stage'], array('Before', 'After'), true) ? $p['stage'] : '',   // the test before the service or the one after it
            'verdict' => self::clip(isset($p['verdict']) ? $p['verdict'] : '', 40),
            'kind' => self::clip(isset($p['kind']) ? $p['kind'] : '', 40),
            'summary' => self::clip(isset($p['summary']) ? $p['summary'] : '', 2000),
            'app' => self::clip(isset($p['appVersion']) ? $p['appVersion'] : '', 40),
            'created' => self::when(isset($p['created']) ? $p['created'] : null),
            'received' => self::when(null),
        );
        if (strlen($full) > self::MAX_FULL) { $full = ''; }
        $fig = self::figures_in(isset($p['figures']) ? $p['figures'] : null);
        $done = self::locked(function () use ($id, $row, $html, $full, $fig) {
            $all = self::read('reports');
            $had = isset($all[$id]);
            $row['token'] = $had && !empty($all[$id]['token']) ? $all[$id]['token'] : bin2hex(random_bytes(16));
            if (!self::put('report-' . $id, $html)) { return null; }
            if ($full !== '') { if (!self::put('report-' . $id . '-full', $full)) { return null; } } else { self::remove('report-' . $id . '-full'); }
            if ($fig) { self::put('report-' . $id . '-fig', wp_json_encode($fig)); } else { self::remove('report-' . $id . '-fig'); }
            $all[$id] = $row;
            return self::write('reports', $all) ? array($had, $row['token']) : null;
        });
        if ($done === null) { return new WP_Error('mazesta_report', 'The report could not be saved.', array('status' => 500)); }
        // a report marked before or after the service goes into that place of the service with its number (the newest of each wins); the report is kept even when the CRM is not there
        if ($row['stage'] !== '' && $row['service'] !== '' && class_exists('MZC_Crm')) { MZC_Crm::attach_stage($row['service'], $row['stage'], $id); }
        $c = self::config();
        return self::fresh(array(
            'id' => $id, 'updated' => $done[0],
            'url' => admin_url('admin-post.php?action=mzc_report&id=' . $id),
            'link' => !empty($c['publicLinks']) ? home_url('/?mazesta_report=' . $done[1]) : null,
        ));
    }

    /** The app's hands-on checks of one service, before or after the work, into its form (MZC_Crm::hands_in). */
    public static function rest_checks($req)
    {
        $p = $req->get_json_params(); $service = self::clip(isset($p['service']) ? $p['service'] : '', 40);
        if ($service === '' || !class_exists('MZC_Crm')) { return new WP_Error('mazesta_checks', 'The service number is missing.', array('status' => 422)); }
        $n = MZC_Crm::hands_in($service, isset($p['stage']) ? (string) $p['stage'] : '', isset($p['items']) ? $p['items'] : null);
        return is_int($n) ? self::fresh(array('service' => $service, 'items' => $n)) : new WP_Error('mazesta_checks', $n, array('status' => 422));
    }

    /** The figures the app sent for the before/after comparison (MZC_Crm::compare), checked and cut to size; empty when there are none. */
    private static function figures_in($list)
    {
        $out = array();
        if (!is_array($list)) { return $out; }
        foreach (array_slice($list, 0, 400) as $f) {
            if (!is_array($f) || !isset($f['key']) || !is_string($f['key']) || !preg_match('/^[tpb]:[A-Za-z0-9._:\- ]{1,120}$/', $f['key'])) { continue; }
            $out[$f['key']] = array('name' => self::clip(isset($f['name']) ? $f['name'] : '', 190), 'value' => isset($f['value']) && is_numeric($f['value']) ? (float) $f['value'] : null,
                'unit' => self::clip(isset($f['unit']) ? $f['unit'] : '', 20), 'higher' => isset($f['higher']) && is_bool($f['higher']) ? $f['higher'] : null,
                'outcome' => isset($f['outcome']) && is_string($f['outcome']) && preg_match('/^[A-Za-z]{1,20}$/', $f['outcome']) ? $f['outcome'] : null);
        }
        return $out;
    }

    /** A report's comparison figures by key (see figures_in), or an empty array. */
    public static function report_figures($id)
    {
        return preg_match('/^[A-Za-z0-9-]{8,64}$/', (string) $id) ? self::read('report-' . $id . '-fig') : array();
    }

    /** The reports kept here, newest first (what the print program lists): who and what each is about, never the page itself. */
    public static function rest_report_list($req)
    {
        $rows = array();
        foreach (self::reports('', 500, 0, 'received')[0] as $r) {
            $rows[] = array('id' => $r['id'], 'service' => $r['service'], 'title' => $r['title'], 'machine' => $r['machine'], 'device' => $r['device'], 'laptop' => !empty($r['laptop']),
                'notes' => $r['notes'], 'stage' => $r['stage'], 'kind' => $r['kind'], 'verdict' => $r['verdict'], 'summary' => $r['summary'], 'created' => $r['created'], 'received' => $r['received']);
        }
        return self::fresh(array('reports' => $rows));
    }

    /**
     * The reports stay files (the shop's choice: the app uploads them to the site as before, not into a database): reports.php is the list, report-ID.php the
     * one-page summary and report-ID-full.php the whole report. Newest first (by 'created' or 'received'), without their pages: array(rows keyed by id, total), each
     * row with its id, has_full and the fields the app sent. $s: words looked for in the service number, title, system, device, summary and notes.
     */
    public static function reports($s = '', $limit = 30, $offset = 0, $order = 'created')
    {
        $rows = self::read('reports'); $s = trim((string) $s); $by = $order === 'received' ? 'received' : 'created';
        if ($s !== '') {
            $rows = array_filter($rows, function ($r) use ($s) {
                foreach (array('title', 'machine', 'service', 'summary', 'device', 'notes') as $f) { if (isset($r[$f]) && mb_stripos((string) $r[$f], $s) !== false) { return true; } }
                return false;
            });
        }
        uasort($rows, function ($a, $b) use ($by) { return strcmp((string) $b[$by], (string) $a[$by]); });
        $out = array(); foreach (array_slice($rows, $offset, $limit, true) as $id => $r) { $out[(string) $id] = self::report_shape((string) $id, $r); }
        return array($out, count($rows));
    }

    private static function report_shape($id, $r)
    {
        $r += array('title' => '', 'machine' => '', 'service' => '', 'device' => '', 'laptop' => '', 'notes' => '', 'stage' => '', 'verdict' => '', 'kind' => '', 'summary' => '', 'app' => '', 'created' => '', 'received' => '', 'token' => '');
        return array('id' => $id, 'has_full' => is_file(self::file('report-' . $id . '-full'))) + $r;
    }

    /** One report without its pages (see reports()), or null. */
    public static function report($id)
    {
        if (!preg_match('/^[A-Za-z0-9-]{8,64}$/', (string) $id)) { return null; }
        $all = self::read('reports');
        return isset($all[$id]) ? self::report_shape((string) $id, $all[$id]) : null;
    }

    /** A report's page as the app sent it: the one-page summary, or with $full the whole report (null when there is none). */
    public static function report_html($id, $full = false)
    {
        return preg_match('/^[A-Za-z0-9-]{8,64}$/', (string) $id) ? self::raw('report-' . $id . ($full ? '-full' : '')) : null;
    }

    /** One report's summary page, as it was sent; the print program shows it in a page that lets nothing in it run. */
    public static function rest_report_get($req)
    {
        $id = (string) $req['id'];
        $html = self::report_html($id);
        if ($html === null) { return new WP_Error('mazesta_report', 'The report was not found.', array('status' => 404)); }
        return self::fresh(array('id' => $id, 'html' => $html));
    }

    /** A run as the app logs it, or false when it is not one. */
    /** The benchmarks' names as the app shows them, for the ones known when this was written; the app sends its own with its runs. */
    private static $bench_names = array(
        'bench.cpu.multi' => 'پردازنده — چندرشته (همه رشته‌ها)', 'bench.cpu.single' => 'پردازنده — تک‌رشته', 'bench.memory' => 'پهنای‌باند حافظه',
        'bench.storage' => 'ذخیره‌سازی (ترتیبی و تصادفی، بدون کش)', 'bench.gpu.d3d' => 'گرافیک — رندر Direct3D 12', 'bench.gpu.rt' => 'گرافیک — ری‌تریسینگ (DXR)',
        'bench.gpu.ai' => 'گرافیک — هوش مصنوعی (DirectML)', 'bench.gpu.scene.d3d' => 'گرافیک — باغ ایرانی (Direct3D 12)', 'bench.gpu.scene.rt' => 'گرافیک — باغ ایرانی با ری‌تریسینگ (DXR)', 'bench.gpu.fur' => 'دمای گرافیک',
        'bench.ai.llm' => 'مدل زبانی هوش مصنوعی (llama.cpp)', 'bench.network.internet' => 'شبکه — سرعت اینترنت',
    );

    public static function bench_name($id)
    {
        static $sent = null;
        if ($sent === null) { $db = self::db(); $sent = $db ? (array) $db->get_results('SELECT id, name FROM `' . self::t('bench_names') . '`', OBJECT_K) : array(); }
        if (isset($sent[$id]) && is_object($sent[$id])) { return $sent[$id]->name; }
        if (isset($sent[$id]) && is_string($sent[$id]) && $sent[$id] !== '') { return $sent[$id]; }
        return isset(self::$bench_names[$id]) ? self::$bench_names[$id] : $id;
    }

    /** The names the app sent with its runs (a benchmark's id and a short plain text each), kept for the pages here. */
    private static function keep_names($names)
    {
        $clean = array();
        foreach ($names as $id => $name) {
            if (!is_string($id) || !preg_match('/^[A-Za-z0-9._-]{1,80}$/', $id)) { continue; }
            $name = self::text($name, 80);
            if ($name !== '') { $clean[$id] = $name; }
            if (count($clean) >= 100) { break; }
        }
        $db = self::db(); if (!$clean || !$db) { return; }
        $vals = array(); foreach ($clean as $id => $name) { $vals[] = $db->prepare('(%s, %s)', $id, $name); }
        $db->query('INSERT INTO `' . self::t('bench_names') . '` (id, name) VALUES ' . implode(',', $vals) . ' ON DUPLICATE KEY UPDATE name = VALUES(name)');
    }

    /* ---------- old versions ---------- */

    /** The newest workload version of each benchmark among the approved runs (written at every rebuild): what "current" means for the notices below. */
    private static function latest_versions()
    {
        static $latest = null;
        if ($latest === null) {
            $latest = array(); $db = self::db();
            foreach ($db ? (array) $db->get_col('SELECT DISTINCT list FROM `' . self::t('bench_runs') . '` WHERE approved = 1') : array() as $list) {
                if (preg_match('/^([A-Za-z0-9._-]+)@(\d+)/', (string) $list, $mm)) { $latest[$mm[1]] = max(isset($latest[$mm[1]]) ? $latest[$mm[1]] : 0, (int) $mm[2]); }
            }
        }
        return $latest;
    }

    /** Whether a result of this benchmark at this workload version is of an old one: a newer version of the benchmark has approved runs. */
    private static function is_old($benchmark, $version)
    {
        $l = self::latest_versions();
        return isset($l[$benchmark]) && (int) $version < (int) $l[$benchmark];
    }

    /** The app version the shop has published (the release folder's manifest), or null. */
    private static function latest_app()
    {
        $f = self::release_dir() . '/update.json';
        $m = is_readable($f) ? json_decode((string) file_get_contents($f), true) : null;
        return is_array($m) && isset($m['app']['version']) && is_string($m['app']['version']) && preg_match('/^\d+(\.\d+){1,3}$/', $m['app']['version']) ? $m['app']['version'] : null;
    }

    /** Whether an app version a result came from is older than the published one. */
    private static function old_app($version)
    {
        $latest = self::latest_app();
        return $latest !== null && is_string($version) && preg_match('/^\d+(\.\d+){1,3}/', $version) && version_compare($version, $latest, '<');
    }

    /**
     * A list's key ("bench.storage@1|fileMb=1024") as a manager reads it: the benchmark's name and its settings in words, and the key itself
     * small underneath (the number after @ is the workload's version: a list starts over when the benchmark's work changes). HTML, escaped.
     */
    private static function list_label($table)
    {
        $table = (string) $table;
        if (!preg_match('/^([A-Za-z0-9._-]+)@(\d+)(?:\|(.*))?$/', $table, $m)) { return '<span dir="ltr">' . esc_html($table) . '</span>'; }
        $label = esc_html(self::bench_name($m[1]));
        if (self::is_old($m[1], (int) $m[2])) { $label .= ' <span class="mzc-old">نسخه قدیمی بنچمارک</span>'; }
        if ($m[1] === 'bench.gpu.scene.d3d') {
            $label .= ' · ' . esc_html(implode('، ', self::scene_words(isset($m[3]) ? $m[3] : '')));
        } elseif (isset($m[3]) && $m[3] !== '') {
            $words = array();
            foreach (explode('|', $m[3]) as $pair) {
                if (preg_match('/^fileMb=(\d+)$/', $pair, $f)) { $words[] = 'فایل ' . number_format_i18n((int) $f[1]) . ' مگابایتی'; }
                elseif (preg_match('/^resolution=(\d+)x(\d+)$/', $pair, $f)) { $words[] = 'رزولوشن ' . (int) $f[1] . '×' . (int) $f[2]; }
                elseif (preg_match('/^quality=(\d)$/', $pair, $f)) { $words[] = self::quality_words($m[1], (int) $f[1]); }
                elseif (preg_match('/^duration=(\d+)$/', $pair, $f)) { $words[] = self::duration_words($m[1], (int) $f[1]); }
                else { $words[] = $pair; }
            }
            $label .= ' · ' . esc_html(implode('، ', $words));
        }
        return $label . '<br><small dir="ltr" class="mzc-dim">' . esc_html($table) . '</small>';
    }

    /**
     * The garden (Direct3D) benchmark's settings in words. The app leaves the default settings out of a list's key (2560×1440, quality 3, no ray
     * tracing, no weather, two frames in flight) so old lists stay valid; a manager reads the whole setting, so they are put back here.
     */
    private static function scene_words($rest)
    {
        $o = array('resolution' => '2560x1440', 'quality' => '3', 'raytracing' => 'off', 'weather' => 'off', 'frames' => '2');
        foreach (explode('|', (string) $rest) as $pair) {
            if (strpos($pair, '=') !== false) { list($k, $v) = explode('=', $pair, 2); $o[$k] = $v; }
        }
        $words = array();
        $words[] = preg_match('/^(\d+)x(\d+)$/', $o['resolution'], $f) ? 'رزولوشن ' . (int) $f[1] . '×' . (int) $f[2] : 'رزولوشن ' . $o['resolution'];
        if ($o['raytracing'] === 'on') { $words[] = 'ری‌تریسینگ روشن'; }
        else { $words[] = self::quality_words('bench.gpu.scene.d3d', (int) $o['quality']); $words[] = 'ری‌تریسینگ خاموش'; }
        if ($o['weather'] !== 'off') { $words[] = 'آب‌وهوا: ' . $o['weather']; }
        $words[] = $o['frames'] === '1' ? 'تک‌فریم' : ($o['frames'] === '2' ? 'دو فریم هم‌زمان' : $o['frames'] . ' فریم');
        if (isset($o['duration']) && ctype_digit((string) $o['duration'])) { $words[] = self::duration_words('bench.gpu.scene.d3d', (int) $o['duration']); }
        return $words;
    }

    /**
     * A list's run length in words. The app leaves a benchmark's own length out of the key, so only longer runs have one: the garden is counted
     * in walks of 162 seconds (3 and 5 of them), the rest in minutes or seconds.
     */
    private static function duration_words($benchmark, $secs)
    {
        if ($benchmark === 'bench.gpu.scene.d3d' && $secs % 162 === 0) { return 'مدت: ' . number_format_i18n($secs / 162) . ' دور'; }
        return 'مدت: ' . ($secs % 60 === 0 ? number_format_i18n($secs / 60) . ' دقیقه' : number_format_i18n($secs) . ' ثانیه');
    }

    /** The garden benchmarks' quality setting in words: the rasteriser's load level, or the ray tracer's rays a pixel. */
    private static function quality_words($benchmark, $q)
    {
        if ($benchmark === 'bench.gpu.scene.rt') { return 'کیفیت: ' . $q . ' پرتو در هر پیکسل'; }
        $names = array(1 => 'سبک', 2 => 'متوسط', 3 => 'سنگین', 4 => 'بسیار سنگین');
        return 'کیفیت: ' . (isset($names[$q]) ? $names[$q] : $q);
    }

    public static function valid_run($run)
    {
        return is_object($run) && isset($run->id, $run->benchmark, $run->part, $run->system, $run->value, $run->unit)
            && is_string($run->id) && preg_match('/^[A-Za-z0-9-]{8,64}$/', $run->id) && is_string($run->benchmark) && preg_match('/^[A-Za-z0-9._-]{1,80}$/', $run->benchmark)
            && is_string($run->part) && trim($run->part) !== '' && is_string($run->system) && is_string($run->unit)
            && (is_int($run->value) || is_float($run->value)) && $run->value > 0 && is_finite((float) $run->value);
    }

    /** A short plain text from outside: control characters and angle brackets removed, cut to $n. Anything that is not text is empty. */
    public static function text($v, $n)
    {
        if (!is_string($v)) { return ''; }
        $s = preg_replace('/[\x00-\x1F\x7F<>]/u', '', $v);   // null when it is not valid UTF-8
        return is_string($s) ? mb_substr(trim($s), 0, $n) : '';
    }

    /**
     * A run rebuilt from the fields the app writes, each checked for its type, range and length. Nothing else in the request is kept, so
     * what is stored and later sent out in the lists holds only these fields. Null when it is not a run.
     */
    private static function clean_run($run, $trusted)
    {
        if (!self::valid_run($run) || !preg_match('/^[A-Za-z0-9+\/=_-]{8,128}$/', $run->system)) { return null; }
        $part = self::text($run->part, 120); $unit = self::text($run->unit, 20);
        if ($part === '' || $unit === '' || (float) $run->value > 1.0e15) { return null; }
        $o = new stdClass();
        $o->id = $run->id; $o->at = self::when(isset($run->at) ? $run->at : null); $o->benchmark = $run->benchmark;
        $o->version = isset($run->version) && is_int($run->version) && $run->version > 0 && $run->version < 100000 ? $run->version : 1;
        $o->settings = self::text(isset($run->settings) ? $run->settings : '', 160);
        $o->part = $part; $o->system = $run->system;
        $o->machine = $trusted ? self::text(isset($run->machine) ? $run->machine : '', 80) : '';   // a stranger's computer name is not ours to keep
        $o->spec = $trusted ? self::text(isset($run->spec) ? $run->spec : '', 300) : $part;
        $o->value = (float) $run->value; $o->unit = $unit;
        $app = self::text(isset($run->app) ? $run->app : '', 40);
        if ($app !== '') { $o->app = $app; }
        if (isset($run->metrics) && is_array($run->metrics)) {
            $o->metrics = array();
            foreach (array_slice($run->metrics, 0, 24) as $m) {
                if (!is_object($m) || !isset($m->key, $m->value) || !(is_int($m->value) || is_float($m->value)) || !is_finite((float) $m->value)) { continue; }
                $key = self::text($m->key, 60);
                if ($key === '') { continue; }
                $x = new stdClass(); $x->key = $key; $x->value = (float) $m->value; $x->unit = self::text(isset($m->unit) ? $m->unit : '', 20);
                $o->metrics[] = $x;
            }
        }
        $o->overclocked = isset($run->overclocked) && $run->overclocked === true;
        if (isset($run->details) && is_array($run->details)) {
            $o->details = array();
            foreach (array_slice($run->details, 0, 80) as $d) {
                if (!is_object($d)) { continue; }
                $x = new stdClass(); $x->group = self::text(isset($d->group) ? $d->group : '', 60); $x->key = self::text(isset($d->key) ? $d->key : '', 80); $x->value = self::text(isset($d->value) ? $d->value : '', 200);
                if ($x->key !== '') { $o->details[] = $x; }
            }
        }
        return $o;
    }

    /** Adds the runs not yet held (each once, by its id): approved when they came with the shop's key, else waiting for review. */
    private static function add_runs($runs, $higher, $trusted)
    {
        $db = self::db(); $added = 0; $known = 0; $bad = 0;
        if (!$db) { return array(0, 0, count($runs)); }
        foreach ($runs as $raw) {
            $run = self::clean_run($raw, $trusted);
            if ($run === null) { $bad++; continue; }
            $table = $run->benchmark . '@' . $run->version . ($run->settings !== '' ? '|' . $run->settings : '');
            $json = wp_json_encode($run, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($json === false || strlen($json) > 20000 || strlen($table) > 255) { $bad++; continue; }
            // each run once, by its id: INSERT IGNORE says which were new
            $n = $db->query($db->prepare('INSERT IGNORE INTO `' . self::t('bench_runs') . '` (id, list, part, value, unit, higher, approved, run_at, received, run) VALUES (%s, %s, %s, %f, %s, %d, %d, %s, %s, %s)',
                $run->id, $table, $run->part, $run->value, $run->unit, !(isset($higher[$run->benchmark]) && !$higher[$run->benchmark]) ? 1 : 0, $trusted ? 1 : 0, MZC_Stats::dt($run->at), gmdate('Y-m-d H:i:s'), $json));
            if ($n) { $added++; } else { $known++; }
        }
        return array($added, $known, $bad);
    }

    private static function runs_of($req)
    {
        if (strlen($req->get_body()) > 2000000) { return new WP_Error('mazesta_runs', 'The request is too large.', array('status' => 413)); }
        $body = json_decode($req->get_body());   // objects stay objects, so a run goes back out as it came in
        if (!is_object($body) || !isset($body->runs) || !is_array($body->runs)) { return new WP_Error('mazesta_runs', 'No runs in the request.', array('status' => 400)); }
        if (count($body->runs) > self::MAX_RUNS) { return new WP_Error('mazesta_runs', 'Too many runs in one request.', array('status' => 413)); }
        return $body;
    }

    public static function rest_runs($req)
    {
        $key = self::key_state($req); $c = self::config();
        // the shop's own copies (site key) and the release tool sending the archive (release key) go straight into the lists
        $trusted = $key === 'ok' || self::key_state($req, 'releaseKey') === 'ok';
        if (!$trusted) {
            if (empty($c['openUploads'])) { return new WP_Error('mazesta_key', 'The site key is missing or wrong.', array('status' => 401)); }
            if (!self::allowed('runs', 20)) { return new WP_Error('mazesta_busy', 'Too many uploads from this address; try again in an hour.', array('status' => 429)); }
        }
        $body = self::runs_of($req);
        if (is_wp_error($body)) { return $body; }
        if (!self::db()) { return self::no_db(); }
        $higher = isset($body->higher) && is_object($body->higher) ? (array) $body->higher : array();
        list($added, $known, $bad) = self::add_runs($body->runs, $higher, $trusted);
        if ($trusted && isset($body->names) && is_object($body->names)) { self::keep_names((array) $body->names); }
        // Mazesta's own marks (featured, overclocked) come with its runs; for a run marked on two copies the later mark wins.
        $marked = 0;
        if ($trusted && isset($body->marks) && is_object($body->marks)) {
            $marks = (array) $body->marks;
            $db = self::db();
            foreach ($db ? $marks : array() as $id => $m) {
                if (!is_object($m)) { continue; }
                $oc = isset($m->overclocked) && is_bool($m->overclocked) ? ($m->overclocked ? '1' : '0') : 'NULL';
                $marked += (int) $db->query($db->prepare('UPDATE `' . self::t('bench_runs') . "` SET featured = %d, oc = $oc, note = %s, mark_at = %s WHERE id = %s AND (mark_at IS NULL OR mark_at < %s)",
                    !empty($m->featured) ? 1 : 0, isset($m->note) && is_string($m->note) ? mb_substr($m->note, 0, 190) : '', $at = MZC_Stats::dt(isset($m->at) ? $m->at : ''), (string) $id, $at));
            }
        }
        $lists = ($trusted && ($added > 0 || $marked > 0)) ? self::rebuild() : null;
        return self::fresh(array('added' => $added, 'known' => $known, 'rejected' => $bad, 'pending' => !$trusted, 'marked' => $marked, 'lists' => $lists));
    }

    /* ---------- anonymous usage statistics ---------- */

    public static function usage_file($ym) { return self::dir() . '/usage-' . $ym . '.log.php'; }

    /**
     * What the app's "send anonymous usage statistics" switch sends (on by default; the app says in plain words what is in it). No key: anybody can send, so it is
     * bounded - sixty posts an hour from one address, two hundred events a post, a few kilobytes an event - and only plain figures and short names are kept. The
     * sender's address is used for that count only and is never stored. An installation is its random id, nothing else; its parts' names are kept beside it.
     */
    public static function rest_usage($req)
    {
        if (!self::allowed('usage', 60)) { return new WP_Error('mazesta_busy', 'Too many posts from this address; try again in an hour.', array('status' => 429)); }
        $body = json_decode((string) $req->get_body(), true);
        if (!is_array($body) || !isset($body['install']) || !preg_match('/^[a-f0-9]{32}$/', (string) $body['install'])) { return new WP_Error('mazesta_usage', 'Not understood.', array('status' => 400)); }
        $id = (string) $body['install']; $now = gmdate('c');
        $events = isset($body['events']) && is_array($body['events']) ? array_slice($body['events'], 0, 200) : array();
        $m = isset($body['machine']) && is_array($body['machine']) ? $body['machine'] : array();
        $machine = array(
            'cpu' => self::text(isset($m['cpu']) ? $m['cpu'] : '', 120), 'os' => self::text(isset($m['os']) ? $m['os'] : '', 120),
            'ramGb' => isset($m['ramGb']) && is_numeric($m['ramGb']) ? (int) $m['ramGb'] : null,
            'gpus' => array(),
        );
        if (isset($m['gpus']) && is_array($m['gpus'])) { foreach (array_slice($m['gpus'], 0, 4) as $g) { $machine['gpus'][] = self::text($g, 120); } }
        foreach (array('cores', 'threads') as $n) { if (isset($m[$n]) && is_numeric($m[$n])) { $machine[$n] = (int) $m[$n]; } }
        foreach (array('gpuDriver' => 40, 'board' => 120) as $n => $max) { if (isset($m[$n])) { $machine[$n] = self::text($m[$n], $max); } }
        foreach (array('ramModules', 'storage') as $n) {
            if (isset($m[$n]) && is_array($m[$n])) { $machine[$n] = array(); foreach (array_slice($m[$n], 0, 12) as $x) { $machine[$n][] = self::text($x, 120); } }
        }
        // each drive's health; the blue screens, power losses and setup checks the app read once a run (codes and figures only)
        if (isset($m['drives']) && is_array($m['drives'])) {
            $machine['drives'] = array();
            foreach (array_slice($m['drives'], 0, 12) as $x) { if (!is_array($x) || !isset($x['n'])) { continue; } $y = array('n' => self::text($x['n'], 120)); if (isset($x['health'])) { $y['health'] = self::text($x['health'], 30); } if (isset($x['wear']) && is_numeric($x['wear'])) { $y['wear'] = (int) $x['wear']; } $machine['drives'][] = $y; }
        }
        if (isset($m['health']) && is_array($m['health'])) {
            $h = $m['health']; $y = array();
            foreach (array('bsod', 'powerLosses') as $n) { if (isset($h[$n]) && is_numeric($h[$n])) { $y[$n] = (int) $h[$n]; } }
            if (isset($h['bsodRecent']) && is_array($h['bsodRecent'])) { $y['bsodRecent'] = array(); foreach (array_slice($h['bsodRecent'], 0, 5) as $x) { if (is_array($x)) { $y['bsodRecent'][] = array('at' => self::text(isset($x['at']) ? $x['at'] : '', 40), 'code' => self::text(isset($x['code']) ? $x['code'] : '', 12), 'name' => self::text(isset($x['name']) ? $x['name'] : '', 80)); } } }
            if (isset($h['setup']) && is_array($h['setup'])) {
                $y['setup'] = array();
                foreach (array_slice($h['setup'], 0, 30) as $x) {
                    if (!is_array($x) || !isset($x['c']) || !preg_match('/^[A-Za-z]{2,40}$/', (string) $x['c'])) { continue; }
                    $f = array('c' => (string) $x['c'], 'l' => self::text(isset($x['l']) ? $x['l'] : '', 12), 'p' => self::text(isset($x['p']) ? $x['p'] : '', 20));
                    if (isset($x['s'])) { $f['s'] = self::text($x['s'], 120); }
                    if (isset($x['m']) && is_array($x['m'])) { foreach (array_slice($x['m'], 0, 6, true) as $k => $v) { if (preg_match('/^[A-Za-z_]{2,40}$/', (string) $k) && is_numeric($v)) { $f['m'][$k] = (float) $v; } } }
                    $y['setup'][] = $f;
                }
            }
            $machine['health'] = $y;
        }
        if (!$m) { $machine = null; }   // an event with no parts (the uninstaller's) keeps what the system sent before
        $lines = array();
        foreach ($events as $e) {
            if (!is_array($e) || !isset($e['k']) || !preg_match('/^[a-z]{2,12}(\.[a-z]{2,12}){0,2}$/', (string) $e['k'])) { continue; }
            $d = isset($e['d']) && is_array($e['d']) ? $e['d'] : array();
            $j = wp_json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if ($j === false || strlen($j) > 6000) { continue; }
            $at = isset($e['at']) && is_string($e['at']) && preg_match('/^\d{4}-\d{2}-\d{2}T[\d:.]+/', $e['at']) ? substr($e['at'], 0, 33) : $now;
            $lines[] = array('i' => $id, 'at' => $at, 'k' => (string) $e['k'], 'd' => $d);
        }
        $ok = MZC_Stats::record($id, $machine, self::text(isset($body['app']) ? $body['app'] : '', 20), self::text(isset($body['edition']) ? $body['edition'] : '', 12),
            self::text(isset($body['language']) ? $body['language'] : '', 8), $lines);
        return $ok ? self::fresh(array('accepted' => count($lines))) : self::no_db();
    }

    /** A piece of the app's own log and Windows' crash records of it (the app takes the user's folder and the computer's name out first). Only a system that sends statistics. */
    public static function rest_logs($req)
    {
        if (!self::allowed('logs', 60)) { return new WP_Error('mazesta_busy', 'Too many posts from this address; try again in an hour.', array('status' => 429)); }
        $body = json_decode((string) $req->get_body(), true);
        if (!is_array($body) || !isset($body['install']) || !preg_match('/^[a-f0-9]{32}$/', (string) $body['install'])) { return new WP_Error('mazesta_logs', 'Not understood.', array('status' => 400)); }
        $text = isset($body['text']) && is_string($body['text']) ? substr($body['text'], 0, 262144) : '';
        $crashes = array();
        foreach (isset($body['crashes']) && is_array($body['crashes']) ? array_slice($body['crashes'], 0, 20) : array() as $c) {
            if (!is_array($c)) { continue; } $x = array();
            foreach ($c as $k => $v) { if (preg_match('/^(at|sig\d{1,2})$/', (string) $k) && is_scalar($v)) { $x[$k] = self::text((string) $v, 200); } }
            if ($x) { $crashes[] = $x; }
        }
        if ($text === '' && !$crashes) { return self::fresh(array('accepted' => 0)); }
        if (!MZC_Stats::ready()) { return self::no_db(); }
        $file = isset($body['file']) && preg_match('/^[A-Za-z0-9._-]{1,40}$/', (string) $body['file']) ? (string) $body['file'] : '';
        $ok = MZC_Stats::add_log((string) $body['install'], self::text(isset($body['app']) ? $body['app'] : '', 20), $file, wp_check_invalid_utf8($text, true), $crashes);
        return $ok ? self::fresh(array('accepted' => 1)) : new WP_Error('mazesta_logs', 'Unknown system: send the statistics first.', array('status' => 404));
    }

    /**
     * A user's latest results, to pass on: kept as a page of its own under a link. Only numbers and short plain texts are taken (no HTML).
     * A computer has one page: sharing again replaces it and keeps its link. The runs also wait in the review queue when the shop takes
     * uploads without a key.
     */
    public static function rest_share($req)
    {
        $c = self::config();
        if (empty($c['sharing'])) { return new WP_Error('mazesta_share', 'Sharing is switched off on the site.', array('status' => 403)); }
        if (!self::allowed('share', 30)) { return new WP_Error('mazesta_busy', 'Too many uploads from this address; try again in an hour.', array('status' => 429)); }
        $body = self::runs_of($req);
        if (is_wp_error($body)) { return $body; }
        if (count($body->runs) > 60) { return new WP_Error('mazesta_runs', 'Too many runs in one request.', array('status' => 413)); }
        $names = isset($body->names) && is_object($body->names) ? (array) $body->names : array();
        $rows = array(); $system = '';
        foreach ($body->runs as $raw) {
            $run = self::clean_run($raw, false);
            if ($run === null) { continue; }
            if ($system === '') { $system = $run->system; }
            $name = self::text(isset($names[$run->benchmark]) ? $names[$run->benchmark] : '', 80);
            $rows[] = array(
                'benchmark' => $run->benchmark, 'name' => $name !== '' ? $name : $run->benchmark, 'settings' => $run->settings, 'value' => $run->value, 'unit' => $run->unit,
                'part' => self::part_name($run->part), 'at' => $run->at, 'version' => $run->version,
            );
        }
        if (!$rows) { return new WP_Error('mazesta_runs', 'No valid runs in the request.', array('status' => 400)); }
        $m = isset($body->machine) && is_object($body->machine) ? $body->machine : new stdClass();
        $share = array(
            'created' => self::when(null), 'app' => self::text(isset($body->appVersion) ? $body->appVersion : '', 40),
            'owner' => self::text(isset($m->name) ? $m->name : '', 40),
            'cpu' => self::text(isset($m->cpu) ? $m->cpu : '', 120), 'gpu' => self::text(isset($m->gpu) ? $m->gpu : '', 120), 'os' => self::text(isset($m->os) ? $m->os : '', 120),
            'ramGb' => isset($m->ramGb) && (is_int($m->ramGb) || is_float($m->ramGb)) && $m->ramGb > 0 && $m->ramGb < 100000 ? (float) $m->ramGb : null,
            'rows' => $rows,
        );
        $who = substr(hash('sha256', $system), 0, 24);
        $db = self::db(); if (!$db) { return self::no_db(); }
        $token = $db->get_var($db->prepare('SELECT token FROM `' . self::t('shares') . '` WHERE who = %s', $who));
        if ($token === null) { $token = bin2hex(random_bytes(12)); }
        $ok = $db->replace(self::t('shares'), array('token' => $token, 'who' => $who, 'created' => MZC_Stats::dt($share['created']), 'app' => $share['app'], 'owner' => $share['owner'], 'cpu' => $share['cpu'], 'gpu' => $share['gpu'], 'os' => $share['os'], 'ram_gb' => $share['ramGb']));
        $db->delete(self::t('share_rows'), array('token' => $token));
        $vals = array();
        foreach ($share['rows'] as $i => $r) { $vals[] = $db->prepare('(%s, %d, %s, %s, %s, %f, %s, %s, %s, %d)', $token, $i, $r['benchmark'], self::text($r['name'], 80), $r['settings'], $r['value'], $r['unit'], $r['part'], MZC_Stats::dt($r['at']), $r['version']); }
        if ($ok && !$db->query('INSERT INTO `' . self::t('share_rows') . '` (token, pos, benchmark, name, settings, value, unit, part, at, version) VALUES ' . implode(',', $vals))) { $ok = false; }
        // the oldest pages go when there are too many
        $over = (int) $db->get_var('SELECT COUNT(*) FROM `' . self::t('shares') . '`') - self::MAX_SHARES;
        if ($over > 0) { foreach ((array) $db->get_col($db->prepare('SELECT token FROM `' . self::t('shares') . '` ORDER BY created LIMIT %d', $over)) as $old) { self::drop_share($old); } }
        if (!$ok) { $token = null; }
        if ($token === null) { return new WP_Error('mazesta_share', 'The results could not be saved.', array('status' => 500)); }
        $queued = 0;
        if (!empty($c['openUploads'])) {
            $higher = isset($body->higher) && is_object($body->higher) ? (array) $body->higher : array();
            list($queued) = self::add_runs($body->runs, $higher, false);
        }
        return self::fresh(array('link' => home_url('/?mazesta_share=' . $token), 'rows' => count($rows), 'queued' => $queued));
    }

    /* ---------- the comparison lists ---------- */

    private static function db_dir() { return self::dir() . '/benchdb'; }

    /** A part's name as the lists group it (BenchmarkPeers.PartName): vendor marks and CPU tails removed, spaces collapsed. */
    private static function part_name($raw)
    {
        $s = preg_replace('/\((R|TM|C)\)|®|™/iu', ' ', (string) $raw);
        $s = preg_replace('/(\s+CPU)?\s+@\s+[\d.]+\s*GHz$|\s+\d+-Core\s+Processor$|\s+Processor$/iu', '', trim(preg_replace('/\s+/u', ' ', $s)));
        return trim(preg_replace('/\s+/u', ' ', $s));
    }

    /** The list's file name (BenchmarkPeers.FileName): the settings folded into a short hash. */
    private static function file_name($table)
    {
        $bar = strpos($table, '|');
        if ($bar === false) { return str_replace('@', '-v', $table) . '.json'; }
        return str_replace('@', '-v', substr($table, 0, $bar)) . '-' . substr(hash('sha256', substr($table, $bar + 1)), 0, 10) . '.json';
    }

    private static function sample($run, $oc)
    {
        $s = array('value' => $run->value, 'overclocked' => $oc, 'at' => isset($run->at) ? $run->at : null);
        if (isset($run->metrics)) { $s['metrics'] = $run->metrics; }
        if (isset($run->details)) { $s['details'] = $run->details; }
        return $s;
    }

    /** Builds every list from the approved runs and writes them, with index.json (name, size, SHA-256 of each). Returns how many lists there are. */
    public static function rebuild()
    {
        if (!self::ensure()) { return 0; }
        $dir = self::db_dir();
        $tables = array();
        $db = self::db(); if (!$db) { return 0; }
        foreach ((array) $db->get_results('SELECT list, higher, featured, oc, note, run FROM `' . self::t('bench_runs') . '` WHERE approved = 1', ARRAY_A) as $row) {
            $run = json_decode((string) $row['run']);
            if (!is_object($run) || !isset($run->value, $run->part, $run->system, $run->unit)) { continue; }
            $oc = $row['oc'] !== null ? (bool) $row['oc'] : !empty($run->overclocked);
            $tables[$row['list']][] = array('run' => $run, 'oc' => $oc, 'higher' => (bool) $row['higher'], 'featured' => (bool) $row['featured'], 'note' => (string) $row['note'], 'ts' => isset($run->at) ? (int) strtotime($run->at) : 0);
        }
        // the newest version of each benchmark that has approved runs: a list of an older one is marked, so whoever shows it can say it is old
        $latest = array();
        foreach (array_keys($tables) as $key) {
            if (preg_match('/^([A-Za-z0-9._-]+)@(\d+)/', (string) $key, $mm)) { $latest[$mm[1]] = max(isset($latest[$mm[1]]) ? $latest[$mm[1]] : 0, (int) $mm[2]); }
        }
        $flags = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES;
        $files = array(); $built = gmdate('Y-m-d\TH:i:s\Z');
        foreach ($tables as $key => $list) {
            $first = $list[0]; $higher = $first['higher'];
            $units = array();
            foreach ($list as $x) { $u = $x['run']->unit; $units[$u] = isset($units[$u]) ? $units[$u] + 1 : 1; }
            arsort($units); $unit = (string) key($units);
            $parts = array(); $featured = array();
            foreach ($list as $x) {
                if ($x['run']->unit !== $unit) { continue; }
                $name = self::part_name($x['run']->part);
                if ($name === '') { continue; }
                $parts[mb_strtoupper($name) . "\x01" . ($x['oc'] ? '1' : '0')][] = $x;
                if ($x['featured']) {
                    $f = array('id' => $x['run']->id, 'part' => $name) + self::sample($x['run'], $x['oc']);
                    if ($x['note'] !== '') { $f['note'] = $x['note']; }
                    $featured[] = $f;
                }
            }
            $entries = array();
            foreach ($parts as $group) {
                $best = array();   // each system once, with its best run
                foreach ($group as $x) {
                    $sys = (string) $x['run']->system; $v = (float) $x['run']->value;
                    if (!isset($best[$sys]) || ($higher ? $v > (float) $best[$sys]['run']->value : $v < (float) $best[$sys]['run']->value)) { $best[$sys] = $x; }
                }
                $per = array_values($best);
                usort($per, function ($a, $b) { return (float) $a['run']->value <=> (float) $b['run']->value; });
                $n = count($per);
                $median = $n % 2 === 1 ? (float) $per[intdiv($n, 2)]['run']->value : ((float) $per[intdiv($n, 2) - 1]['run']->value + (float) $per[intdiv($n, 2)]['run']->value) / 2;
                $near = $per[0];
                foreach ($per as $x) { if (abs((float) $x['run']->value - $median) < abs((float) $near['run']->value - $median)) { $near = $x; } }
                $last = $group[0];
                foreach ($group as $x) { if ($x['ts'] > $last['ts']) { $last = $x; } }
                $entries[] = array(
                    'part' => self::part_name($group[0]['run']->part), 'median' => $median, 'best' => (float) ($higher ? $per[$n - 1]['run']->value : $per[0]['run']->value),
                    'systems' => $n, 'runs' => count($group), 'last' => isset($last['run']->at) ? $last['run']->at : $built, 'overclocked' => $group[0]['oc'],
                    'sample' => self::sample($near['run'], $near['oc']),
                    // The model's systems one by one, best first (the entry is their median); a very common model keeps its best 200.
                    'members' => array_map(function ($x) use ($built) { return array('value' => (float) $x['run']->value, 'at' => isset($x['run']->at) ? $x['run']->at : $built); }, array_slice($higher ? array_reverse($per) : $per, 0, 200)),
                );
            }
            if (!$entries) { continue; }
            usort($entries, function ($a, $b) use ($higher) {
                if ($a['median'] != $b['median']) { return $higher ? $b['median'] <=> $a['median'] : $a['median'] <=> $b['median']; }
                return strcasecmp($a['part'], $b['part']);
            });
            usort($featured, function ($a, $b) use ($higher) { return $higher ? $b['value'] <=> $a['value'] : $a['value'] <=> $b['value']; });
            $r = $first['run'];
            $version = isset($r->version) ? (int) $r->version : 1; $newest = isset($latest[$r->benchmark]) ? $latest[$r->benchmark] : $version;
            $json = wp_json_encode(array(
                'key' => $key, 'benchmark' => $r->benchmark, 'version' => $version, 'settings' => isset($r->settings) ? (string) $r->settings : '',
                'latestVersion' => $newest, 'outdated' => $version < $newest,
                'unit' => $unit, 'higherIsBetter' => $higher, 'built' => $built, 'entries' => $entries, 'featured' => $featured,
            ), $flags);
            $name = self::file_name($key);
            if ($json === false || !preg_match('/^[A-Za-z0-9][A-Za-z0-9._@=-]*\.json$/', $name)) { continue; }
            if (file_put_contents($dir . '/' . $name . '.tmp', $json) === false || !rename($dir . '/' . $name . '.tmp', $dir . '/' . $name)) { continue; }
            $files[$name] = array('file' => 'benchdb/' . $name, 'size' => strlen($json), 'sha256' => hash('sha256', $json), 'benchmark' => $r->benchmark, 'version' => $version, 'latestVersion' => $newest, 'outdated' => $version < $newest);
        }
        $have = glob($dir . '/*.json');
        foreach (is_array($have) ? $have : array() as $f) {
            $b = basename($f);
            if ($b !== 'index.json' && !isset($files[$b])) { @unlink($f); }
        }
        ksort($files);
        file_put_contents($dir . '/index.json', wp_json_encode(array('built' => $built, 'files' => array_values($files)), $flags));
        return count($files);
    }

    public static function rest_index()
    {
        $f = self::db_dir() . '/index.json';
        $index = is_readable($f) ? json_decode((string) file_get_contents($f), true) : null;
        return self::fresh(is_array($index) ? $index : array('built' => null, 'files' => array()));
    }

    /** A list is sent byte for byte as it was written: the app checks its size and SHA-256 against the index. */
    public static function rest_list($req)
    {
        $name = basename((string) $req['file']);
        $f = self::db_dir() . '/' . $name;
        if ($name === 'index.json' || !is_readable($f)) { return new WP_Error('mazesta_list', 'No such list.', array('status' => 404)); }
        nocache_headers();
        header('Content-Type: application/json; charset=utf-8');
        header('X-LiteSpeed-Cache-Control: no-cache');
        header('Content-Length: ' . filesize($f));
        readfile($f);
        exit;
    }

    /* ---------- the app's release (the signed update folder) ---------- */

    private static function release_dir() { return ABSPATH . 'mazesta'; }
    private static function release_name($name) { return is_string($name) && preg_match('/^(MazestaUpdate-\d+\.\d+\.\d+\.zip|update\.json|update\.json\.sig|benchdb\/[A-Za-z0-9][A-Za-z0-9._@=-]*\.json)$/', $name); }

    /** One piece of a release file, appended at its offset into /mazesta/.incoming; a piece at 0 starts the file over. */
    public static function rest_chunk($req)
    {
        $name = (string) $req->get_param('name'); $offset = (int) $req->get_param('offset');
        if (!self::release_name($name) || $offset < 0) { return new WP_Error('mazesta_release', 'Not a release file name.', array('status' => 400)); }
        $dir = self::release_dir() . '/.incoming';
        if (!wp_mkdir_p($dir)) { return new WP_Error('mazesta_release', 'The update folder cannot be written.', array('status' => 500)); }
        $file = $dir . '/' . $name;
        if (!wp_mkdir_p(dirname($file))) { return new WP_Error('mazesta_release', 'The update folder cannot be written.', array('status' => 500)); }
        $have = $offset === 0 ? 0 : (is_file($file) ? filesize($file) : -1);
        if ($have !== $offset) { return self::fresh(array('error' => 'offset', 'have' => max(0, (int) $have)), 409); }
        $body = $req->get_body();
        if ($body === '' || file_put_contents($file, $body, $offset === 0 ? 0 : FILE_APPEND) === false) { return new WP_Error('mazesta_release', 'The piece could not be written.', array('status' => 500)); }
        clearstatcache(true, $file);
        return self::fresh(array('have' => filesize($file)));
    }

    /** Checks every uploaded file's size and SHA-256, then puts them in place: the zip first, update.json and its signature last. */
    public static function rest_commit($req)
    {
        $p = $req->get_json_params();
        $want = isset($p['files']) && is_array($p['files']) ? $p['files'] : array();
        $dir = self::release_dir(); $in = $dir . '/.incoming';
        $names = array();
        foreach ($want as $f) {
            $name = isset($f['name']) ? $f['name'] : '';
            if (!self::release_name($name) || !is_file($in . '/' . $name)) { return new WP_Error('mazesta_release', 'A file is missing: ' . sanitize_text_field((string) $name), array('status' => 400)); }
            if (!isset($f['size'], $f['sha256']) || filesize($in . '/' . $name) !== (int) $f['size'] || !hash_equals(strtolower((string) $f['sha256']), (string) hash_file('sha256', $in . '/' . $name))) {
                return new WP_Error('mazesta_release', 'A file arrived damaged: ' . $name, array('status' => 400));
            }
            $names[] = $name;
        }
        if (!in_array('update.json', $names, true) || !in_array('update.json.sig', $names, true)) { return new WP_Error('mazesta_release', 'update.json and its signature are required.', array('status' => 400)); }
        usort($names, function ($a, $b) {
            $ua = substr($a, 0, 6) === 'update' ? 1 : 0; $ub = substr($b, 0, 6) === 'update' ? 1 : 0;
            return $ua !== $ub ? $ua - $ub : strcmp($a, $b);
        });
        foreach ($names as $name) {
            if (!wp_mkdir_p(dirname($dir . '/' . $name)) || !rename($in . '/' . $name, $dir . '/' . $name)) { return new WP_Error('mazesta_release', 'Could not put ' . $name . ' in place.', array('status' => 500)); }
        }
        // The zip the manifest offers stays; older ones go.
        $manifest = json_decode((string) file_get_contents($dir . '/update.json'), true);
        $keep = is_array($manifest) && isset($manifest['app']['file']) ? (string) $manifest['app']['file'] : '';
        $zips = glob($dir . '/MazestaUpdate-*.zip');
        foreach (is_array($zips) ? $zips : array() as $zip) { if (basename($zip) !== $keep) { @unlink($zip); } }
        // The same for the signed comparison lists: the ones the manifest no longer names go.
        $listed = array();
        if (is_array($manifest) && isset($manifest['data']) && is_array($manifest['data'])) { foreach ($manifest['data'] as $d) { if (isset($d['file'])) { $listed[(string) $d['file']] = true; } } }
        $lists = glob($dir . '/benchdb/*.json');
        foreach (is_array($lists) ? $lists : array() as $list) { if (!isset($listed['benchdb/' . basename($list)])) { @unlink($list); } }
        return self::fresh(array('ok' => true, 'version' => is_array($manifest) && isset($manifest['app']['version']) ? $manifest['app']['version'] : null));
    }

    /* ---------- pages: a report, a shared result ---------- */

    public static function page_headers($csp)
    {
        nocache_headers();
        header('Content-Type: text/html; charset=utf-8');
        header('X-Robots-Tag: noindex, nofollow');
        header('X-LiteSpeed-Cache-Control: no-cache');
        header('Content-Security-Policy: ' . $csp);
        header('X-Frame-Options: DENY'); header('X-Content-Type-Options: nosniff'); header('Referrer-Policy: no-referrer');
    }

    private static function show_report($id, $print)
    {
        $id = (string) $id;
        $ok = preg_match('/^[A-Za-z0-9-]{8,64}$/', $id);
        // The summary by default; ?view=full is the whole report, when the app sent it.
        $full = $ok && isset($_GET['view']) && $_GET['view'] === 'full' ? self::report_html($id, true) : null;
        $html = $full !== null ? $full : ($ok ? self::report_html($id) : null);
        if ($html === null) { wp_die('گزارش پیدا نشد.', '', array('response' => 404)); }
        $r = self::report($id); $has_full = $r && $r['has_full'];
        $nonce = bin2hex(random_bytes(12));
        // The page came from outside: nothing in it may run or load. Only the print button's script, named by its nonce, runs.
        self::page_headers("default-src 'none'; style-src 'unsafe-inline'; font-src data:; img-src data:; script-src 'nonce-" . $nonce . "'");
        $html = preg_replace('/<meta\s+http-equiv="Content-Security-Policy"[^>]*>/i', '', $html);
        $tabs = '';
        if ($has_full) {
            $tabs = '<a class="' . ($full === null ? 'on' : '') . '" href="' . esc_url(add_query_arg(array('view' => false, 'print' => false))) . '">خلاصه گزارش</a>'
                . '<a class="' . ($full !== null ? 'on' : '') . '" href="' . esc_url(add_query_arg(array('view' => 'full', 'print' => false))) . '">گزارش کامل</a>';
        }
        $bar = '<style>.mzc-bar{position:fixed;top:8px;left:8px;z-index:9;display:flex;gap:6px;font:14px Tahoma,sans-serif}.mzc-bar button,.mzc-bar a{padding:8px 18px;border:0;border-radius:6px;background:#0b6;color:#fff;cursor:pointer;text-decoration:none}.mzc-bar a{background:#e9e9e4;color:#222}.mzc-bar a.on{background:#222;color:#fff}@media print{.mzc-bar{display:none}}</style>'
            . '<div class="mzc-bar">' . $tabs . '<button id="mzc-print" type="button">چاپ</button></div>'
            . '<script nonce="' . $nonce . '">document.getElementById("mzc-print").addEventListener("click",function(){window.print()});' . ($print ? 'window.addEventListener("load",function(){window.print()});' : '') . '</script>';
        echo stripos($html, '</body>') !== false ? preg_replace('/<\/body>/i', $bar . '</body>', $html, 1) : $html . $bar;
        exit;
    }

    public static function act_report()
    {
        if (!self::can()) { wp_die('اجازه دیدن گزارش‌ها را ندارید.', '', array('response' => 403)); }
        self::show_report(isset($_GET['id']) ? (string) $_GET['id'] : '', !empty($_GET['print']));
    }

    public static function number($v)
    {
        $v = (float) $v;
        return rtrim(rtrim(number_format($v, abs($v) >= 100 ? 0 : 2, '.', ','), '0'), '.');
    }

    /** A shared page as it was kept (created, app, owner, cpu, gpu, os, ramGb, rows), or null. */
    private static function share($token)
    {
        $db = self::db(); if (!$db || !preg_match('/^[0-9a-f]{24}$/', (string) $token)) { return null; }
        $s = $db->get_row($db->prepare('SELECT * FROM `' . self::t('shares') . '` WHERE token = %s', $token), ARRAY_A); if (!$s) { return null; }
        $rows = (array) $db->get_results($db->prepare('SELECT benchmark, name, settings, value, unit, part, at, version FROM `' . self::t('share_rows') . '` WHERE token = %s ORDER BY pos', $token), ARRAY_A);
        foreach ($rows as &$r) { $r['value'] = (float) $r['value']; $r['version'] = (int) $r['version']; $r['at'] = self::iso($r['at']); } unset($r);
        return array('created' => self::iso($s['created']), 'app' => $s['app'], 'owner' => $s['owner'], 'cpu' => $s['cpu'], 'gpu' => $s['gpu'], 'os' => $s['os'], 'ramGb' => $s['ram_gb'] !== null ? (float) $s['ram_gb'] : null, 'rows' => $rows);
    }

    private static function drop_share($token) { $db = self::db(); if ($db) { $db->delete(self::t('share_rows'), array('token' => $token)); $db->delete(self::t('shares'), array('token' => $token)); } }

    /** A user's shared results, drawn by the site from the numbers it kept (no HTML came from outside). */
    private static function show_share($token)
    {
        $s = self::share($token);
        if (!is_array($s) || empty($s['rows'])) { wp_die('این نتیجه پیدا نشد.', '', array('response' => 404)); }
        self::page_headers("default-src 'none'; style-src 'unsafe-inline'");
        $e = 'esc_html';
        $spec = array();
        $owner = isset($s['owner']) && $s['owner'] !== '' ? $s['owner'] : 'کاربر مازستا';
        if ($s['cpu'] !== '') { $spec[] = array('پردازنده', $s['cpu']); }
        if ($s['gpu'] !== '') { $spec[] = array('کارت گرافیک', $s['gpu']); }
        if (!empty($s['ramGb'])) { $spec[] = array('حافظه', self::number($s['ramGb']) . ' GB'); }
        if ($s['os'] !== '') { $spec[] = array('سیستم‌عامل', $s['os']); }
        echo '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex">'
            . '<title>نتایج بنچمارک Mazesta Test</title><style>'
            . 'body{margin:0;background:#0e1012;color:#e8eaed;font:15px/1.8 Tahoma,Vazirmatn,sans-serif}main{max-width:820px;margin:0 auto;padding:28px 16px}'
            . 'h1{font-size:22px;margin:0 0 4px}h1 b{color:#fdd400}.sub{color:#8a9097;margin:0 0 20px}.box{background:#16191c;border:1px solid #262a2f;border-radius:10px;padding:14px 18px;margin:0 0 16px}'
            . 'dl{display:grid;grid-template-columns:auto 1fr;gap:2px 16px;margin:0}dt{color:#8a9097}dd{margin:0;direction:ltr;text-align:right;unicode-bidi:isolate}'
            . 'table{width:100%;border-collapse:collapse}th,td{padding:9px 8px;border-bottom:1px solid #262a2f;text-align:right}th{color:#8a9097;font-weight:normal;font-size:13px}'
            . '.n{direction:ltr;unicode-bidi:isolate;font-weight:bold;color:#fff;white-space:nowrap}.n small{color:#fdd400;font-weight:normal}.p{direction:ltr;unicode-bidi:isolate;color:#c3c7cc;font-size:13px}'
            . '.warn{background:#2a1a12;border-color:#7a3a1a;color:#f0c8a0}.warn p{margin:6px 0 0}.old{background:#7a3a1a;color:#fff;border-radius:3px;padding:0 6px;font-size:11px;white-space:nowrap}'
            . 'footer{color:#8a9097;font-size:13px;margin-top:18px}a{color:#fdd400}'
            . '</style></head><body><main><h1>نتایج بنچمارک <b>Mazesta Test</b></h1><p class="sub">' . $e($owner) . ' · ثبت‌شده در ' . $e(MZC_Crm::jtime((int) strtotime($s['created']))) . '</p>';
        if ($spec) {
            echo '<div class="box"><dl>';
            foreach ($spec as $row) { echo '<dt>' . $e($row[0]) . '</dt><dd>' . $e($row[1]) . '</dd>'; }
            echo '</dl></div>';
        }
        $stale = 0;
        foreach ($s['rows'] as $r) { if (isset($r['version']) && self::is_old($r['benchmark'], $r['version'])) { $stale++; } }
        $old_app = !empty($s['app']) && self::old_app($s['app']) ? $s['app'] : '';
        if ($stale > 0 || $old_app !== '') {
            echo '<div class="box warn"><strong>این نتایج با نسخه قدیمی برنامه گرفته شده‌اند.</strong>';
            if ($stale > 0) { echo '<p>' . $e($stale === 1 ? 'یکی از بنچمارک‌های این صفحه' : $stale . ' بنچمارک این صفحه') . ' (با برچسب «نسخه قدیمی») با کار قدیمی‌تر برنامه اندازه‌گرفته شده است؛ صحنه یا روش امتیازدهی بعد از آن عوض شده و عددش با نتیجه‌های امروز قابل مقایسه نیست.</p>'; }
            if ($old_app !== '') { echo '<p>این نتایج را نسخه <span dir="ltr">' . $e($old_app) . '</span> برنامه گرفته؛ آخرین نسخه <span dir="ltr">' . $e((string) self::latest_app()) . '</span> است.</p>'; }
            echo '<p>بهتر است Mazesta Test را از بخش به‌روزرسانی داخل خودش به‌روز کنید و بنچمارک را دوباره اجرا کنید.</p></div>';
        }
        echo '<div class="box"><table><thead><tr><th>بنچمارک</th><th>نتیجه</th><th>قطعه</th><th>تاریخ اجرا</th></tr></thead><tbody>';
        foreach ($s['rows'] as $r) {
            echo '<tr><td>' . $e($r['name']) . (isset($r['version']) && self::is_old($r['benchmark'], $r['version']) ? ' <span class="old">نسخه قدیمی</span>' : '') . ($r['settings'] !== '' ? ' <span class="p">' . $e($r['settings']) . '</span>' : '') . '</td><td class="n">' . $e(self::number($r['value'])) . ' <small>' . $e($r['unit']) . '</small></td>'
                . '<td class="p">' . $e($r['part']) . '</td><td>' . $e(MZC_Crm::jdate(MZC_Crm::ymd((int) strtotime($r['at'])))) . '</td></tr>';
        }
        echo '</tbody></table></div><footer>این اعداد را برنامه Mazesta Test روی همین سیستم اندازه گرفته و کاربر آن فرستاده است. <a href="' . esc_url(home_url('/')) . '">' . $e(get_bloginfo('name')) . '</a></footer></main></body></html>';
        exit;
    }

    /** A shared result by its link; and a report by its link (a 128-bit random token), for a colleague without an account, only while the shop has switched links on. */
    public static function public_pages()
    {
        if (!empty($_GET['mazesta_share'])) { self::show_share((string) $_GET['mazesta_share']); }
        if (empty($_GET['mazesta_report'])) { return; }
        $token = (string) $_GET['mazesta_report']; $c = self::config();
        $id = null;
        if (!empty($c['publicLinks']) && preg_match('/^[0-9a-f]{32}$/', $token)) {
            foreach (self::read('reports') as $rid => $r) { if (isset($r['token']) && hash_equals((string) $r['token'], $token)) { $id = (string) $rid; break; } }
        }
        if ($id === null) { wp_die('گزارش پیدا نشد.', '', array('response' => 404)); }
        self::show_report($id, !empty($_GET['print']));
    }

    /* ---------- dashboard ---------- */

    public static function guard($action)
    {
        if (!self::can()) { wp_die('اجازه این کار را ندارید.', '', array('response' => 403)); }
        check_admin_referer('mzc_' . $action);
    }

    public static function back($tab, $msg = '')
    {
        wp_safe_redirect(add_query_arg(array('page' => 'mazesta-connect', 'tab' => $tab, 'msg' => $msg), admin_url('admin.php')));
        exit;
    }

    public static function post_link($action, $args, $label, $class = 'button button-small', $confirm = '')
    {
        $url = wp_nonce_url(add_query_arg(array('action' => 'mzc_' . $action) + $args, admin_url('admin-post.php')), 'mzc_' . $action);
        return '<a class="' . esc_attr($class) . '" href="' . esc_url($url) . '"' . ($confirm !== '' ? ' onclick="return confirm(\'' . esc_js($confirm) . '\')"' : '') . '>' . esc_html($label) . '</a>';
    }

    public static function arg($name) { return isset($_GET[$name]) ? sanitize_text_field(wp_unslash($_GET[$name])) : ''; }

    public static function act_report_delete()
    {
        self::guard('report_delete');
        $id = self::arg('id');
        if (preg_match('/^[A-Za-z0-9-]{8,64}$/', $id)) {
            self::locked(function () use ($id) { $all = self::read('reports'); unset($all[$id]); self::write('reports', $all); self::remove('report-' . $id); self::remove('report-' . $id . '-full'); self::remove('report-' . $id . '-fig'); });
        }
        self::back('reports', 'deleted');
    }

    /** Runs $sql (an UPDATE or DELETE of bench_runs, with %s for the run's id when $id is given) and builds the lists again. */
    private static function change_runs($sql, $id = null)
    {
        $db = self::db(); if (!$db) { return; }
        $db->query($id === null ? $sql : $db->prepare($sql, $id));
        self::rebuild();
    }

    public static function act_run_approve()
    {
        self::guard('run_approve');
        $id = self::arg('id'); $tb = self::t('bench_runs');
        if (!empty($_GET['all'])) { self::change_runs("UPDATE `$tb` SET approved = 1 WHERE approved = 0"); } else { self::change_runs("UPDATE `$tb` SET approved = 1 WHERE id = %s", $id); }
        self::back('bench', 'approved');
    }

    public static function act_run_delete()
    {
        self::guard('run_delete');
        self::change_runs('DELETE FROM `' . self::t('bench_runs') . '` WHERE id = %s', self::arg('id'));
        self::back('bench', 'deleted');
    }

    /** Whole lists at once: the ticked ones, or (old=1) every list of a workload older than its benchmark's newest. The runs go, then the lists are built again. */
    public static function act_list_delete()
    {
        self::guard('list_delete');
        $db = self::db(); $tb = self::t('bench_runs');
        $keys = isset($_POST['lists']) && is_array($_POST['lists']) ? array_map('sanitize_text_field', wp_unslash($_POST['lists'])) : array();
        if (!empty($_POST['old']) && $db) {
            $l = self::latest_versions();
            foreach ((array) $db->get_col("SELECT DISTINCT list FROM `$tb`") as $k) {
                if (preg_match('/^([A-Za-z0-9._-]+)@(\d+)/', (string) $k, $m) && isset($l[$m[1]]) && (int) $m[2] < (int) $l[$m[1]]) { $keys[] = $k; }
            }
        }
        $n = 0;
        foreach ($db ? array_unique($keys) : array() as $k) { $n += (int) $db->query($db->prepare("DELETE FROM `$tb` WHERE list = %s", $k)); }
        if ($n > 0) { self::rebuild(); }
        self::back('bench', $n > 0 ? 'deleted' : 'nothing');
    }

    public static function act_run_feature()
    {
        self::guard('run_feature');
        self::change_runs('UPDATE `' . self::t('bench_runs') . '` SET featured = ' . (empty($_GET['off']) ? 1 : 0) . ", mark_at = '" . gmdate('Y-m-d H:i:s') . "' WHERE id = %s", self::arg('id'));
        self::back('bench', 'saved');
    }

    /** The ticked users' results go straight into the comparison lists (as approved runs, no review): the numbers are the ones the app sent with its share. */
    public static function act_share_add()
    {
        self::guard('share_add');
        $tokens = isset($_POST['tokens']) && is_array($_POST['tokens']) ? array_slice(array_map('sanitize_text_field', wp_unslash($_POST['tokens'])), 0, 300) : array();
        $db = self::db(); $higher = array();
        foreach ($db ? (array) $db->get_results('SELECT DISTINCT list, higher FROM `' . self::t('bench_runs') . '`', ARRAY_A) : array() as $r) { $higher[strtok($r['list'], '@')] = (bool) $r['higher']; }
        $runs = array();
        foreach ($tokens as $t) {
            $sh = self::share($t);
            if (!is_array($sh) || empty($sh['rows'])) { continue; }
            foreach ($sh['rows'] as $i => $row) {
                $o = new stdClass();
                $o->id = self::share_run_id($t, $row);
                // one result per user in a list and part: a newer one takes the older one's place (an equal or older one is the same, and stays)
                if ($db) { $db->query($db->prepare('DELETE FROM `' . self::t('bench_runs') . '` WHERE id = %s AND run_at < %s', $o->id, MZC_Stats::dt($row['at']))); }
                $o->system = 'share' . $t; $o->at = $row['at']; $o->benchmark = $row['benchmark']; $o->version = (int) $row['version'];
                $o->settings = $row['settings']; $o->part = $row['part']; $o->spec = $row['part']; $o->value = (float) $row['value']; $o->unit = $row['unit'];
                if (!empty($sh['app'])) { $o->app = $sh['app']; }
                $runs[] = $o;
            }
        }
        list($added) = self::add_runs($runs, $higher, true);
        if ($added > 0) { self::rebuild(); }
        self::back('shares', $added > 0 ? 'saved' : 'nothing');
    }

    /** A share's row as a run's id: the same user, benchmark, version, settings and part always give the same id, so adding twice never doubles it. */
    private static function share_run_id($token, $row)
    {
        return 'sh' . substr(md5($token . '|' . $row['benchmark'] . '|' . (int) $row['version'] . '|' . $row['settings'] . '|' . $row['part']), 0, 20);
    }

    public static function act_share_delete()
    {
        self::guard('share_delete');
        $token = self::arg('token');
        if (preg_match('/^[0-9a-f]{24}$/', $token)) { self::drop_share($token); }
        self::back('shares', 'deleted');
    }

    public static function act_rebuild()
    {
        self::guard('rebuild');
        self::rebuild();
        self::back('bench', 'rebuilt');
    }

    public static function act_settings()
    {
        self::guard('settings');
        if (!current_user_can('manage_options')) { wp_die('فقط مدیر سایت می‌تواند تنظیمات را عوض کند.', '', array('response' => 403)); }
        self::config();
        self::locked(function () {
            $c = self::read('config');
            $c['openUploads'] = !empty($_POST['open_uploads']); $c['publicLinks'] = !empty($_POST['public_links']); $c['sharing'] = !empty($_POST['sharing']);
            if (!empty($_POST['new_key'])) { $c['key'] = self::new_key(); }
            if (!empty($_POST['new_release_key'])) { $c['releaseKey'] = self::new_key(); }
            if (!empty($_POST['new_read_key'])) { $c['readKey'] = self::new_key(); }
            $h = isset($_POST['ip_header']) ? (string) wp_unslash($_POST['ip_header']) : ''; $c['ipHeader'] = isset(self::$ip_headers[$h]) ? $h : '';
            self::write('config', $c);
        });
        self::back('settings', 'saved');
    }

    public static function local($iso) { return esc_html(MZC_Crm::jtime((int) strtotime((string) $iso))); }

    public static function page()
    {
        if (!self::can()) { wp_die('اجازه دیدن این صفحه را ندارید.', '', array('response' => 403)); }
        $tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'reports';
        $tabs = array('reports' => 'گزارش‌ها', 'bench' => 'بنچمارک‌ها', 'shares' => 'نتایج کاربران', 'settings' => 'تنظیمات و انتشار');
        if (!isset($tabs[$tab])) { $tab = 'reports'; }
        MZC_Admin::open('mazesta-connect', 'گزارش‌ها و بنچمارک‌ها');
        echo '<h2 class="nav-tab-wrapper">';
        foreach ($tabs as $k => $label) {
            echo '<a class="nav-tab' . ($k === $tab ? ' nav-tab-active' : '') . '" href="' . esc_url(admin_url('admin.php?page=mazesta-connect&tab=' . $k)) . '">' . esc_html($label) . '</a>';
        }
        echo '</h2>';
        if (!empty($_GET['pair'])) { self::pair_panel(strtolower(self::arg('pair'))); }
        if (!empty($_GET['msg'])) { echo '<div class="notice notice-success is-dismissible"><p>انجام شد.</p></div>'; }
        if ($tab === 'reports') { self::tab_reports(); } elseif ($tab === 'bench') { self::tab_bench(); } elseif ($tab === 'shares') { self::tab_shares(); } else { self::tab_settings(); }
        MZC_Admin::close();
    }

    private static function tab_reports()
    {
        $s = self::arg('s'); $c = self::config();
        $paged = max(1, isset($_GET['paged']) ? (int) $_GET['paged'] : 1); $per = 30;
        list($rows, $total) = self::reports($s, $per, ($paged - 1) * $per);
        $links = !empty($c['publicLinks']);
        $verdicts = array('Passed' => 'سالم', 'Failed' => 'ایراد دارد', 'Incomplete' => 'ناقص', '' => 'بنچمارک');
        echo '<form method="get" class="mzc-my"><input type="hidden" name="page" value="mazesta-connect"><input type="hidden" name="tab" value="reports">'
            . '<input type="search" name="s" value="' . esc_attr($s) . '" placeholder="شماره سرویس، مدل دستگاه، سیستم، توضیحات…"> <button class="button">جستجو</button> <span class="description">' . esc_html(number_format_i18n($total)) . ' گزارش</span></form>';
        echo '<table class="widefat striped"><thead><tr><th>تاریخ</th><th>شماره سرویس</th><th>مدل دستگاه</th><th>سیستم</th><th>نتیجه</th><th>خلاصه</th><th></th></tr></thead><tbody>';
        if (!$rows) { echo '<tr><td colspan="7">هنوز گزارشی از برنامه نرسیده است. در برنامه: گزارش‌ها › ارسال به سایت.</td></tr>'; }
        foreach ($rows as $id => $r) {
            $view = admin_url('admin-post.php?action=mzc_report&id=' . rawurlencode((string) $id));
            echo '<tr><td>' . self::local($r['created']) . '</td><td><strong>' . esc_html($r['service']) . '</strong>' . ($r['stage'] !== '' ? ' <span class="description">(' . ($r['stage'] === 'Before' ? 'قبل از سرویس' : 'بعد از سرویس') . ')</span>' : '') . '</td><td dir="ltr" class="mzc-ltr-r">' . esc_html(isset($r['device']) ? $r['device'] : '') . (!empty($r['laptop']) ? ' <span class="description">(لپ‌تاپ)</span>' : '') . '</td><td dir="ltr" class="mzc-ltr-r">' . esc_html($r['machine']) . '</td>'
                . '<td>' . esc_html(isset($verdicts[$r['verdict']]) ? $verdicts[$r['verdict']] : $r['verdict']) . '</td><td>' . esc_html(mb_substr((string) $r['summary'], 0, 140)) . '</td><td class="mzc-nowrap">'
                . '<a class="button button-small button-primary" target="_blank" href="' . esc_url($view . '&print=1') . '">چاپ</a> <a class="button button-small" target="_blank" href="' . esc_url($view) . '">خلاصه</a> '
                . ($r['has_full'] ? '<a class="button button-small" target="_blank" href="' . esc_url($view . '&view=full') . '">گزارش کامل</a> ' : '')
                . ($links && !empty($r['token']) ? '<a class="button button-small" target="_blank" href="' . esc_url(home_url('/?mazesta_report=' . $r['token'])) . '">پیوند</a> ' : '')
                . self::post_link('report_delete', array('id' => (string) $id), 'حذف', 'button button-small', 'این گزارش از سایت پاک شود؟') . '</td></tr>';
        }
        echo '</tbody></table>';
        $pages = (int) ceil($total / $per);
        if ($pages > 1) {
            echo '<div class="tablenav"><div class="tablenav-pages">' . paginate_links(array('base' => add_query_arg('paged', '%#%'), 'format' => '', 'current' => $paged, 'total' => $pages)) . '</div></div>';
        }
    }

    private static function value_text($r) { return esc_html(self::number($r['value']) . ' ' . $r['unit']); }

    private static function tab_bench()
    {
        $db = self::db(); if (!$db) { echo '<p>' . esc_html(MZC_Crm_Db::error() ?: 'پایگاه دادهٔ CRM آماده نیست.') . '</p>'; return; }
        $tb = self::t('bench_runs'); $cols = 'id, list AS `table`, part, value, unit, featured, run_at AS runAt, received';
        $pending = array(); foreach ((array) $db->get_results("SELECT $cols FROM `$tb` WHERE approved = 0 ORDER BY received DESC LIMIT 200", ARRAY_A) as $r) { $pending[$r['id']] = $r; }
        $lists = array(); $approved = 0;
        foreach ((array) $db->get_results("SELECT list, COUNT(*) AS runs, COUNT(DISTINCT part) AS parts, MAX(received) AS last FROM `$tb` WHERE approved = 1 GROUP BY list ORDER BY list", ARRAY_A) as $l) {
            $lists[$l['list']] = array('runs' => (int) $l['runs'], 'parts' => (int) $l['parts'], 'last' => $l['last']); $approved += (int) $l['runs'];
        }
        echo '<p>' . esc_html(number_format_i18n($approved)) . ' اجرای تأییدشده در ' . esc_html(number_format_i18n(count($lists))) . ' فهرست. '
            . self::post_link('rebuild', array(), 'ساخت دوباره فهرست‌ها') . '</p>';
        echo '<p class="description">این‌جا فقط نتایجی است که خود برنامه Mazesta Test اندازه گرفته و فرستاده است؛ هیچ عددی دستی یا نمونه وارد نمی‌شود.</p>';
        echo '<h3>در انتظار بررسی (' . esc_html(number_format_i18n(count($pending))) . ')</h3>';
        if ($pending) {
            echo '<p>' . self::post_link('run_approve', array('all' => 1), 'تأیید همه', 'button button-primary', 'همه اجراهای در انتظار وارد فهرست‌ها شوند؟') . '</p>';
            echo '<table class="widefat striped"><thead><tr><th>بنچمارک</th><th>قطعه</th><th>نتیجه</th><th>زمان اجرا</th><th></th></tr></thead><tbody>';
            foreach ($pending as $id => $r) {
                echo '<tr><td>' . self::list_label($r['table']) . '</td><td dir="ltr" class="mzc-ltr-r">' . esc_html($r['part']) . '</td><td dir="ltr" class="mzc-ltr-r">' . self::value_text($r) . '</td><td>' . self::local($r['runAt']) . '</td><td>'
                    . self::post_link('run_approve', array('id' => (string) $id), 'تأیید', 'button button-small button-primary') . ' ' . self::post_link('run_delete', array('id' => (string) $id), 'حذف', 'button button-small', 'این اجرا پاک شود؟') . '</td></tr>';
            }
            echo '</tbody></table>';
        } else { echo '<p class="description">چیزی در انتظار نیست. اجراهایی که با کلید سایت (از نسخه مازستایی برنامه) می‌رسند مستقیم وارد فهرست می‌شوند.</p>'; }
        $old = self::latest_versions();
        echo '<h3>فهرست‌ها</h3><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="mzc_list_delete">' . wp_nonce_field('mzc_list_delete', '_wpnonce', true, false)
            . '<p><button class="button" onclick="return confirm(\'همه اجراهای فهرست‌های انتخاب‌شده پاک شوند؟ برنمی‌گردد.\')">حذف فهرست‌های انتخاب‌شده</button> '
            . '<button class="button" name="old" value="1" onclick="return confirm(\'همه فهرست‌های نسخه قدیمی (هر بنچمارکی که نسخه تازه‌تری دارد) پاک شوند؟ برنمی‌گردد.\')">حذف همه نسخه‌های قدیمی</button></p>'
            . '<p class="description">هر بنچمارک یک فهرست مقایسه دارد (و اگر تنظیمی مثل اندازه فایل داشته باشد، برای هر تنظیم یک فهرست). روی نام فهرست بزنید تا اجراهایش را ببینید و نتیجه مرجع انتخاب کنید. نوشته کوچک زیر هر نام، شناسه فنی همان فهرست در برنامه است.</p>'
            . '<table class="widefat striped"><thead><tr><th><input type="checkbox" onclick="var t=this;document.querySelectorAll(\'.mzc-list\').forEach(function(c){c.checked=t.checked})"></th><th>بنچمارک (فهرست)</th><th>تعداد مدل قطعه</th><th>تعداد اجرا</th><th>آخرین دریافت</th></tr></thead><tbody>';
        if (!$lists) { echo '<tr><td colspan="5">هنوز اجرایی بارگذاری نشده است. در برنامه: بنچمارک › ارسال نتایج به سایت.</td></tr>'; }
        foreach ($lists as $t => $l) {
            $stale = preg_match('/^([A-Za-z0-9._-]+)@(\d+)/', $t, $m) && isset($old[$m[1]]) && (int) $m[2] < (int) $old[$m[1]];
            echo '<tr><td><input type="checkbox" class="mzc-list" name="lists[]" value="' . esc_attr($t) . '"></td><td><a href="' . esc_url(admin_url('admin.php?page=mazesta-connect&tab=bench&list=' . rawurlencode($t))) . '">' . self::list_label($t) . '</a>' . ($stale ? ' <span class="mzc-bad-text">(نسخه قدیمی)</span>' : '') . '</td><td>' . $l['parts'] . '</td><td>' . (int) $l['runs'] . '</td><td>' . self::local($l['last']) . '</td></tr>';
        }
        echo '</tbody></table></form>';
        $key = self::arg('list');
        if ($key !== '') {
            $runs = array(); foreach ((array) $db->get_results($db->prepare("SELECT $cols FROM `$tb` WHERE approved = 1 AND list = %s ORDER BY value DESC LIMIT 500", $key), ARRAY_A) as $r) { $runs[$r['id']] = $r; }
            echo '<h3>' . self::list_label($key) . '</h3><p class="description">«نتیجه مرجع» (★) اجرایی است که مازستا تأیید می‌کند نتیجه درست این مدل در این بنچمارک است. مدلی که نتیجه مرجع داشته باشد در برنامه با <strong>میانه نتایج مرجعش</strong> نشان داده می‌شود (با برچسب «مرجع»)؛ مدلی که ندارد با میانه همه سیستم‌هایش. نتیجه مرجع را فقط از همین‌جا یا از نسخه مازستایی برنامه می‌توان انتخاب کرد؛ کاربران نمی‌توانند.</p><table class="widefat striped"><thead><tr><th>قطعه</th><th>نتیجه</th><th>زمان اجرا</th><th></th></tr></thead><tbody>';
            foreach (array_slice($runs, 0, 500, true) as $id => $r) {
                $star = !empty($r['featured']);
                echo '<tr><td dir="ltr" class="mzc-ltr-r">' . ($star ? '★ ' : '') . esc_html($r['part']) . '</td><td dir="ltr" class="mzc-ltr-r">' . self::value_text($r) . '</td><td>' . self::local($r['runAt']) . '</td><td>'
                    . self::post_link('run_feature', $star ? array('id' => (string) $id, 'off' => 1) : array('id' => (string) $id), $star ? 'برداشتن از مرجع' : 'انتخاب به‌عنوان نتیجه مرجع') . ' '
                    . self::post_link('run_delete', array('id' => (string) $id), 'حذف', 'button button-small', 'این اجرا پاک شود؟') . '</td></tr>';
            }
            echo '</tbody></table>';
        }
    }

    private static function tab_shares()
    {
        $db = self::db(); $tb = self::t('shares');
        $index = $db ? (array) $db->get_results("SELECT s.token, s.created, s.owner, s.cpu, s.gpu, (SELECT COUNT(*) FROM `" . self::t('share_rows') . "` r WHERE r.token = s.token) AS `rows` FROM `$tb` s ORDER BY s.created DESC LIMIT 300", ARRAY_A) : array();
        echo '<p class="description">نتیجه‌هایی که کاربران از برنامه با «اشتراک‌گذاری آخرین نتیجه» فرستاده‌اند. هر سیستم یک صفحه دارد و با فرستادن دوباره همان صفحه تازه می‌شود. تازه‌شدن خودکار وارد لیست بنچمارک‌ها نمی‌شود: سطر آن سیستم زرد می‌شود و به اول جدول می‌آید تا دوباره تأییدش کنید.</p>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="mzc_share_add">'; wp_nonce_field('mzc_share_add');
        echo '<p><button class="button button-primary" onclick="return confirm(\'نتیجه‌های انتخاب‌شده در لیست بنچمارک‌ها بروند؟\')">افزودن انتخاب‌شده‌ها به لیست بنچمارک‌ها</button> <label><input type="checkbox" onclick="var t=this;document.querySelectorAll(\'.mzc-pick\').forEach(function(c){c.checked=t.checked})"> همه</label></p>';
        // A page is "in the list" when every one of its results is there at least as new as the page's own.
        $in = array(); $held = array(); $had = array();   // $had: a result of this page went into the lists before (so a page that is not "in" now was sent again, newer)
        if ($db && $index) {
            foreach ((array) $db->get_results('SELECT id, run_at FROM `' . self::t('bench_runs') . "` WHERE id LIKE 'sh%'", ARRAY_A) as $h) { $held[$h['id']] = $h['run_at']; }
            foreach ((array) $db->get_results('SELECT token, benchmark, version, settings, part, at FROM `' . self::t('share_rows') . '`', ARRAY_A) as $r) {
                $id = self::share_run_id($r['token'], $r); $ok = isset($held[$id]) && $held[$id] >= MZC_Stats::dt($r['at']);
                $in[$r['token']] = (isset($in[$r['token']]) ? $in[$r['token']] : true) && $ok;
                if (isset($held[$id])) { $had[$r['token']] = true; }
            }
        }
        echo '<table class="widefat"><thead><tr><th></th><th>تاریخ</th><th>نام</th><th>پردازنده</th><th>کارت گرافیک</th><th>بنچمارک</th><th>در لیست</th><th></th></tr></thead><tbody>';
        if (!$index) { echo '<tr><td colspan="8">هنوز کسی نتیجه‌ای به اشتراک نگذاشته است.</td></tr>'; }
        foreach (array_slice($index, 0, 300, true) as $s) {
            $added = !empty($in[$s['token']]); $again = !$added && !empty($had[$s['token']]);
            echo '<tr' . ($added ? ' style="background:#e6f4ea"' : ($again ? ' style="background:#fff4d6"' : '')) . '><td><input type="checkbox" class="mzc-pick" name="tokens[]" value="' . esc_attr($s['token']) . '"></td><td>' . self::local($s['created']) . '</td><td>' . esc_html(isset($s['owner']) && $s['owner'] !== '' ? $s['owner'] : 'کاربر مازستا') . '</td><td dir="ltr" class="mzc-ltr-r">' . esc_html($s['cpu']) . '</td><td dir="ltr" class="mzc-ltr-r">' . esc_html($s['gpu']) . '</td><td>' . (int) $s['rows'] . '</td><td>' . ($added ? '<strong style="color:#137333">✔ رفته</strong>' : ($again ? '<strong style="color:#b06000">نتیجهٔ تازه فرستاده؛ دوباره تأیید کنید</strong>' : '—')) . '</td><td>'
                . '<a class="button button-small" target="_blank" href="' . esc_url(home_url('/?mazesta_share=' . $s['token'])) . '">دیدن</a> '
                . self::post_link('share_delete', array('token' => (string) $s['token']), 'حذف', 'button button-small', 'این صفحه پاک شود؟') . '</td></tr>';
        }
        echo '</tbody></table></form>';
    }

    private static function tab_settings()
    {
        $admin = current_user_can('manage_options'); $c = self::config();
        $dir = self::release_dir(); $manifest = is_readable($dir . '/update.json') ? json_decode((string) file_get_contents($dir . '/update.json'), true) : null;
        echo '<h3>نسخه منتشرشده برنامه</h3>';
        if (is_array($manifest) && isset($manifest['app']['version'])) {
            $zip = $dir . '/' . basename((string) $manifest['app']['file']);
            echo '<p>نسخه <strong dir="ltr">' . esc_html($manifest['app']['version']) . '</strong>، ' . esc_html(size_format((int) $manifest['app']['size'])) . '، فایل <code dir="ltr">' . esc_html($manifest['app']['file']) . '</code> '
                . (is_file($zip) ? '✔' : '<strong class="mzc-bad-text">روی سایت نیست</strong>') . ' ' . (is_file($dir . '/update.json.sig') ? '' : '<strong class="mzc-bad-text">امضا (update.json.sig) نیست</strong>') . '</p>';
        } else {
            echo '<p>هنوز نسخه‌ای منتشر نشده است. روی سیستم مازستا: <code dir="ltr">pwsh tools/release.ps1 -App -NotesFa notes-fa.txt -Upload</code></p>';
        }
        echo '<p class="description">برنامه‌ها این نشانی را می‌خوانند: <code dir="ltr">' . esc_html(home_url('/mazesta/update.json')) . '</code> — این پوشه را از کش مستثنا کنید.</p>';
        echo '<p class="description">داده‌های این افزونه در پایگاه داده وردپرس نیست؛ همه در پایگاه دادهٔ CRM است (هر بخش جدول خودش، پیشوند <code dir="ltr">' . esc_html(MZC_Crm_Db::prefix()) . '</code>). فقط کلیدها و اتصال همان پایگاه داده در این پوشه است: <code dir="ltr">' . esc_html(self::dir()) . '</code> (برای پشتیبان‌گیری، از آن پایگاه داده و این پوشه نسخه بگیرید).</p>'
            . (self::db() ? '' : '<p><strong class="mzc-bad-text">' . esc_html(MZC_Crm_Db::error() ?: 'پایگاه دادهٔ CRM آماده نیست.') . ' تا وقتی تنظیم نشود، گزارش‌ها، بنچمارک‌ها، آمار و پیام‌ها ذخیره نمی‌شوند.</strong></p>');
        if (!$admin) { return; }
        echo '<h3>کلیدها و تنظیمات</h3><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '"><input type="hidden" name="action" value="mzc_settings">';
        wp_nonce_field('mzc_settings');
        echo '<table class="form-table"><tr><th>کلید سایت</th><td><code dir="ltr" class="mzc-copy">' . esc_html((string) $c['key']) . '</code><p class="description">در نسخه مازستایی برنامه: به‌روزرسانی برنامه › اتصال به سایت مازستا. روی هر سیستمی که باید گزارش بفرستد یک بار وارد می‌شود و با پوشه Data برنامه جابه‌جا می‌شود.</p>'
            . '<label><input type="checkbox" name="new_key" value="1"> کلید تازه بساز (کلید قبلی از کار می‌افتد)</label></td></tr>'
            . '<tr><th>کلید انتشار</th><td><code dir="ltr" class="mzc-copy">' . esc_html((string) $c['releaseKey']) . '</code><p class="description">فقط روی سیستمی که نسخه تازه برنامه را منتشر می‌کند (فایل <code dir="ltr">G:\\Mazesta-Keys\\site-release-key.txt</code>). به کسی ندهید.</p>'
            . '<label><input type="checkbox" name="new_release_key" value="1"> کلید تازه بساز</label></td></tr>'
            . '<tr><th>کلید خواندن گزارش‌ها</th><td><code dir="ltr" class="mzc-copy">' . esc_html((string) $c['readKey']) . '</code><p class="description">برای برنامه چاپ گزارش‌ها روی سیستم منشی: فقط می‌تواند فهرست گزارش‌ها را بخواند و خلاصه‌شان را ببیند، چیزی نمی‌فرستد.</p>'
            . '<label><input type="checkbox" name="new_read_key" value="1"> کلید تازه بساز</label></td></tr>'
            . '<tr><th>اشتراک‌گذاری کاربران</th><td><label><input type="checkbox" name="sharing" value="1"' . checked(!empty($c['sharing']), true, false) . '> کاربران بتوانند آخرین نتیجه بنچمارکشان را بدون کلید بفرستند و پیوند صفحه آن را بگیرند</label></td></tr>'
            . '<tr><th>بارگذاری بدون کلید</th><td><label><input type="checkbox" name="open_uploads" value="1"' . checked(!empty($c['openUploads']), true, false) . '> نتیجه کاربران بدون کلید به صف بررسی فهرست‌های مقایسه هم برود (بعد از تأیید شما وارد فهرست می‌شود)</label></td></tr>'
            . '<tr><th>پیوند گزارش</th><td><label><input type="checkbox" name="public_links" value="1"' . checked(!empty($c['publicLinks']), true, false) . '> هر گزارش با پیوند خودش بدون ورود به سایت هم باز شود (هر کس پیوند را داشته باشد گزارش را می‌بیند)</label></td></tr>';
        // what this request looks like from here, so the right header (if any) can be picked
        $seen = array('REMOTE_ADDR: ' . (isset($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '—'));
        foreach (self::$ip_headers as $h => $l) { if (!empty($_SERVER[$h])) { $seen[] = $l . ': ' . (string) $_SERVER[$h]; } }
        $opts = '<option value="">همان REMOTE_ADDR (پیش‌فرض)</option>';
        foreach (self::$ip_headers as $h => $l) { $opts .= '<option value="' . esc_attr($h) . '"' . selected(isset($c['ipHeader']) ? $c['ipHeader'] : '', $h, false) . '>' . esc_html($l) . '</option>'; }
        echo '<tr><th>نشانی بازدیدکننده</th><td><select name="ip_header">' . $opts . '</select><p class="description">آنچه از همین درخواست شما دیده می‌شود: <code dir="ltr">' . esc_html(implode('  |  ', $seen)) . '</code>. اگر REMOTE_ADDR نشانی اینترنت شما نیست (نشانی CDN است) و یکی از سرآیندها هست، همان را انتخاب کنید؛ وگرنه سقف تلاش ورود و پیامک برای همهٔ کاربران یکی می‌شود. سرآیندی را که CDN شما نمی‌فرستد انتخاب نکنید.</p></td></tr></table>';
        submit_button('ذخیره');
        echo '</form>';
    }
}

Mazesta_Connect::boot();
